# Methodology

## Question
Where in Paris could a €1.50 coffee shop succeed? The answer is a transparent multi-criteria ranking of the 20 arrondissements, a customer-aspect analysis, and a financial simulator. Clustering is a separate, exploratory analysis.

## Data
| Source | Use | Notes |
|---|---|---|
| Google Maps reviews (Apify exports) | reviews, ratings, structured fields | 9,609 unique Paris reviews, 270 venues; 25–50 most recent reviews per venue |
| SIRENE (data.gouv.fr) | competing cafés, hospitality activity | team selection of 4,285 cafés + hospitality directory |
| INSEE Populations légales 2021 | resident population | municipal population per arrondissement; verify figures against the INSEE table before the final report |
| Paris Open Data | district outlines | optional official file, otherwise simplified outlines |

Students, transit access and commercial rents are **not available** and are never invented. They can be imported (CSV).

### Review cleaning (`01_prepare_reviews.py`)
Exports are merged; duplicates are removed by review id and by exact long copies (≥ 40 characters). Short identical texts ("Super !") are kept. Reviews without text are excluded from statistics (rating-only reviews are not comparable). Venues are classified (café / bar-brasserie / restaurant / off-topic) from Google categories; the default scope is café + adjacent + restaurant, because cafés alone leave districts 16, 18, 20 almost empty. Starbucks (32 venues, ~14% of reviews, rated 3.15 vs 4.21 for independents) is flagged and compared separately.

## Aspect-based sentiment analysis (`02_absa.py`)
Nine aspects: price, taste, coffee quality, service, waiting time, atmosphere, comfort & space, drink variety, takeaway. Only French and English reviews are analysed.
1. Each review is split into clauses (sentences, contrast conjunctions, commas).
2. **Aspect detection**: multilingual sentence embeddings (`paraphrase-multilingual-MiniLM-L12-v2`); each clause is compared by cosine similarity with French and English anchor sentences for each aspect, and with off-topic ("noise") anchors. A clause is attached to an aspect if similarity ≥ 0.42 and it beats the noise by 0.03; a second aspect is added if within 0.04. This is semantic matching, not keyword matching.
3. **Polarity**: XLM-RoBERTa fine-tuned for sentiment (`cardiffnlp/twitter-xlm-roberta-base-sentiment`): negative / neutral / positive per clause.
4. Aggregation per aspect and per district; no percentage is shown under 30 mentions.

**Validation**: (a) Spearman correlation with Google's own sub-ratings (Service, Atmosphere, Food); (b) a hand-labelled sample of 250 clauses (`pipeline/validation`), giving precision, recall and sentiment F1. Until (b) is done, irony, mixed languages and very short reviews are known weak spots.

## Attractiveness score (`03_metrics.py`)
Criteria (default weights in `config.toml`):
| Criterion | Weight | Direction |
|---|---|---|
| Resident population | 0.15 | higher is better |
| Hospitality activity (footfall proxy) | 0.15 | higher is better |
| Low café density per 10,000 residents | 0.20 | lower density is better |
| Incumbent dissatisfaction (low average rating) | 0.10 | lower rating is better |
| Price frustration (share of negative price mentions) | 0.20 | higher is better (price gap to exploit) |
| Waiting-time frustration | 0.10 | higher is better |
| Takeaway share | 0.10 | higher is better |

Each criterion is winsorised (5th–95th percentile), min–max scaled to 0–1, oriented, weighted and summed (0–100). A criterion missing for all districts is dropped and weights are renormalised (price and waiting criteria are dropped until the ABSA has run). A single missing value takes the median and is flagged.

**Eligibility**: a district needs ≥ 150 reviews and ≥ 8 venues. Confidence: ≥ 400 reviews high, ≥ 200 medium, otherwise low.

**Sensitivity**: 3,000 Dirichlet perturbations of the weights; we record how often each district stays in the top 3 and its plausible rank interval.

**Ranking is "reliable"** only if the ABSA is available, at most 2 districts are excluded for lack of data, and every top-3 district stays in the top 3 in ≥ 55% of the draws. Otherwise the site labels the ranking "provisional" and does not highlight a top 3 on the map.

## Clustering
K-Means (k from 2 to 5 chosen by silhouette, 50 initialisations, seed 42) on standardised district features, shown with a PCA projection. With 20 districts it is exploratory: it describes similarities and never feeds the ranking.

## Financial simulator
Client-side, formula-based. Starting values are working assumptions (price €1.50 incl. 10% VAT, 300 cups/day, 26 days, rent €4,500, 3 FTE at €2,600, ingredients €0.35, packaging €0.08, payment fee 1.5% and VAT 10% are fixed in the model; other monthly costs €1,600 (energy, insurance, accountant)) labelled "Project", "Assumption" or "To verify". Break-even cups/day = fixed costs ÷ (contribution margin per cup × days). At the defaults the shop loses money (break-even ≈ 586 cups/day): the €1.50 price needs high volume or low rent. District rents are only used if provided.

## Limitations
- Google reviews come from customers who chose to write; they are not a sample of all Parisians.
- Only recent reviews per venue: review counts do not measure popularity.
- Café density per resident ignores visitors and overstates competition in the centre; the hospitality count is a proxy, not a flow measure.
- The scope includes restaurants with café-type names.
- Students, transit and rents are absent until provided.
- A score is a decision aid, not a revenue forecast.
