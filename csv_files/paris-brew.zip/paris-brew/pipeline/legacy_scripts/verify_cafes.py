import re
import unicodedata
from pathlib import Path
from urllib.parse import quote_plus

import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
INPUT_FILE = PROJECT_DIR / "data" / "processed" / "cafes_selected_300.csv"
OUTPUT_FILE = PROJECT_DIR / "data" / "processed" / "cafes_to_verify.csv"

PARIS_ACTIVITY_CODES = {"56.10A", "56.10C", "56.30Z"}
CAFE_NAME_TERMS = (
    "cafe",
    "coffee",
    "espresso",
    "roaster",
    "brulerie",
    "barista",
    "latte",
    "cappuccino",
    "kawa",
    "salon de the",
    "tea room",
)


def normalize_text(value):
    text = "" if pd.isna(value) else str(value).casefold()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(char for char in text if not unicodedata.combining(char))
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def build_maps_link(row):
    parts = [row.get("cafe_name"), row.get("address"), row.get("postal_code")]
    query = ", ".join(
        str(part).strip()
        for part in parts
        if pd.notna(part) and str(part).strip()
    )
    query = f"{query}, Paris, France" if query else "Paris, France"
    return f"https://www.google.com/maps/search/?api=1&query={quote_plus(query)}"


def get_review_reasons(row, duplicate_pairs):
    reasons = []
    name = normalize_text(row.get("cafe_name"))
    address = normalize_text(row.get("address"))

    if not name:
        reasons.append("Missing establishment name")
    elif not any(term in name for term in CAFE_NAME_TERMS):
        reasons.append("Name does not clearly indicate a cafe or coffee business")

    activity_code = str(row.get("activity_code", "")).strip().upper()
    if activity_code not in PARIS_ACTIVITY_CODES:
        reasons.append(f"Unfamiliar or missing activity code: {activity_code or 'blank'}")

    if not address:
        reasons.append("Missing address")
    elif (name, address) in duplicate_pairs:
        reasons.append("Duplicate normalized name and address")

    postal_code = "" if pd.isna(row.get("postal_code")) else str(row.get("postal_code")).strip()
    arrondissement = pd.to_numeric(row.get("arrondissement"), errors="coerce")
    postal_arrondissement = (
        pd.to_numeric(postal_code[-2:], errors="coerce")
        if postal_code.startswith("750") and len(postal_code) == 5
        else float("nan")
    )

    if pd.isna(arrondissement) or not 1 <= arrondissement <= 20:
        reasons.append("Invalid or missing arrondissement")
    if pd.isna(postal_arrondissement) or not 1 <= postal_arrondissement <= 20:
        reasons.append("Postal code is not a valid Paris arrondissement code")
    elif not pd.isna(arrondissement) and arrondissement != postal_arrondissement:
        reasons.append("Postal code and arrondissement do not match")

    return reasons


def main():
    df = pd.read_csv(INPUT_FILE, dtype={"siret": str, "postal_code": str})

    normalized_names = df["cafe_name"].map(normalize_text)
    normalized_addresses = df["address"].map(normalize_text)
    pair_keys = list(zip(normalized_names, normalized_addresses))
    pair_counts = pd.Series(pair_keys).value_counts()
    duplicate_pairs = {
        pair
        for pair, count in pair_counts.items()
        if count > 1 and pair[0] and pair[1]
    }

    reasons_by_row = [
        get_review_reasons(row, duplicate_pairs)
        for _, row in df.iterrows()
    ]
    df["verification_reasons"] = ["; ".join(reasons) for reasons in reasons_by_row]
    df["verification_status"] = [
        "Needs manual verification" if reasons else "No issues detected"
        for reasons in reasons_by_row
    ]
    df["google_maps_search_link"] = df.apply(build_maps_link, axis=1)

    # Keep all establishments so uncertain records can be checked by a person.
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

    df["arrondissement_number"] = pd.to_numeric(
        df["arrondissement"], errors="coerce"
    )
    needs_review = df["verification_status"].eq("Needs manual verification")
    summary = (
        df.loc[needs_review]
        .groupby("arrondissement_number")
        .size()
        .reindex(range(1, 21), fill_value=0)
    )

    print(f"Verification file saved: {OUTPUT_FILE}")
    print(f"Total establishments: {len(df)}")
    print(f"Need manual verification: {int(needs_review.sum())}")
    print("\nManual verification needed per arrondissement:")
    for arrondissement, count in summary.items():
        print(f"{int(arrondissement):02d}: {count}")


if __name__ == "__main__":
    main()