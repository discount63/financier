from pathlib import Path

import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
PROCESSED_DIR = PROJECT_DIR / "data" / "processed"
INPUT_FILE = PROCESSED_DIR / "cafes_to_verify.csv"
OUTPUT_CSV = PROCESSED_DIR / "apify_queries.csv"
OUTPUT_TXT = PROCESSED_DIR / "apify_queries.txt"
DUPLICATE_MARKER = "Duplicate normalized name and address"


def main():
    df = pd.read_csv(INPUT_FILE, dtype={"postal_code": str})

    # Exclude duplicate candidates until a person reviews them.
    duplicate_mask = df["verification_reasons"].fillna("").str.contains(
        DUPLICATE_MARKER,
        case=False,
        regex=False,
    )
    ready = df.loc[~duplicate_mask].copy()

    ready["search_query"] = ready.apply(
        lambda row: ", ".join(
            [
                str(row["cafe_name"]).strip(),
                str(row["address"]).strip(),
                str(row["postal_code"]).strip(),
                "Paris, France",
            ]
        ),
        axis=1,
    )

    query_csv = ready[
        ["cafe_name", "arrondissement", "address", "search_query"]
    ].rename(columns={"cafe_name": "establishment_name"})

    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    query_csv.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")
    OUTPUT_TXT.write_text("\n".join(query_csv["search_query"]) + "\n", encoding="utf-8")

    summary = (
        ready.groupby("arrondissement")
        .size()
        .reindex(range(1, 21), fill_value=0)
    )
    print(f"Eligible establishments: {len(ready)}")
    print(f"Excluded for duplicate review: {int(duplicate_mask.sum())}")
    print(f"CSV saved: {OUTPUT_CSV}")
    print(f"TXT saved: {OUTPUT_TXT}")
    print("\nQueries per arrondissement:")
    for arrondissement, count in summary.items():
        print(f"{int(arrondissement):02d}: {count}")


if __name__ == "__main__":
    main()