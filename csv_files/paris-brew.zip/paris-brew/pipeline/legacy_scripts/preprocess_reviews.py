import pandas as pd

# Path to the raw reviews dataset
INPUT_FILE = "data/Raw/Reviews/Reviews by Apify Raw Clean.csv"

# Load the CSV file
df = pd.read_csv(INPUT_FILE)

# Display basic information about the dataset
print("Total number of reviews:", len(df))
print("\nColumns:", df.columns.tolist())
print("\nFirst 5 reviews:")
print(df.head())

#Filter 

# 2. Filter reviews

# Keep only French and English reviews.
df = df[df["review_language"].isin(["fr", "en"])].copy()

print("\nReviews after language filtering:", len(df))

# Remove reviews without text.
df = df.dropna(subset=["review_text"])

# Remove reviews with empty text.
df = df[df["review_text"].str.strip() != ""].copy()

print("Reviews after removing empty texts:", len(df))

# Remove duplicate reviews.
df = df.drop_duplicates(subset=["review_id"])

print("Reviews after removing duplicates", len(df))

# Installing spacy(python3 -m pip install spacy)
#Installing the french and english extenstion (python3 -m spacy download fr_core_news_sm. and python3 -m spacy download en_core_web_sm)  

# 3. Text preprocessing with spaCy

import spacy

# Load French and English language models
nlp_fr = spacy.load("fr_core_news_sm")
nlp_en = spacy.load("en_core_web_sm")


def preprocess_text(text, language):
    # Select the correct language model
    nlp = nlp_fr if language == "fr" else nlp_en

    # Analyze the text
    doc = nlp(text.lower())

    # Keep useful words in their base form
    tokens = [
        token.lemma_
        for token in doc
        if not token.is_stop
        and not token.is_punct
        and not token.is_space
        and not token.like_num
    ]

    return " ".join(tokens)


# Apply preprocessing to all reviews
df["cleaned_text"] = df.apply(
    lambda row: preprocess_text(
        row["review_text"],
        row["review_language"]
    ),
    axis=1
)

# Display an example
print("\nOriginal review:")
print(df["review_text"].iloc[0])

print("\nCleaned review:")
print(df["cleaned_text"].iloc[0])

# 4. Save the preprocessed dataset

from pathlib import Path

# Create the output folder if it does not exist
OUTPUT_FILE = Path("data/processed/reviews_cleaned.csv")
OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)

# Save the cleaned reviews
df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")

print("\nCleaned dataset saved successfully!")
print("Total reviews:", len(df))
print("File:", OUTPUT_FILE)
