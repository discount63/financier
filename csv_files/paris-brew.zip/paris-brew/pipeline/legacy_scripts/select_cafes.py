import pandas as pd
from pathlib import Path

# File paths
INPUT_FILE = Path("data/Raw/coffee list/paris_cafes_raw_4286.csv")
OUTPUT_FILE = Path("data/processed/cafes_selected_300.csv")

# Load the dataset
df = pd.read_csv(INPUT_FILE, dtype={"siret": str, "postal_code": str})

print(f"Total establishments: {len(df)}")

# Remove rows with missing information
df = df.dropna(subset=["cafe_name", "address", "arrondissement"])

# Keep only Paris arrondissements
df["arrondissement"] = pd.to_numeric(
    df["arrondissement"], errors="coerce"
)

df = df[df["arrondissement"].between(1, 20)].copy()

# Remove duplicate establishments
df = df.drop_duplicates(subset=["siret"])

# Identify names that suggest a coffee shop
coffee_keywords = [
    "coffee",
    "cafe",
    "café",
    "espresso",
    "roaster",
    "brulerie",
    "brûlerie",
    "barista",
    "latte",
    "cappuccino",
    "kawa"
]

df["coffee_priority"] = df["cafe_name"].str.lower().apply(
    lambda name: any(word in name for word in coffee_keywords)
)

# Prioritize coffee-related names
df = df.sort_values(
    by=["arrondissement", "coffee_priority"],
    ascending=[True, False]
)

# Select up to 15 establishments per arrondissement
selected = (
    df.groupby("arrondissement", group_keys=False)
    .head(15)
    .copy()
)

# Prepare Google Maps search queries
selected["google_maps_query"] = (
    selected["cafe_name"].astype(str)
    + ", "
    + selected["address"].astype(str)
    + ", "
    + selected["postal_code"].astype(str)
    + " Paris, France"
)

# Save the result
OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)

selected.to_csv(
    OUTPUT_FILE,
    index=False,
    encoding="utf-8-sig"
)

# Display results
print("\nSelected establishments by arrondissement:")
print(selected.groupby("arrondissement").size())

print(f"\nTotal selected: {len(selected)}")
print(f"File saved: {OUTPUT_FILE}")

print("\nFirst 5 Google Maps queries:")
print(selected["google_maps_query"].head().to_string(index=False))