"""Prepare Apify queries and safely process a Google Maps reviews export.

Run from the project folder:
    python3 process_apify_pipeline.py
    python3 process_apify_pipeline.py --apify-export path/to/apify_export.csv

Each run writes to a new folder under data/processed/apify_pipeline_runs.
"""

import argparse
import re
import unicodedata
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
PROCESSED_DIR = PROJECT_DIR / "data" / "processed"
QUERIES_FILE = PROCESSED_DIR / "apify_queries.csv"
EXISTING_REVIEWS_FILE = PROCESSED_DIR / "reviews_cleaned.csv"
RUNS_DIR = PROCESSED_DIR / "apify_pipeline_runs"

DUPLICATE_REVIEW_THRESHOLD = 0.88
DUPLICATE_ADDRESS_THRESHOLD = 0.82
DUPLICATE_COMBINED_THRESHOLD = 0.88
MINIMUM_MATCH_GAP = 0.08


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Prepare Apify queries and process an Apify reviews CSV export."
    )
    parser.add_argument(
        "--apify-export",
        type=Path,
        help="Path to a new Apify CSV export. Omit this to prepare queries only.",
    )
    return parser.parse_args()


def create_run_directory():
    RUNS_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("run_%Y%m%d_%H%M%S")
    run_directory = RUNS_DIR / timestamp
    suffix = 1
    while run_directory.exists():
        run_directory = RUNS_DIR / f"{timestamp}_{suffix:02d}"
        suffix += 1
    run_directory.mkdir()
    return run_directory


def prepare_bulk_queries(run_directory):
    queries = pd.read_csv(QUERIES_FILE, dtype=str, keep_default_na=False)
    required_columns = {
        "establishment_name",
        "arrondissement",
        "address",
        "search_query",
    }
    missing_columns = required_columns.difference(queries.columns)
    if missing_columns:
        raise ValueError(
            "The query CSV is missing required columns: "
            + ", ".join(sorted(missing_columns))
        )

    bulk_queries = queries[
        ["search_query", "establishment_name", "address", "arrondissement"]
    ].rename(
        columns={
            "establishment_name": "expected_establishment_name",
            "address": "expected_address",
            "arrondissement": "expected_arrondissement",
        }
    )
    bulk_queries.to_csv(
        run_directory / "apify_bulk_queries.csv",
        index=False,
        encoding="utf-8-sig",
    )
    (run_directory / "apify_search_queries.txt").write_text(
        "\n".join(bulk_queries["search_query"]) + "\n",
        encoding="utf-8",
    )
    return bulk_queries


def normalize_text(value, address=False):
    if pd.isna(value):
        return ""
    text = unicodedata.normalize("NFKD", str(value).casefold())
    text = "".join(
        character
        for character in text
        if not unicodedata.combining(character)
    )
    if address:
        text = re.sub(r"\b750\d{2}\b", " ", text)
        text = re.sub(r"\b(paris|france)\b", " ", text)
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def similarity(left, right):
    if not left or not right:
        return 0.0
    return SequenceMatcher(None, left, right).ratio()


def address_number(address):
    match = re.match(r"\s*(\d+)\s*([a-z])?\b", address)
    return "" if match is None else (match.group(1) + (match.group(2) or ""))


def find_column(frame, aliases):
    columns_by_normalized_name = {
        re.sub(r"[^a-z0-9]", "", str(column).casefold()): column
        for column in frame.columns
    }
    for alias in aliases:
        key = re.sub(r"[^a-z0-9]", "", alias.casefold())
        if key in columns_by_normalized_name:
            return columns_by_normalized_name[key]
    return None


def add_standard_column(frame, target, aliases):
    source = find_column(frame, aliases)
    if source is None:
        frame[target] = ""
    elif source != target:
        frame[target] = frame[source]
    return frame


def standardize_export(frame):
    frame = frame.copy()
    aliases = {
        "review_id": ("review_id", "reviewId", "reviewID", "id"),
        "cafe_name": ("cafe_name", "placeName", "place_name", "name"),
        "cafe_address": (
            "cafe_address",
            "address",
            "place_address",
            "full_address",
        ),
        "review_text": ("review_text", "reviewText", "text", "textTranslated"),
        "review_rating": ("review_rating", "rating", "stars"),
        "review_date": ("review_date", "publishedAtDate", "date"),
        "cleaned_text": ("cleaned_text",),
        "translated_text": ("translated_text", "textTranslated"),
    }
    for target, names in aliases.items():
        add_standard_column(frame, target, names)
    frame["review_id"] = frame["review_id"].fillna("").astype(str).str.strip()
    return frame


def match_review(review, expected_establishments):
    review_name = normalize_text(review.get("cafe_name"))
    review_address = normalize_text(review.get("cafe_address"), address=True)
    if not review_name or not review_address:
        return {
            "match_status": "needs_manual_review",
            "match_reason": "Returned café name or address is missing",
            "match_score": 0.0,
            "name_match_score": 0.0,
            "address_match_score": 0.0,
            "expected_establishment_name": "",
            "expected_address": "",
            "expected_arrondissement": "",
        }

    candidates = []
    for expected in expected_establishments.itertuples(index=False):
        expected_name = normalize_text(expected.establishment_name)
        expected_address = normalize_text(expected.address, address=True)
        name_score = similarity(review_name, expected_name)
        address_score = similarity(review_address, expected_address)

        returned_number = address_number(review_address)
        expected_number = address_number(expected_address)
        if returned_number and expected_number and returned_number != expected_number:
            address_score = 0.0

        combined_score = (name_score + address_score) / 2
        candidates.append(
            {
                "name_score": name_score,
                "address_score": address_score,
                "combined_score": combined_score,
                "establishment_name": expected.establishment_name,
                "address": expected.address,
                "arrondissement": expected.arrondissement,
            }
        )

    candidates.sort(key=lambda candidate: candidate["combined_score"], reverse=True)
    best = candidates[0]
    next_score = candidates[1]["combined_score"] if len(candidates) > 1 else 0.0
    is_unique = best["combined_score"] - next_score >= MINIMUM_MATCH_GAP
    is_strong = (
        best["name_score"] >= DUPLICATE_REVIEW_THRESHOLD
        and best["address_score"] >= DUPLICATE_ADDRESS_THRESHOLD
        and best["combined_score"] >= DUPLICATE_COMBINED_THRESHOLD
    )

    if not is_strong:
        reason = "Name and address do not both meet the match thresholds"
    elif not is_unique:
        reason = "More than one expected establishment is a possible match"
    else:
        reason = "Name and address match one expected establishment"

    return {
        "match_status": "verified_match" if is_strong and is_unique else "needs_manual_review",
        "match_reason": reason,
        "match_score": round(best["combined_score"], 4),
        "name_match_score": round(best["name_score"], 4),
        "address_match_score": round(best["address_score"], 4),
        "expected_establishment_name": best["establishment_name"],
        "expected_address": best["address"],
        "expected_arrondissement": best["arrondissement"],
    }


def clean_for_aspect_analysis(value):
    normalized = normalize_text(value)
    return normalized


def process_reviews(export_path, expected_establishments, run_directory):
    incoming = pd.read_csv(export_path, dtype=str, keep_default_na=False)
    incoming = standardize_export(incoming)

    match_results = [
        match_review(row, expected_establishments)
        for _, row in incoming.iterrows()
    ]
    audit = pd.concat(
        [incoming.reset_index(drop=True), pd.DataFrame(match_results)],
        axis=1,
    )
    audit["merge_status"] = "needs_manual_review"
    audit.loc[
        audit["match_status"].eq("verified_match")
        & audit["review_id"].ne(""),
        "merge_status",
    ] = "ready_to_merge"
    audit.loc[
        audit["review_id"].eq("")
        & audit["match_status"].eq("verified_match"),
        "match_status",
    ] = "needs_manual_review"
    audit.loc[
        audit["review_id"].eq(""), "match_reason"
    ] = "Review ID is missing; safe deduplication is not possible"
    audit.loc[
        audit["review_text"].astype(str).str.strip().eq("")
        & audit["merge_status"].eq("ready_to_merge"),
        "merge_status",
    ] = "needs_manual_review"
    audit.loc[
        audit["review_text"].astype(str).str.strip().eq(""), "match_reason"
    ] = "Review text is missing"

    existing = pd.read_csv(
        EXISTING_REVIEWS_FILE,
        dtype={"review_id": str},
        keep_default_na=False,
    )
    existing["review_id"] = existing["review_id"].astype(str).str.strip()
    existing_ids = set(existing.loc[existing["review_id"].ne(""), "review_id"])
    seen_new_ids = set()

    for index in audit.index[audit["merge_status"].eq("ready_to_merge")]:
        review_id = audit.at[index, "review_id"]
        if review_id in existing_ids or review_id in seen_new_ids:
            audit.at[index, "merge_status"] = "duplicate_review_id"
            audit.at[index, "match_reason"] = (
                "Review ID already exists in the merged input"
            )
        else:
            seen_new_ids.add(review_id)

    accepted = audit.loc[audit["merge_status"].eq("ready_to_merge")].copy()
    if not accepted.empty:
        accepted["cleaned_text"] = accepted.apply(
            lambda row: str(row["cleaned_text"]).strip()
            or clean_for_aspect_analysis(
                row["translated_text"] or row["review_text"]
            ),
            axis=1,
        )
        accepted["pipeline_record_source"] = "new_apify_export"

    existing["pipeline_record_source"] = "existing_cleaned_dataset"
    merged = pd.concat([existing, accepted], ignore_index=True, sort=False)
    merged["review_id"] = merged["review_id"].astype(str).str.strip()
    merged = merged.loc[merged["review_id"].ne("")]
    merged = merged.drop_duplicates(subset=["review_id"], keep="first")

    audit.to_csv(
        run_directory / "apify_review_match_audit.csv",
        index=False,
        encoding="utf-8-sig",
    )
    audit.loc[audit["merge_status"].eq("needs_manual_review")].to_csv(
        run_directory / "apify_reviews_needing_review.csv",
        index=False,
        encoding="utf-8-sig",
    )
    merged.to_csv(
        run_directory / "reviews_for_aspect_sentiment.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print(f"New review rows: {len(incoming)}")
    print(f"New reviews accepted: {len(accepted)}")
    print(
        "New reviews needing manual review: "
        f"{int(audit['merge_status'].eq('needs_manual_review').sum())}"
    )
    print(
        "Duplicate review IDs not added: "
        f"{int(audit['merge_status'].eq('duplicate_review_id').sum())}"
    )
    print(f"Final unique reviews: {len(merged)}")
    print(f"Final dataset: {run_directory / 'reviews_for_aspect_sentiment.csv'}")


def main():
    arguments = parse_arguments()
    if arguments.apify_export and not arguments.apify_export.is_file():
        raise SystemExit(f"Apify export not found: {arguments.apify_export}")
    if not QUERIES_FILE.is_file():
        raise SystemExit(f"Query CSV not found: {QUERIES_FILE}")

    run_directory = create_run_directory()
    bulk_queries = prepare_bulk_queries(run_directory)
    print(f"Prepared {len(bulk_queries)} queries in: {run_directory}")

    if arguments.apify_export is None:
        print("No Apify export supplied; query preparation is complete.")
        return
    if not EXISTING_REVIEWS_FILE.is_file():
        raise SystemExit(f"Existing cleaned reviews not found: {EXISTING_REVIEWS_FILE}")

    expected = pd.read_csv(QUERIES_FILE, dtype=str, keep_default_na=False)
    process_reviews(arguments.apify_export, expected, run_directory)


if __name__ == "__main__":
    main()