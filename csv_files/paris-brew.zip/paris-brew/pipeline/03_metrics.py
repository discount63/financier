"""Étape 3 — Indicateurs par arrondissement, analyse d'aspects agrégée, score d'attractivité, K-Means.

Entrées : data/processed/reviews_clean.csv, venues.csv, aspect_mentions.csv (si l'étape 2 a été lancée),
          data/external/sirene_paris_cafes.csv, data/external/district_indicators.csv
Sortie  : data/processed/metrics.json   (consommé par 04_export_site_data.py)

Règle d'or : aucune valeur n'est inventée. Un indicateur manquant reste « unavailable » et n'entre pas dans le score.
Usage :  python3 pipeline/03_metrics.py
"""
from __future__ import annotations

import re
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aspects import ASPECTS  # noqa: E402
from common import ARR_LABELS, ARR_NAMES_FR, ROOT, load_config, path_of, write_json  # noqa: E402

ARRS = list(range(1, 21))
STOPWORDS = set(
    """le la les un une des du de d l et ou mais donc or ni car que qui quoi dont où ce cet cette ces mon ma mes ton ta tes son sa
    ses notre nos votre vos leur leurs je tu il elle on nous vous ils elles me te se lui y en à au aux avec sans pour par sur sous dans
    chez très trop plus moins aussi bien mal pas ne n c j s t qu est sont était étaient été être avoir a ai as avons avez ont avait
    fait faire faut peu tout tous toute toutes comme si the a an and or but of to in on at for with is are was were be been it its this
    that these those i you he she we they my your our their not no very too so just really also have has had do does did from by as
    can will would there here which who what when where than then them him her his me us""".split()
)


# --------------------------------------------------------------------------------------------------- utilitaires
def metric(value, unit: str = "", status: str = "measured", source: str = "", note: str = "") -> dict:
    """Un indicateur et son statut : measured | estimate | unavailable."""
    if value is None or (isinstance(value, float) and not np.isfinite(value)):
        return {"value": None, "unit": unit, "status": "unavailable", "source": source, "note": note}
    return {"value": value, "unit": unit, "status": status, "source": source, "note": note}


def share(mask: pd.Series) -> float | None:
    return float(mask.mean()) if len(mask) else None


def winsorized_minmax(values: pd.Series, bounds: list[float]) -> pd.Series:
    lo, hi = values.quantile(bounds[0]), values.quantile(bounds[1])
    if hi - lo < 1e-12:
        return pd.Series(0.5, index=values.index)
    return (values.clip(lo, hi) - lo) / (hi - lo)


def top_terms(neg: list[str], pos: list[str], n: int = 6) -> list[dict]:
    """Termes les plus caractéristiques des propositions négatives (log-odds avec a priori informatif, Monroe et al. 2008)."""
    def tokens(text: str) -> list[str]:
        words = [w for w in re.findall(r"[a-zàâçéèêëîïôûùüÿœ']+", text.lower()) if w not in STOPWORDS and len(w) > 2]
        return words + [f"{a} {b}" for a, b in zip(words, words[1:])]

    neg_c, pos_c = Counter(), Counter()
    for clause in neg:
        neg_c.update(set(tokens(clause)))
    for clause in pos:
        pos_c.update(set(tokens(clause)))
    total_neg, total_pos = max(sum(neg_c.values()), 1), max(sum(pos_c.values()), 1)
    prior = 0.5
    scored = []
    for term, count in neg_c.items():
        if count < 3:
            continue
        p_neg = (count + prior) / (total_neg + prior * len(neg_c))
        p_pos = (pos_c.get(term, 0) + prior) / (total_pos + prior * len(neg_c))
        scored.append((np.log(p_neg / p_pos) * np.log1p(count), term, count))
    scored.sort(reverse=True)
    out = []
    seen: list[str] = []
    for _, term, count in scored:
        if any(term in s or s in term for s in seen):  # évite « long » + « trop long »
            continue
        seen.append(term)
        example = min((c for c in neg if term in c.lower()), key=len, default="")
        out.append({"term": term, "count": int(count), "example": example[:140]})
        if len(out) == n:
            break
    return out


def positive_terms(pos: list[str], neg: list[str], n: int = 6) -> list[dict]:
    return top_terms(pos, neg, n)


# --------------------------------------------------------------------------------------------------- chargement
def load_inputs(config: dict):
    processed = path_of(config, "processed_dir")
    reviews = pd.read_csv(processed / "reviews_clean.csv", low_memory=False)
    reviews = reviews[reviews["in_scope"]].copy()
    if config["scope"]["exclude_chains_from_district_stats"]:
        reviews = reviews[~reviews["is_chain"]]
    venues = pd.read_csv(processed / "venues.csv")
    mentions_path = processed / "aspect_mentions.csv"
    mentions = pd.read_csv(mentions_path) if mentions_path.exists() else None
    sirene = pd.read_csv(path_of(config, "sirene_cafes"), dtype={"siret": str})
    indicators = pd.read_csv(path_of(config, "district_indicators")).set_index("arrondissement")
    directory_path = path_of(config, "sirene_directory")
    activity = None
    if directory_path.exists():
        directory = pd.read_csv(directory_path, dtype=str, low_memory=False,
                                usecols=["codePostalEtablissement", "activitePrincipaleEtablissement", "etatAdministratifEtablissement"])
        directory = directory[directory["etatAdministratifEtablissement"].eq("A")]
        directory["arr"] = pd.to_numeric(directory["codePostalEtablissement"].str.extract(r"^750(0[1-9]|1\d|20)$")[0], errors="coerce")
        directory = directory.dropna(subset=["arr"])
        directory["arr"] = directory["arr"].astype(int)
        code = directory["activitePrincipaleEtablissement"].fillna("")
        activity = pd.DataFrame({
            "hospitality_total": directory.groupby("arr").size(),
            "hotels": directory[code.str.startswith("55.")].groupby("arr").size(),
            "restaurants": directory[code.str.startswith("56.1")].groupby("arr").size(),
        }).fillna(0).astype(int)
    return reviews, venues, mentions, sirene, indicators, activity


# --------------------------------------------------------------------------------------------------- agrégats
def aspect_block(mentions: pd.DataFrame, reviews: pd.DataFrame, min_mentions: int) -> dict:
    """Statistiques d'aspects : global et par arrondissement. Retourne aussi la validation contre les sous-notes Google."""
    review_arr = reviews.set_index("review_id")["arr"]
    review_rating = reviews.set_index("review_id")["rating"]
    mentions = mentions[mentions["review_id"].isin(review_arr.index)].copy()
    mentions["arr"] = mentions["review_id"].map(review_arr)
    mentions["rating"] = mentions["review_id"].map(review_rating)
    n_reviews_total = reviews["analyzable"].sum()

    def stats(frame: pd.DataFrame, n_reviews: int) -> dict:
        n = len(frame)
        if n < min_mentions:
            return {"mentions": int(n), "reliable": False}
        return {
            "mentions": int(n), "reliable": True,
            "review_share": float(frame["review_id"].nunique() / max(n_reviews, 1)),
            "positive": float((frame["sentiment"] == "positive").mean()),
            "neutral": float((frame["sentiment"] == "neutral").mean()),
            "negative": float((frame["sentiment"] == "negative").mean()),
            "net": float(frame["sentiment_score"].mean()),
        }

    out: dict = {"global": {}, "by_arr": {a: {} for a in ARRS}, "validation": {}}
    analyzable = reviews[reviews["analyzable"]]
    per_arr_reviews = analyzable.groupby("arr").size().to_dict()
    for key, spec in ASPECTS.items():
        sub = mentions[mentions["aspect"] == key]
        block = stats(sub, int(n_reviews_total))
        block["label"] = spec["label"]
        # Lien avec la note globale : corrélation de Spearman entre la polarité moyenne de l'aspect dans l'avis et la note.
        per_review = sub.groupby("review_id").agg(score=("sentiment_score", "mean"), rating=("rating", "first"))
        if len(per_review) >= 40:
            rho, _ = spearmanr(per_review["score"], per_review["rating"])
            block["rating_correlation"] = None if np.isnan(rho) else float(rho)
            neg_r = per_review.loc[per_review["score"] < -0.2, "rating"].mean()
            pos_r = per_review.loc[per_review["score"] > 0.2, "rating"].mean()
            block["rating_when_negative"] = None if np.isnan(neg_r) else float(neg_r)
            block["rating_when_positive"] = None if np.isnan(pos_r) else float(pos_r)
        neg_clauses = sub.loc[sub["sentiment"] == "negative", "clause"].tolist()
        pos_clauses = sub.loc[sub["sentiment"] == "positive", "clause"].tolist()
        block["top_complaints"] = top_terms(neg_clauses, pos_clauses) if len(neg_clauses) >= 12 else []
        block["top_praise"] = positive_terms(pos_clauses, neg_clauses) if len(pos_clauses) >= 12 else []
        out["global"][key] = block
        for arr in ARRS:
            out["by_arr"][arr][key] = stats(sub[sub["arr"] == arr], int(per_arr_reviews.get(arr, 0)))

    # Validation externe : l'ABSA doit être cohérent avec les sous-notes Google (Service, Ambiance, Cuisine).
    pairs = {"service": "sub_service", "atmosphere": "sub_ambiance", "taste": "sub_food", "coffee_quality": "sub_food"}
    sub_ratings = reviews.set_index("review_id")
    for aspect, column in pairs.items():
        sub = mentions[mentions["aspect"] == aspect].groupby("review_id")["sentiment_score"].mean()
        joined = pd.concat([sub, sub_ratings[column]], axis=1, join="inner").dropna()
        if len(joined) >= 40:
            rho, _ = spearmanr(joined.iloc[:, 0], joined.iloc[:, 1])
            out["validation"][aspect] = {"google_sub_rating": column.replace("sub_", ""), "n": int(len(joined)),
                                         "spearman": float(rho)}
    return out


def district_table(reviews, venues, sirene, indicators, activity, config) -> pd.DataFrame:
    rows = []
    sirene_counts = sirene.groupby("arrondissement").size()
    sirene_bars = sirene[sirene["activity_code"] == "56.30Z"].groupby("arrondissement").size()
    for arr in ARRS:
        r = reviews[reviews["arr"] == arr]
        v = venues[(venues["arr"] == arr) & venues["segment"].isin(config["scope"]["include_segments"])]
        order = r["ctx_order_type"].dropna()
        wait = r["ctx_wait"].dropna()
        noise = r["ctx_noise"].dropna()
        price = r["price_band_eur"].dropna()
        pop = indicators.loc[arr, "population"] if arr in indicators.index else np.nan
        rows.append(
            {
                "arr": arr, "reviews": len(r), "venues": int(len(v)),
                "venues_core": int((v["segment"] == "core").sum()),
                "rating_mean": r["rating"].mean() if len(r) else np.nan,
                "pct_1_2": share(r["rating"] <= 2), "pct_5": share(r["rating"] == 5),
                "rating_hist": [int((r["rating"] == s).sum()) for s in range(1, 6)],
                "chain_share": share(r["is_chain"]),
                "price_band_mean": price.mean() if len(price) >= 30 else np.nan, "price_band_n": int(len(price)),
                "takeaway_share": share(order == "À emporter") if len(order) >= 15 else np.nan, "takeaway_n": int(len(order)),
                "long_wait_share": share(~wait.str.contains("Aucune|10 min maximum", regex=True)) if len(wait) >= 20 else np.nan,
                "wait_n": int(len(wait)),
                "loud_share": share(noise.str.startswith(("Élevé", "Très élevé"))) if len(noise) >= 30 else np.nan,
                "noise_n": int(len(noise)),
                "sub_service": r["sub_service"].mean() if r["sub_service"].notna().sum() >= 30 else np.nan,
                "sub_ambiance": r["sub_ambiance"].mean() if r["sub_ambiance"].notna().sum() >= 30 else np.nan,
                "population": pop,
                "hospitality_total": float(activity.at[arr, "hospitality_total"]) if activity is not None and arr in activity.index else np.nan,
                "hotels": float(activity.at[arr, "hotels"]) if activity is not None and arr in activity.index else np.nan,
                "sirene_cafes": int(sirene_counts.get(arr, 0)), "sirene_bars": int(sirene_bars.get(arr, 0)),
                "cafes_per_10k": sirene_counts.get(arr, 0) / pop * 10_000 if pop == pop else np.nan,
                "residents_per_cafe": pop / sirene_counts.get(arr, 1) if pop == pop else np.nan,
            }
        )
    return pd.DataFrame(rows).set_index("arr")


# --------------------------------------------------------------------------------------------------- classement
CRITERIA = {
    # nom : (colonne, sens (+1 = plus c'est élevé, mieux c'est), libellé, source, nécessite l'ABSA)
    "demand_population": ("population", +1, "Resident population", "INSEE", False),
    "visitor_activity": ("hospitality_total", +1, "Hospitality activity (proxy for footfall)", "SIRENE", False),
    "low_competition": ("cafes_per_10k", -1, "Low café density (per 10,000 residents)", "SIRENE ÷ INSEE", False),
    "incumbent_dissatisfaction": ("rating_mean", -1, "Average rating of incumbents (low = room to improve)", "Google Maps", False),
    "price_pain": ("price_neg", +1, "Price frustration (share of negative price mentions)", "ABSA", True),
    "wait_pain": ("wait_neg", +1, "Waiting-time frustration (share of negative waiting mentions)", "ABSA", True),
    "takeaway_signal": ("takeaway_share", +1, "Takeaway share (declared in reviews)", "Google Maps", False),
}


def score_districts(table: pd.DataFrame, aspects: dict | None, config: dict) -> dict:
    rk = config["ranking"]
    frame = table.copy()
    frame["price_neg"] = np.nan
    frame["wait_neg"] = np.nan
    absa_available = aspects is not None
    if absa_available:
        for arr in ARRS:
            p, w = aspects["by_arr"][arr]["price"], aspects["by_arr"][arr]["waiting_time"]
            frame.loc[arr, "price_neg"] = p.get("negative", np.nan) if p.get("reliable") else np.nan
            frame.loc[arr, "wait_neg"] = w.get("negative", np.nan) if w.get("reliable") else np.nan

    eligible = (frame["reviews"] >= rk["min_reviews_per_district"]) & (frame["venues"] >= rk["min_venues_per_district"])
    base_weights = {k: v for k, v in rk["weights"].items() if CRITERIA[k][4] is False or absa_available}
    used = {}
    normalized = pd.DataFrame(index=frame.index)
    imputed: dict[int, list[str]] = {a: [] for a in ARRS}
    for name in list(base_weights):
        column, sign, *_ = CRITERIA[name]
        values = frame.loc[eligible, column]
        if values.notna().sum() < 5:
            continue  # critère inutilisable : retiré, poids renormalisé
        scaled = winsorized_minmax(values, rk["winsor"])
        if sign < 0:
            scaled = 1 - scaled
        median_fill = float(scaled.median())
        for arr in values.index[values.isna()]:
            imputed[int(arr)].append(name)
        normalized[name] = scaled.reindex(frame.index)
        normalized.loc[eligible, name] = normalized.loc[eligible, name].fillna(median_fill)
        used[name] = base_weights[name]
    total = sum(used.values())
    weights = {k: v / total for k, v in used.items()}
    score = sum(normalized[k] * w for k, w in weights.items()) * 100
    score[~eligible] = np.nan

    # Sensibilité : on perturbe les poids (Dirichlet autour des poids de base) et on regarde si le top 3 tient.
    rng = np.random.default_rng(config["clustering"]["seed"])
    names = list(weights)
    alpha = np.array([weights[k] for k in names]) * 25
    draws = rng.dirichlet(alpha, size=rk["sensitivity_draws"])
    mat = normalized.loc[eligible, names].to_numpy()
    scores_draw = draws @ mat.T * 100  # (draws, districts)
    districts = list(normalized.index[eligible])
    ranks = (-scores_draw).argsort(axis=1).argsort(axis=1) + 1
    top_n = rk["top_n"]
    stability = {int(d): float((ranks[:, i] <= top_n).mean()) for i, d in enumerate(districts)}
    rank_interval = {int(d): [int(np.percentile(ranks[:, i], 5)), int(np.percentile(ranks[:, i], 95))] for i, d in enumerate(districts)}

    order = score.dropna().sort_values(ascending=False)
    top = [int(a) for a in order.index[:top_n]]
    excluded = [int(a) for a in frame.index[~eligible]]
    reasons: list[str] = []
    if not absa_available:
        reasons.append("Aspect-based sentiment analysis (ABSA) has not been run yet: the price and waiting-time criteria are missing from the score.")
    if len(excluded) > 2:
        reasons.append(f"{len(excluded)} districts have too few reviews ({', '.join(ARR_NAMES_FR[a] for a in excluded)}).")
    weak = [a for a in top if stability.get(a, 0) < rk["min_top3_stability"]]
    if weak:
        reasons.append(
            "The top 3 is not stable when the weights vary: "
            + ", ".join(f"{ARR_NAMES_FR[a]} ({stability[a]:.0%} of draws)" for a in weak) + "."
        )
    status = "reliable" if not reasons else "provisional"
    caveats = []
    if excluded and status == "reliable":
        caveats.append(f"Left out of the ranking for lack of data: {', '.join(ARR_NAMES_FR[a] for a in excluded)}.")

    return {
        "status": status, "reasons": reasons, "caveats": caveats, "top": top,
        "weights": weights, "criteria": {k: {"label": CRITERIA[k][2], "source": CRITERIA[k][3], "direction": CRITERIA[k][1],
                                              "weight": weights[k]} for k in weights},
        "dropped_criteria": [k for k in rk["weights"] if k not in weights],
        "scores": {int(a): (None if np.isnan(s) else round(float(s), 1)) for a, s in score.items()},
        "components": {int(a): {k: (None if np.isnan(normalized.at[a, k]) else round(float(normalized.at[a, k]), 3)) for k in weights}
                       for a in normalized.index},
        "imputed": {a: v for a, v in imputed.items() if v}, "excluded": excluded,
        "stability": stability, "rank_interval": rank_interval,
        "raw": {int(a): {k: (None if pd.isna(frame.at[a, CRITERIA[k][0]]) else float(frame.at[a, CRITERIA[k][0]])) for k in weights}
                for a in frame.index},
    }


def cluster_districts(table: pd.DataFrame, aspects: dict | None, eligible: list[int], config: dict) -> dict:
    cfg = config["clustering"]
    feats = pd.DataFrame(index=table.index)
    feats["population (log)"] = np.log(table["population"])
    feats["cafés per 10k residents"] = table["cafes_per_10k"]
    feats["average rating"] = table["rating_mean"]
    feats["% 1–2★ reviews"] = table["pct_1_2"]
    feats["% takeaway"] = table["takeaway_share"]
    if aspects is not None:
        for key in ("price", "service", "waiting_time", "atmosphere"):
            feats[f"net {ASPECTS[key]['label'].lower()}"] = [aspects["by_arr"][a][key].get("net", np.nan) for a in feats.index]
    feats = feats.loc[eligible]
    feats = feats.loc[:, feats.notna().sum() >= len(feats) * 0.8].fillna(feats.median())
    z = StandardScaler().fit_transform(feats)
    best = None
    for k in range(cfg["k_min"], min(cfg["k_max"], len(feats) - 1) + 1):
        model = KMeans(n_clusters=k, n_init=50, random_state=cfg["seed"]).fit(z)
        sil = float(silhouette_score(z, model.labels_))
        if best is None or sil > best[0]:
            best = (sil, k, model)
    sil, k, model = best
    pca = PCA(n_components=2, random_state=cfg["seed"]).fit(z)
    xy = pca.transform(z)
    zdf = pd.DataFrame(model.cluster_centers_, columns=feats.columns)
    clusters = []
    for c in range(k):
        members = [int(a) for a, lab in zip(feats.index, model.labels_) if lab == c]
        top_feat = zdf.loc[c].abs().sort_values(ascending=False).index[:2]
        traits = [f"{'high' if zdf.at[c, f] > 0 else 'low'}: {f}" for f in top_feat]
        clusters.append({"id": c, "members": members, "traits": traits})
    return {
        "k": int(k), "silhouette": round(sil, 3), "features": list(feats.columns), "clusters": clusters,
        "assignment": {int(a): int(l) for a, l in zip(feats.index, model.labels_)},
        "pca": {int(a): [round(float(x), 3), round(float(y), 3)] for a, (x, y) in zip(feats.index, xy)},
        "explained_variance": [round(float(v), 3) for v in pca.explained_variance_ratio_],
        "caveat": "With only 20 districts, clustering is exploratory: it describes similarities, it does not point to the best location.",
    }


def structured_block(reviews: pd.DataFrame) -> dict:
    """Ce que Google fournit déjà de façon structurée (sans NLP) : sous-notes, prix par personne, attente, bruit, type de commande."""
    english = {
        "Aucune attente": "No wait", "10 min maximum": "Up to 10 min", "10-30 min": "10–30 min", "30-60 min": "30–60 min",
        "1 heure ou plus": "1 hour or more", "Repas sur place": "Dine-in", "À emporter": "Takeaway", "Livraison": "Delivery",
    }

    def dist(series: pd.Series, order: list[str] | None = None) -> list[dict]:
        counts = series.dropna().astype(str).str.replace("\u00a0", " ", regex=False).value_counts()
        if order:
            counts = counts.reindex(order).dropna()
        counts.index = [english.get(k, k) for k in counts.index]
        total = counts.sum()
        return [{"label": k, "count": int(v), "share": float(v / total)} for k, v in counts.items()]

    subs = {}
    for key, column in (("service", "sub_service"), ("ambiance", "sub_ambiance"), ("food", "sub_food")):
        values = reviews[column].dropna()
        subs[key] = {"n": int(len(values)), "mean": float(values.mean()), "share_1_2": float((values <= 2).mean()),
                     "share_5": float((values == 5).mean())}
    fr = reviews[reviews["language"] == "fr"]
    neg = fr[fr["rating"] <= 2]["text"].astype(str).tolist()
    pos = fr[fr["rating"] >= 4]["text"].astype(str).tolist()
    return {
        "sub_ratings": subs,
        "rating_hist": [int((reviews["rating"] == s).sum()) for s in range(1, 6)],
        "price_band": dist(reviews["ctx_price_band"], ["1–10 €", "10–20 €", "20–30 €", "30–40 €", "40–50 €"]),
        "wait": dist(reviews["ctx_wait"], ["Aucune attente", "10 min maximum", "10-30 min", "30-60 min", "1 heure ou plus"]),
        "noise": dist(reviews["ctx_noise"]),
        "order_type": dist(reviews["ctx_order_type"]),
        "lexical": {
            "note": "Word counts (log-odds) in French 1–2★ reviews compared with 4–5★ reviews: a lexical statistic, not an aspect-level sentiment analysis.",
            "negative_reviews": len(neg), "terms": top_terms(neg, pos, n=14),
        },
    }


def chain_comparison(reviews: pd.DataFrame) -> dict:
    out = {}
    for label, mask in (("chain", reviews["is_chain"]), ("independent", ~reviews["is_chain"])):
        sub = reviews[mask]
        out[label] = {"reviews": int(len(sub)), "venues": int(sub["place_id"].nunique()), "rating_mean": float(sub["rating"].mean()),
                      "pct_1_2": float((sub["rating"] <= 2).mean())}
    return out


def main() -> None:
    config = load_config()
    reviews, venues, mentions, sirene, indicators, activity = load_inputs(config)
    table = district_table(reviews, venues, sirene, indicators, activity, config)
    aspects = aspect_block(mentions, reviews, config["ranking"]["min_aspect_mentions"]) if mentions is not None else None
    ranking = score_districts(table, aspects, config)
    eligible = [a for a in ARRS if a not in ranking["excluded"]]
    clustering = cluster_districts(table, aspects, eligible, config)

    payload = {
        "table": {int(a): {k: (None if (isinstance(v, float) and np.isnan(v)) else v) for k, v in row.items()}
                  for a, row in table.to_dict("index").items()},
        "aspects": aspects, "ranking": ranking, "clustering": clustering, "chains": chain_comparison(reviews),
        "structured": structured_block(reviews),
        "absa_available": aspects is not None,
        "global": {"reviews": int(len(reviews)), "venues": int(reviews["place_id"].nunique()),
                   "rating_mean": float(reviews["rating"].mean()), "pct_1_2": float((reviews["rating"] <= 2).mean())},
        "sirene_total": int(len(sirene)),
    }
    out = path_of(config, "processed_dir") / "metrics.json"
    write_json(out, payload)
    summary = pd.DataFrame({"reviews": table["reviews"], "venues": table["venues"], "rating": table["rating_mean"].round(2),
                            "cafes/10k": table["cafes_per_10k"].round(1), "score": pd.Series(ranking["scores"])})
    print(summary.to_string())
    print(f"\nRanking status : {ranking['status']}")
    for reason in ranking["reasons"]:
        print(" -", reason)
    print(f"Current top {config['ranking']['top_n']} : {[ARR_NAMES_FR[a] for a in ranking['top']]}")
    print(f"K-Means : k={clustering['k']}, silhouette={clustering['silhouette']}")
    print(f"Written: {out}")


if __name__ == "__main__":
    main()
