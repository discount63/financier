"""Étape 4 — Écrire les fichiers JSON lus par le site (web/public/data/).

Le site ne calcule rien de statistique : il affiche ce que cette étape produit, avec le statut de chaque valeur
(mesuré / estimation / indisponible) et sa source.

Contours : si data/external/arrondissements.geojson existe (export officiel Paris Open Data), il est utilisé.
Sinon on retombe sur un fichier basse définition (visible mais angulaire) et le site l'indique.
"""
from __future__ import annotations

import json
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aspects import ASPECTS  # noqa: E402
from common import ARR_LABELS, ARR_NAMES_FR, ROOT, load_config, path_of, write_json  # noqa: E402
from importlib import import_module  # noqa: E402

metrics_mod = import_module("03_metrics")
metric = metrics_mod.metric

NAME_TO_ARR = {  # contours basse définition : noms historiques
    "Louvre": 1, "Bourse": 2, "Temple": 3, "Hôtel-de-Ville": 4, "Panthéon": 5, "Luxembourg": 6, "Palais-Bourbon": 7,
    "Élysée": 8, "Opéra": 9, "Enclos-St-Laurent": 10, "Popincourt": 11, "Reuilly": 12, "Gobelins": 13, "Observatoire": 14,
    "Vaugirard": 15, "Passy": 16, "Batignolles-Monceau": 17, "Butte-Montmartre": 18, "Buttes-Chaumont": 19, "Ménilmontant": 20,
}


def load_geojson(config: dict) -> tuple[dict, str]:
    preferred, fallback = path_of(config, "geojson_preferred"), path_of(config, "geojson_fallback")
    path, quality = (preferred, "official") if preferred.exists() else (fallback, "lowres_fallback")
    data = json.load(open(path, encoding="utf-8"))
    features = []
    for feature in data["features"]:
        props = feature.get("properties", {})
        arr = None
        for key in ("c_ar", "c_arinsee", "arr", "arrondissement", "num_arr", "code_insee"):
            if key in props and props[key] not in (None, ""):
                value = int(str(props[key])[-2:]) if key in ("c_arinsee", "code_insee") else int(props[key])
                arr = value if 1 <= value <= 20 else None
                if arr:
                    break
        if arr is None:
            arr = NAME_TO_ARR.get(props.get("name"))
        if arr is None and props.get("l_ar"):
            match = re.match(r"(\d+)", str(props["l_ar"]))
            arr = int(match.group(1)) if match else None
        if arr is None:
            continue
        features.append({"type": "Feature", "id": arr, "properties": {"arr": arr, "name": ARR_NAMES_FR[arr], "label": ARR_LABELS[arr]},
                         "geometry": feature["geometry"]})
    features.sort(key=lambda f: f["properties"]["arr"])
    if len(features) != 20:
        raise SystemExit(f"The boundaries file must contain 20 districts (found: {len(features)}). Check {path}.")
    return {"type": "FeatureCollection", "features": features}, quality


def main() -> None:
    config = load_config()
    processed = path_of(config, "processed_dir")
    out_dir = path_of(config, "web_data_dir")
    out_dir.mkdir(parents=True, exist_ok=True)
    m = json.load(open(processed / "metrics.json", encoding="utf-8"))
    audit = json.load(open(processed / "audit.json", encoding="utf-8"))
    indicators = pd.read_csv(path_of(config, "district_indicators")).set_index("arrondissement")
    ranking, aspects, table = m["ranking"], m["aspects"], m["table"]
    absa_ok = m["absa_available"]

    districts = []
    for arr in range(1, 21):
        row = table[str(arr)]
        ind = indicators.loc[arr] if arr in indicators.index else None

        def ind_metric(col, src_col, unit):
            if ind is None or pd.isna(ind.get(col)):
                return metric(None, unit, source="To fill in: data/external/district_indicators.csv")
            return metric(float(ind[col]), unit, source=str(ind.get(src_col) or "Provided file"))

        rec = {
            "arr": arr, "name": ARR_NAMES_FR[arr], "label": ARR_LABELS[arr],
            "score": ranking["scores"].get(str(arr)), "eligible": arr not in ranking["excluded"],
            "confidence": ("high" if row["reviews"] >= 400 else "medium" if row["reviews"] >= 200 else "low"),
            "rank": None, "top3_stability": ranking["stability"].get(str(arr)),
            "rank_interval": ranking["rank_interval"].get(str(arr)),
            "cluster": m["clustering"]["assignment"].get(str(arr)),
            "pca": m["clustering"]["pca"].get(str(arr)),
            "components": ranking["components"].get(str(arr)), "raw": ranking["raw"].get(str(arr)), "imputed": ranking["imputed"].get(str(arr), []),
            "rating_hist": row["rating_hist"],
            "metrics": {
                "population": ind_metric("population", "population_source", "residents"),
                "students": ind_metric("students", "students_source", "students"),
                "transit": ind_metric("transit_stations", "transit_source", "stations"),
                "rent": ind_metric("rent_eur_m2_year", "rent_source", "€/m²/an"),
                "reviews": metric(row["reviews"], "reviews", source="Google Maps (Apify)"),
                "venues": metric(row["venues"], "venues", source="Google Maps (Apify)"),
                "rating": metric(row["rating_mean"], "/5", source="Google Maps (Apify)"),
                "negative_share": metric(row["pct_1_2"], "part", source="Google Maps (Apify)", note="1- or 2-star reviews"),
                "cafes_sirene": metric(row["sirene_cafes"], "cafés", source="SIRENE (team selection, 4,285 venues)"),
                "cafes_per_10k": metric(row["cafes_per_10k"], "per 10,000 residents", source="SIRENE ÷ INSEE",
                                        note="Counts residents, not visitors: overstates density in the centre."),
                "hospitality": metric(row["hospitality_total"], "venues", source="SIRENE, hospitality directory",
                                      note="Proxy for footfall (visitors and workers), not a flow measurement."),
                "takeaway": metric(row["takeaway_share"], "part", source="Google Maps: \"order type\"",
                                   note=f"out of {row['takeaway_n']} reviews that fill in this field"),
                "price_band": metric(row["price_band_mean"], "€ / person", source="Google Maps: \"price per person\"",
                                     note=f"midpoint of declared band, {row['price_band_n']} reviews"),
                "long_wait": metric(row["long_wait_share"], "part", source="Google Maps: \"wait time\"",
                                    note=f"10–30 min or more, out of {row['wait_n']} reviews"),
                "loud": metric(row["loud_share"], "part", source="Google Maps: \"noise level\"", note=f"out of {row['noise_n']} reviews"),
                "chain_share": metric(row["chain_share"], "part", source="Google Maps (Apify)", note="share of reviews about Starbucks"),
                "service_rating": metric(row["sub_service"], "/5", source="Google Maps: Service sub-rating"),
                "ambiance_rating": metric(row["sub_ambiance"], "/5", source="Google Maps: Atmosphere sub-rating"),
            },
            "aspects": aspects["by_arr"][str(arr)] if absa_ok else None,
        }
        districts.append(rec)
    ranked = sorted([d for d in districts if d["score"] is not None], key=lambda d: -d["score"])
    for position, d in enumerate(ranked, start=1):
        d["rank"] = position
    write_json(out_dir / "districts.json", districts)

    write_json(out_dir / "aspects.json", {
        "available": absa_ok,
        "labels": {k: v["label"] for k, v in ASPECTS.items()},
        "global": aspects["global"] if absa_ok else None,
        "validation": aspects["validation"] if absa_ok else None,
    })
    write_json(out_dir / "ranking.json", {
        "status": ranking["status"], "reasons": ranking["reasons"], "caveats": ranking["caveats"], "top": ranking["top"],
        "criteria": ranking["criteria"], "dropped_criteria": ranking["dropped_criteria"], "excluded": ranking["excluded"],
        "top_n": config["ranking"]["top_n"], "min_reviews": config["ranking"]["min_reviews_per_district"],
        "min_top3_stability": config["ranking"]["min_top3_stability"], "draws": config["ranking"]["sensitivity_draws"],
    })
    write_json(out_dir / "clusters.json", m["clustering"])

    geojson, quality = load_geojson(config)
    write_json(out_dir / "arrondissements.geojson", geojson)

    venues = pd.read_csv(processed / "venues.csv")
    venues = venues[venues["segment"].isin(config["scope"]["include_segments"])]
    write_json(out_dir / "venues.json", [
        {"n": r.place_name, "lat": round(r.lat, 5), "lon": round(r.lon, 5), "arr": int(r.arr), "seg": r.segment,
         "r": None if pd.isna(r.mean_rating_collected) else round(float(r.mean_rating_collected), 2), "c": bool(r.is_chain),
         "k": int(r.reviews_collected)}
        for r in venues.itertuples() if not pd.isna(r.lat)
    ])

    write_json(out_dir / "meta.json", {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "audit": audit, "structured": m["structured"], "global": m["global"], "chains": m["chains"], "sirene_total": m["sirene_total"],
        "absa_available": absa_ok, "geometry_quality": quality, "weights": ranking["weights"],
        "ranking_status": ranking["status"],
        "run_info": json.load(open(processed / "absa_run.json", encoding="utf-8")) if (processed / "absa_run.json").exists() else None,
        "scope": config["scope"], "absa_config": config["absa"],
        "sources": [
            {"name": "Google Maps reviews", "detail": "Collected with Apify (Google Maps Reviews Scraper, 25 to 50 recent reviews per venue)", "url": "https://apify.com"},
            {"name": "Venues", "detail": "SIRENE directory (hospitality, Paris): venues selected by the team", "url": "https://www.data.gouv.fr/datasets/base-sirene-des-entreprises-et-de-leurs-etablissements-siren-siret"},
            {"name": "Population", "detail": "INSEE, Populations légales 2021 (municipal population), Paris arrondissements table", "url": "https://www.insee.fr/fr/statistiques/fichier/7728806/dep75.pdf"},
            {"name": "District boundaries", "detail": "Paris Open Data if the official file is provided; otherwise low-resolution outlines (click_that_hood)", "url": "https://opendata.paris.fr/explore/dataset/arrondissements/"},
        ],
    })

    exports = ROOT / "exports"
    exports.mkdir(exist_ok=True)
    pd.DataFrame([{"arrondissement": d["name"], "score": d["score"], "rank": d["rank"], "reviews": d["metrics"]["reviews"]["value"],
                   "venues": d["metrics"]["venues"]["value"], "average_rating": d["metrics"]["rating"]["value"],
                   "cafes_per_10k_residents": d["metrics"]["cafes_per_10k"]["value"], "population": d["metrics"]["population"]["value"]}
                  for d in districts]).to_csv(exports / "synthese_arrondissements.csv", index=False, encoding="utf-8-sig")
    print(f"Site files written to {out_dir} (boundaries: {quality}, ranking: {ranking['status']})")


if __name__ == "__main__":
    main()
