"""Runs the whole pipeline: 01 prepare -> 02 ABSA -> 03 metrics -> 04 site files.

Usage:
    python3 pipeline/run_all.py              # everything (first ABSA run downloads ~1.5 GB of models)
    python3 pipeline/run_all.py --skip-absa  # reuse an existing aspect_mentions.csv, or run without ABSA
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run(script: str, *extra: str) -> None:
    print(f"\n=== {script} ===", flush=True)
    result = subprocess.run([sys.executable, str(HERE / script), *extra])
    if result.returncode != 0:
        raise SystemExit(f"{script} failed (exit code {result.returncode}). Fix the error above and re-run.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-absa", action="store_true", help="do not run step 2 (aspect analysis)")
    args = parser.parse_args()
    run("01_prepare_reviews.py")
    if not args.skip_absa:
        run("02_absa.py")
    run("03_metrics.py")
    run("04_export_site_data.py")
    print("\nDone. Start the site with:  cd web && npm install && npm run dev")


if __name__ == "__main__":
    main()
