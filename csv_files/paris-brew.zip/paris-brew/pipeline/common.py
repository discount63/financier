"""Utilitaires partagés par les scripts de la chaîne de traitement."""
from __future__ import annotations

import json
import re
try:
    import tomllib
except ImportError:
    import tomli as tomllib
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "pipeline" / "config.toml"

def _ordinal(n: int) -> str:
    if 10 <= n % 100 <= 20:
        return f"{n}th"
    return f"{n}{ {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th') }"


# Noms d'affichage des arrondissements (le site est en anglais : « 13th »).
ARR_NAMES_FR = {n: _ordinal(n) for n in range(1, 21)}
# Noms historiques des arrondissements (pour l'affichage).
ARR_LABELS = {
    1: "Louvre", 2: "Bourse", 3: "Temple", 4: "Hôtel-de-Ville", 5: "Panthéon", 6: "Luxembourg",
    7: "Palais-Bourbon", 8: "Élysée", 9: "Opéra", 10: "Entrepôt", 11: "Popincourt", 12: "Reuilly",
    13: "Gobelins", 14: "Observatoire", 15: "Vaugirard", 16: "Passy", 17: "Batignolles-Monceau",
    18: "Butte-Montmartre", 19: "Buttes-Chaumont", 20: "Ménilmontant",
}


def load_config() -> dict:
    with open(CONFIG_PATH, "rb") as handle:
        return tomllib.load(handle)


def path_of(config: dict, key: str) -> Path:
    return ROOT / config["paths"][key]


def normalize(text: object) -> str:
    """Minuscules, sans accents, sans ponctuation — pour comparer des noms."""
    if text is None or (isinstance(text, float) and text != text):
        return ""
    folded = unicodedata.normalize("NFKD", str(text).casefold())
    folded = "".join(ch for ch in folded if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", folded).strip()


_ARR_RE = re.compile(r"\b750(0[1-9]|1[0-9]|20)\b")


def arrondissement_from_address(address: object) -> int | None:
    match = _ARR_RE.search("" if address is None else str(address))
    return int(match.group(1)) if match else None


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"), default=_json_default)


def _json_default(value):  # numpy / pandas scalars
    try:
        import numpy as np

        if isinstance(value, (np.integer,)):
            return int(value)
        if isinstance(value, (np.floating,)):
            return None if value != value else float(value)
        if isinstance(value, np.ndarray):
            return value.tolist()
    except ImportError:  # pragma: no cover
        pass
    if value != value:  # NaN
        return None
    return str(value)
