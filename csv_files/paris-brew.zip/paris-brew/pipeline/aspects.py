"""Définition des 9 aspects analysés et segmentation des avis en propositions.

Détection d'aspect : par similarité sémantique (embeddings multilingues) entre chaque proposition de l'avis
et des phrases-ancres décrivant l'aspect, en français et en anglais. Ce n'est PAS une recherche de mots-clés :
« le monsieur au comptoir ne m'a même pas regardé » est rattaché au service sans contenir le mot « service ».
Les phrases « hors sujet » servent de contre-poids : une proposition n'est rattachée à un aspect que si elle est
plus proche de cet aspect que du bruit (anecdotes, localisation, accompagnants…).
"""
from __future__ import annotations

import re

ASPECTS: dict[str, dict] = {
    "price": {
        "label": "Price",
        "anchors": [
            "le prix est trop élevé", "c'est vraiment cher pour ce que c'est", "bon rapport qualité prix",
            "les tarifs sont abordables", "l'addition était salée", "prices are too high", "great value for money",
            "overpriced for what you get", "very affordable and cheap", "un café à ce prix-là, c'est abusif",
        ],
    },
    "taste": {
        "label": "Taste",
        "anchors": [
            "c'était délicieux", "les saveurs étaient fades et sans goût", "un goût excellent", "it tasted amazing",
            "bland and tasteless", "the food was delicious and flavorful", "un peu trop sucré ou amer",
            "gourmand et savoureux", "le gâteau était sec et sans saveur", "the flavor was off",
        ],
    },
    "coffee_quality": {
        "label": "Coffee quality",
        "anchors": [
            "le café est excellent", "un espresso brûlé et amer", "great coffee beans and a perfect espresso",
            "le cappuccino était tiède et aqueux", "the coffee was weak and burnt", "un café de spécialité bien torréfié",
            "le café est mauvais", "best flat white in town", "un expresso bien serré avec une belle crema",
            "café allongé trop dilué",
        ],
    },
    "service": {
        "label": "Service",
        "anchors": [
            "le personnel est accueillant et souriant", "le serveur était désagréable et impoli", "an incredibly friendly staff",
            "the waiter ignored us and was rude", "service lent et inattentif", "l'équipe est aux petits soins",
            "staff were helpful and professional", "on nous a mal reçus", "un accueil chaleureux", "serveuse méprisante",
        ],
    },
    "waiting_time": {
        "label": "Waiting time",
        "anchors": [
            "on a attendu très longtemps", "le service est rapide", "we waited over 30 minutes for our drinks",
            "pas d'attente, servi en deux minutes", "the queue was endless", "une attente interminable avant d'être servis",
            "quick and efficient service", "il a fallu patienter une heure", "long wait for a table", "les commandes arrivent vite",
        ],
    },
    "atmosphere": {
        "label": "Atmosphere",
        "anchors": [
            "l'ambiance est très agréable", "une atmosphère chaleureuse et cosy", "the vibe was great",
            "ambiance bruyante et désagréable", "une belle décoration et une musique agréable", "lovely atmosphere and charming decor",
            "l'endroit manque d'âme", "a lively and fun place", "un lieu charmant au cœur de Paris", "trop de bruit, impossible de discuter",
        ],
    },
    "comfort": {
        "label": "Comfort & space",
        "anchors": [
            "les chaises sont inconfortables", "il y a beaucoup de place pour s'installer", "very cramped and tiny seating",
            "la terrasse est agréable et spacieuse", "comfortable seats and plenty of space", "on est serrés les uns sur les autres",
            "les toilettes sont sales", "il y a des prises pour travailler", "a clean and comfortable place to work", "salle propre et bien chauffée",
        ],
    },
    "variety": {
        "label": "Drink variety",
        "anchors": [
            "un large choix de boissons", "la carte est très limitée", "great selection of teas and coffees",
            "peu d'options sans lait ou végétariennes", "many different drinks and pastries on the menu", "le menu manque de variété",
            "ils proposent des laits végétaux", "a wide range of cocktails and beers", "une carte originale et variée", "not enough choices on the menu",
        ],
    },
    "takeaway": {
        "label": "Takeaway",
        "anchors": [
            "pris à emporter, très pratique", "la commande à emporter était rapide", "coffee to go was perfect",
            "ils ont oublié des produits dans ma commande à emporter", "grab and go option is convenient", "emballage et gobelet de qualité",
            "commande en click and collect", "the takeaway cup was leaking", "service à emporter efficace", "pour emporter c'est parfait",
        ],
    },
}

# Phrases qui ne parlent d'aucun des neuf aspects : elles servent de point de comparaison négatif.
NOISE_ANCHORS = [
    "nous sommes venus à quatre pour l'anniversaire d'une amie", "c'est situé près de la gare", "we came here after visiting the museum",
    "je suis venu avec mes enfants le dimanche", "j'y suis allé hier soir", "merci pour votre réponse",
    "the place is on the corner of the street", "premier avis sur cet établissement", "nous avons réservé par téléphone",
    "c'est la deuxième fois que je viens", "il y avait beaucoup de monde dehors", "recommandé par un ami",
    "the reservation was made online", "un quartier très touristique", "à côté du métro",
]

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?…])\s+|[\n;]+")
_CONTRAST_SPLIT = re.compile(
    r"\b(?:mais|but|however|cependant|toutefois|par contre|en revanche|alors que|tandis que|although|though|whereas|sauf que|malgré)\b",
    flags=re.IGNORECASE,
)
_EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿]+")


def split_clauses(text: str, min_chars: int = 8) -> list[str]:
    """Découpe un avis en propositions : phrases, puis conjonctions d'opposition, puis virgules si les deux
    morceaux sont assez longs. L'objectif est qu'un avis « café excellent, personnel désagréable » donne deux
    unités, chacune avec sa polarité."""
    cleaned = _EMOJI.sub(" ", text or "")
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    clauses: list[str] = []
    for sentence in _SENTENCE_SPLIT.split(cleaned):
        for part in _CONTRAST_SPLIT.split(sentence):
            pieces = [p.strip(" ,.-–—") for p in re.split(r",\s+(?=\S)", part)]
            merged: list[str] = []
            for piece in pieces:
                if merged and len(piece.split()) < 2:  # fragment d'un seul mot : on le rattache au précédent
                    merged[-1] = f"{merged[-1]}, {piece}"
                elif piece:
                    merged.append(piece)
            clauses.extend(merged)
    return [c for c in clauses if len(c) >= min_chars]
