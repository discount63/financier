"""Étape 2 — Analyse de sentiment par aspect (ABSA) avec des modèles pré-entraînés multilingues.

Pour chaque avis analysable (fr / en, établissement dans le périmètre) :
  1. découpage en propositions                       (aspects.split_clauses)
  2. détection d'aspect par embeddings multilingues   (sentence-transformers, similarité cosinus aux phrases-ancres)
  3. polarité de chaque proposition                   (XLM-RoBERTa fine-tuné sentiment : négatif / neutre / positif)

Sortie : data/processed/aspect_mentions.csv  (une ligne = une proposition rattachée à un aspect)
         data/processed/absa_run.json         (modèles, seuils, volumes : traçabilité)

Premier lancement : télécharge ~1,5 Go de modèles depuis Hugging Face (internet requis). Ensuite tout est en cache.
Sur un MacBook M2 : compter ~10–25 minutes pour ~7 000 avis (le GPU Apple « mps » est utilisé automatiquement).

Usage :  python3 pipeline/02_absa.py
Test sans modèles (vérifie seulement le code, ne produit PAS de résultats réels) : python3 pipeline/02_absa.py --backend fake
"""
from __future__ import annotations

import argparse
import hashlib
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from aspects import ASPECTS, NOISE_ANCHORS, split_clauses  # noqa: E402
from common import load_config, path_of, write_json  # noqa: E402

LABELS = ["negative", "neutral", "positive"]


class RealBackend:
    """Modèles Hugging Face réels."""

    name = "huggingface"

    def __init__(self, config: dict):
        import torch
        from sentence_transformers import SentenceTransformer
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        absa = config["absa"]
        self.device = "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Compute device: {self.device}")
        self.prefix = absa.get("embedding_prefix", "")
        self.embedder = SentenceTransformer(absa["embedding_model"], device=self.device)
        self.tokenizer = AutoTokenizer.from_pretrained(absa["sentiment_model"])
        self.classifier = AutoModelForSequenceClassification.from_pretrained(absa["sentiment_model"]).to(self.device).eval()
        id2label = {int(k): v.lower() for k, v in self.classifier.config.id2label.items()}
        self.order = [next(i for i, lab in id2label.items() if lab.startswith(name[:3])) for name in LABELS]
        self.batch_size = absa["batch_size"]
        self.torch = torch

    def embed(self, texts: list[str]) -> np.ndarray:
        return self.embedder.encode(
            [self.prefix + t for t in texts], batch_size=128, normalize_embeddings=True, show_progress_bar=len(texts) > 500
        )

    def sentiment(self, texts: list[str]) -> np.ndarray:
        out = []
        for start in range(0, len(texts), self.batch_size):
            batch = texts[start:start + self.batch_size]
            enc = self.tokenizer(batch, padding=True, truncation=True, max_length=128, return_tensors="pt").to(self.device)
            with self.torch.no_grad():
                probs = self.torch.softmax(self.classifier(**enc).logits, dim=-1).cpu().numpy()
            out.append(probs[:, self.order])
            if (start // self.batch_size) % 50 == 0:
                print(f"  sentiment {min(start + self.batch_size, len(texts))}/{len(texts)}", flush=True)
        return np.vstack(out) if out else np.zeros((0, 3))


class FakeBackend:
    """Backend factice, déterministe, pour tester le code SANS télécharger de modèle. Ses résultats ne veulent rien dire."""

    name = "fake"

    def embed(self, texts: list[str]) -> np.ndarray:
        vecs = []
        for text in texts:
            seed = int(hashlib.md5(text.encode()).hexdigest()[:8], 16)
            vec = np.random.default_rng(seed).normal(size=64)
            vecs.append(vec / np.linalg.norm(vec))
        return np.array(vecs)

    def sentiment(self, texts: list[str]) -> np.ndarray:
        rows = []
        for text in texts:
            seed = int(hashlib.md5(("s" + text).encode()).hexdigest()[:8], 16)
            rows.append(np.random.default_rng(seed).dirichlet([1, 1, 1]))
        return np.array(rows)


def anchor_matrix(backend) -> tuple[list[str], np.ndarray, list[str], np.ndarray]:
    names, texts = [], []
    for key, spec in ASPECTS.items():
        for anchor in spec["anchors"]:
            names.append(key)
            texts.append(anchor)
    return names, backend.embed(texts), NOISE_ANCHORS, backend.embed(NOISE_ANCHORS)


def assign_aspects(similarity: np.ndarray, anchor_aspects: list[str], noise_sim: np.ndarray, config: dict):
    """similarity : (n_clauses, n_anchors). Retourne pour chaque proposition une liste de (aspect, score)."""
    absa = config["absa"]
    aspect_keys = list(ASPECTS)
    per_aspect = np.full((similarity.shape[0], len(aspect_keys)), -1.0)
    for j, key in enumerate(aspect_keys):
        cols = [i for i, a in enumerate(anchor_aspects) if a == key]
        per_aspect[:, j] = similarity[:, cols].max(axis=1)
    noise = noise_sim.max(axis=1)
    results = []
    for i in range(per_aspect.shape[0]):
        order = np.argsort(-per_aspect[i])
        best = per_aspect[i, order[0]]
        picked = []
        if best >= absa["aspect_threshold"] and best >= noise[i] + absa["aspect_margin"]:
            picked.append((aspect_keys[order[0]], float(best)))
            second = per_aspect[i, order[1]]
            if second >= absa["aspect_threshold"] and best - second <= absa["second_aspect_gap"]:
                picked.append((aspect_keys[order[1]], float(second)))
        results.append(picked)
    return results


def polarity(prob: np.ndarray, neutral_band: float) -> tuple[str, float]:
    """Étiquette = classe la plus probable ; une polarité très faible (|P(pos) - P(neg)| < bande) avec une part
    de neutre non négligeable est ramenée à « neutre »."""
    neg, neu, pos = (float(x) for x in prob)
    score = pos - neg
    label = LABELS[int(np.argmax([neg, neu, pos]))]
    if label != "neutral" and abs(score) < neutral_band and neu >= 0.25:
        label = "neutral"
    return label, score


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", choices=["huggingface", "fake"], default="huggingface")
    parser.add_argument("--limit", type=int, default=0, help="analyse only N reviews (quick trial)")
    args = parser.parse_args()

    config = load_config()
    processed = path_of(config, "processed_dir")
    reviews = pd.read_csv(processed / "reviews_clean.csv", low_memory=False)
    reviews = reviews[reviews["analyzable"]].copy()
    if args.limit:
        reviews = reviews.head(args.limit)
    print(f"Reviews to analyse: {len(reviews)}")

    rows = []
    for rid, text in zip(reviews["review_id"], reviews["text"]):
        for k, clause in enumerate(split_clauses(str(text))):
            rows.append((rid, k, clause))
    clauses = pd.DataFrame(rows, columns=["review_id", "clause_idx", "clause"])
    print(f"Clauses: {len(clauses)} (average {len(clauses) / max(len(reviews), 1):.1f} per review)")

    started = time.time()
    backend = FakeBackend() if args.backend == "fake" else RealBackend(config)
    anchor_aspects, anchor_vecs, _, noise_vecs = anchor_matrix(backend)

    vectors = backend.embed(clauses["clause"].tolist())
    assigned = assign_aspects(vectors @ anchor_vecs.T, anchor_aspects, vectors @ noise_vecs.T, config)

    keep_idx = [i for i, picks in enumerate(assigned) if picks]
    print(f"Clauses attached to at least one aspect: {len(keep_idx)} / {len(clauses)}")
    subset = clauses.iloc[keep_idx].reset_index(drop=True)
    probs = backend.sentiment(subset["clause"].tolist())

    records = []
    for pos, i in enumerate(keep_idx):
        label, score = polarity(probs[pos], config["absa"]["neutral_band"])
        for aspect, aspect_score in assigned[i]:
            records.append(
                {
                    "review_id": clauses.at[i, "review_id"], "clause_idx": clauses.at[i, "clause_idx"],
                    "clause": clauses.at[i, "clause"], "aspect": aspect, "aspect_score": round(aspect_score, 4),
                    "sentiment": label, "sentiment_score": round(score, 4),
                    "p_neg": round(float(probs[pos][0]), 4), "p_neu": round(float(probs[pos][1]), 4),
                    "p_pos": round(float(probs[pos][2]), 4),
                }
            )
    out = pd.DataFrame(records)
    target_dir = processed if args.backend == "huggingface" else processed / "test_fake_backend"
    target_dir.mkdir(parents=True, exist_ok=True)
    out.to_csv(target_dir / "aspect_mentions.csv", index=False, encoding="utf-8")
    write_json(
        target_dir / "absa_run.json",
        {
            "backend": backend.name, "embedding_model": config["absa"]["embedding_model"],
            "sentiment_model": config["absa"]["sentiment_model"], "thresholds": {k: config["absa"][k] for k in
            ("aspect_threshold", "aspect_margin", "second_aspect_gap", "neutral_band")},
            "reviews_analyzed": int(len(reviews)), "clauses": int(len(clauses)), "aspect_mentions": int(len(out)),
            "seconds": round(time.time() - started, 1),
        },
    )
    print(f"Wrote {len(out)} aspect mentions -> {target_dir / 'aspect_mentions.csv'} in {time.time() - started:.0f}s")
    if args.backend == "fake":
        print("WARNING: fake backend. These results are random and are not used by the site.")


if __name__ == "__main__":
    main()
