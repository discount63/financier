"""Scores the ABSA against your hand labels (data/processed/validation/labeling_sheet.csv, filled in).

Prints and saves (validation_report.json):
  - aspect precision, per aspect and overall: among clauses the model attached to an aspect, share where your label agrees
  - aspect recall: among clauses YOU labelled with an aspect, share the model found with the same aspect
  - sentiment accuracy and macro-F1 on clauses where the aspect was right, with the confusion matrix
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
from sklearn.metrics import confusion_matrix, f1_score

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from common import load_config, path_of, write_json  # noqa: E402

LABELS = ["negative", "neutral", "positive"]


def main() -> None:
    config = load_config()
    folder = path_of(config, "processed_dir") / "validation"
    sheet = pd.read_csv(folder / "labeling_sheet.csv").fillna("")
    sheet = sheet[sheet["human_aspect"].astype(str).str.strip() != ""].copy()
    if sheet.empty:
        raise SystemExit("No labelled rows found: fill human_aspect / human_sentiment first.")
    for col in ("human_aspect", "human_sentiment", "model_aspect", "model_sentiment"):
        sheet[col] = sheet[col].astype(str).str.strip().str.lower()

    model_has = sheet["model_aspect"] != "none"
    human_has = sheet["human_aspect"] != "none"
    assigned = sheet[model_has]
    precision = float((assigned["human_aspect"] == assigned["model_aspect"]).mean()) if len(assigned) else None
    per_aspect = {a: {"n": int(len(g)), "precision": float((g["human_aspect"] == a).mean())} for a, g in assigned.groupby("model_aspect")}
    labelled = sheet[human_has]
    recall = float((labelled["model_aspect"] == labelled["human_aspect"]).mean()) if len(labelled) else None

    right = sheet[model_has & (sheet["human_aspect"] == sheet["model_aspect"]) & sheet["human_sentiment"].isin(LABELS)]
    sentiment = None
    if len(right):
        sentiment = {
            "n": int(len(right)), "accuracy": float((right["human_sentiment"] == right["model_sentiment"]).mean()),
            "macro_f1": float(f1_score(right["human_sentiment"], right["model_sentiment"], labels=LABELS, average="macro", zero_division=0)),
            "confusion_rows_human_cols_model": confusion_matrix(right["human_sentiment"], right["model_sentiment"], labels=LABELS).tolist(),
        }
    report = {"labelled_rows": int(len(sheet)), "aspect_precision": precision, "aspect_recall": recall, "per_aspect": per_aspect, "sentiment": sentiment,
              "note": "Small hand-labelled sample: treat these figures as estimates with a wide margin of error."}
    write_json(folder / "validation_report.json", report)
    print(f"Rows: {len(sheet)}\nAspect precision: {precision}\nAspect recall: {recall}\nSentiment: {sentiment}")
    print(f"Report saved to {folder / 'validation_report.json'}")


if __name__ == "__main__":
    main()
