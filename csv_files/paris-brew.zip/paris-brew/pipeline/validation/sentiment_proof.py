"""Builds a PDF that shows, with evidence, how well the sentiment model (FR-5, XLM-RoBERTa) works.

Run it AFTER pipeline/05_review_sentiment.py. From the project folder:

  python3 pipeline/validation/sentiment_proof.py              # builds the report
  python3 pipeline/validation/sentiment_proof.py --make-sheet # (optional) 100 reviews for the team to label by hand

Output
  docs/sentiment_proof/Sentiment_model_validation.pdf    the document for the professor
  docs/sentiment_proof/*.png                             each chart on its own, for the slides
  docs/sentiment_proof/results.json                      every number shown in the PDF

The four tests in the report
  1. Stars as a reference: does the label agree with the stars the reviewer gave? (8,000+ reviews, automatic)
  2. Language check: is it as good in French as in English and other languages? (the model claims to be multilingual)
  3. Controlled sentences: 16 sentences written by us to test specific traps (negation, sarcasm, mixed opinions, Korean)
  4. Human labels (optional, strongest): the team labels 100 reviews by hand, then the model is scored against people
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import textwrap
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent.parent
PROCESSED = ROOT / "data" / "processed"
OUT = ROOT / "docs" / "sentiment_proof"
SHEET = PROCESSED / "validation" / "sentiment_labeling_sheet.csv"
SHEET_XLSX = PROCESSED / "validation" / "sentiment_labeling_sheet.xlsx"
TEAM = ["Zayd", "Nayun", "Harin", "Yeji"]
LABELS = ["negative", "neutral", "positive"]

# palette (same family as the website)
INK, MUTE, LINE = "#2B1A1D", "#7F6B70", "#E8DEDA"
NEG, NEU, POS, ACCENT = "#C23A32", "#9A93A6", "#23825A", "#B5214F"
LABEL_COLOR = {"negative": NEG, "neutral": NEU, "positive": POS}

# Test 3. Written by us before looking at the model's answers. "expected" lists every answer we accept.
CONTROLLED = [
    ("Simple", "FR", "Le café est délicieux et le personnel adorable.", ["positive"]),
    ("Simple", "FR", "Service très lent, j'ai attendu 25 minutes pour un expresso.", ["negative"]),
    ("Simple", "EN", "Best flat white in Paris, the baristas are lovely.", ["positive"]),
    ("Simple", "EN", "The coffee was cold and the staff were rude.", ["negative"]),
    ("Negation", "FR", "Pas mauvais du tout, je reviendrai !", ["positive"]),
    ("Negation", "EN", "Not bad at all, I would come back.", ["positive"]),
    ("Negation", "FR", "Je ne recommande pas cet endroit.", ["negative"]),
    ("Price", "FR", "Beaucoup trop cher pour ce que c'est.", ["negative"]),
    ("Neutral", "FR", "Le café est correct, sans plus.", ["neutral", "negative"]),
    ("Neutral", "EN", "It is a café. They serve coffee.", ["neutral"]),
    ("Mixed", "FR", "Le café est bon mais beaucoup trop cher.", ["neutral", "negative"]),
    ("Sarcasm", "FR", "Génial, 30 minutes d'attente pour un café tiède.", ["negative"]),
    ("Korean", "KO", "커피가 정말 맛있고 분위기도 좋아요.", ["positive"]),
    ("Korean", "KO", "너무 비싸고 직원이 불친절했어요.", ["negative"]),
    ("Other language", "ES", "El café estaba buenísimo, volveré.", ["positive"]),
    ("Other language", "IT", "Servizio lentissimo, mai più.", ["negative"]),
]


def load_model_module():
    spec = importlib.util.spec_from_file_location("review_sentiment", ROOT / "pipeline" / "05_review_sentiment.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def star_class(stars: pd.Series) -> np.ndarray:
    return np.where(stars >= 4, "positive", np.where(stars <= 2, "negative", "neutral"))


# ---------------------------------------------------------------- charts

def setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    installed = {f.name for f in font_manager.fontManager.ttflist}
    # several families: matplotlib falls back to the next one for characters a font lacks (Korean, for example)
    wanted = ["Helvetica Neue", "Arial", "Apple SD Gothic Neo", "AppleGothic", "Noto Sans CJK KR", "Noto Sans CJK JP", "Noto Sans CJK TC"]
    families = [f for f in wanted if f in installed] + ["DejaVu Sans"]
    plt.rcParams.update({
        "font.family": families,
        "font.size": 9.5, "axes.edgecolor": LINE, "axes.labelcolor": INK, "xtick.color": MUTE, "ytick.color": MUTE,
        "axes.spines.top": False, "axes.spines.right": False, "axes.titleweight": "bold", "axes.titlesize": 11,
        "axes.titlelocation": "left", "text.color": INK, "figure.dpi": 150,
    })
    return plt


def chart_score_by_star(plt, df):
    fig, ax = plt.subplots(figsize=(6.6, 3.3))
    data = [df.loc[df["rating"] == s, "sentiment_score"].dropna().values for s in range(1, 6)]
    parts = ax.violinplot([d if len(d) else [0] for d in data], positions=range(1, 6), widths=0.8, showextrema=False)
    for body, s in zip(parts["bodies"], range(1, 6)):
        body.set_facecolor(NEG if s <= 2 else POS if s >= 4 else NEU)
        body.set_alpha(0.28)
        body.set_edgecolor("none")
    means = [d.mean() if len(d) else np.nan for d in data]
    ax.plot(range(1, 6), means, color=INK, lw=1.6, marker="o", ms=6, zorder=3)
    for s, m, d in zip(range(1, 6), means, data):
        if not np.isnan(m):
            ax.annotate(f"{m:+.2f}", (s, m), textcoords="offset points", xytext=(9, 4), fontsize=9, fontweight="bold")
        ax.text(s, -1.22, f"n = {len(d):,}", ha="center", fontsize=8, color=MUTE)
    ax.axhline(0, color=LINE, lw=1)
    ax.set_xticks(range(1, 6), [f"{s}★" for s in range(1, 6)])
    ax.set_ylim(-1.3, 1.1)
    ax.set_ylabel("Model sentiment score (−1 to +1)")
    ax.set_xlabel("Stars given by the reviewer")
    ax.set_title("The model's score rises with the stars")
    fig.tight_layout()
    return fig


def chart_confusion(plt, truth, pred, title, truth_name):
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(truth, pred, labels=LABELS)
    share = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1)
    fig, ax = plt.subplots(figsize=(4.4, 3.5))
    ax.imshow(share, cmap="Greens" if True else None, vmin=0, vmax=1)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{share[i, j]:.0%}\n({cm[i, j]:,})", ha="center", va="center", fontsize=9,
                    color="white" if share[i, j] > 0.55 else INK, fontweight="bold" if i == j else "normal")
    ax.set_xticks(range(3), LABELS)
    ax.set_yticks(range(3), LABELS)
    ax.set_xlabel("Model says")
    ax.set_ylabel(truth_name)
    ax.set_title(title)
    for s in ax.spines.values():
        s.set_visible(False)
    fig.tight_layout()
    return fig


def chart_languages(plt, per_lang):
    fig, ax = plt.subplots(figsize=(6.6, 2.6))
    names = [f"{r['language']}  (n = {r['n']:,})" for r in per_lang]
    vals = [r["agreement"] for r in per_lang]
    y = np.arange(len(names))[::-1]
    ax.barh(y, vals, color=ACCENT, height=0.55)
    for yy, v in zip(y, vals):
        ax.text(v + 0.01, yy, f"{v:.0%}", va="center", fontsize=9, fontweight="bold")
    ax.set_yticks(y, names)
    ax.set_xlim(0, 1.08)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.0%}"))
    ax.set_xlabel("Agreement with the stars (1–2★ = negative, 4–5★ = positive)")
    ax.set_title("It works in every language, not only in English")
    fig.tight_layout()
    return fig


# ---------------------------------------------------------------- pages

A4 = (8.27, 11.69)


def wrap(text: str, width: int) -> list[str]:
    """Like textwrap.wrap, but counts Korean / Chinese / Japanese characters as two columns wide, and drops emoji
    (most fonts cannot draw them)."""
    import unicodedata
    text = "".join(ch for ch in str(text) if ord(ch) < 0x10000 and (unicodedata.category(ch) != "So" or ch in "★✓✗"))
    lines, cur, cur_w = [], "", 0
    for word in text.split():
        w = sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in word)
        if cur and cur_w + 1 + w > width:
            lines.append(cur)
            cur, cur_w = word, w
        else:
            cur, cur_w = (cur + " " + word if cur else word), cur_w + (1 if cur else 0) + w
        while cur_w > width:  # a single very long word
            lines.append(cur[:width])
            cur = cur[width:]
            cur_w = len(cur)
    if cur:
        lines.append(cur)
    return lines or [""]


def page(plt, title=None):
    fig = plt.figure(figsize=A4)
    if title:
        fig.text(0.08, 0.94, title, fontsize=16, fontweight="bold", color=INK)
        fig.add_artist(plt.Line2D([0.08, 0.92], [0.928, 0.928], color=ACCENT, lw=1.2))
    return fig


def paragraph(fig, x, y, text, width=96, size=9.5, color=INK, line=1.45, weight="normal"):
    """Writes wrapped text from (x, y) downwards and returns the y where it ends."""
    step = size * line / 72 / A4[1]
    for para in text.split("\n"):
        for ln in wrap(para, width) if para else [""]:
            fig.text(x, y, ln, fontsize=size, color=color, va="top", fontweight=weight)
            y -= step
    return y


def embed(fig, chart, rect):
    """Places a chart figure inside a page, as an image."""
    import io
    buf = io.BytesIO()
    chart.savefig(buf, format="png", dpi=200, bbox_inches="tight")
    buf.seek(0)
    import matplotlib.image as mpimg
    img = mpimg.imread(buf)
    ax = fig.add_axes(rect)
    ax.imshow(img)
    ax.axis("off")


def footer(fig, n, watermark=None):
    fig.text(0.08, 0.035, "Financier · Applied Data Science · Sookmyung Women's University", fontsize=7.5, color=MUTE)
    fig.text(0.92, 0.035, str(n), fontsize=7.5, color=MUTE, ha="right")
    if watermark:
        fig.text(0.5, 0.5, watermark, fontsize=46, color="#C23A32", alpha=0.14, ha="center", va="center", rotation=30, fontweight="bold")


def table(fig, top, rows, cols, widths, wraps, size=8.2, row_gap=0.006, color_col=None):
    """Simple table drawn as text. rows = list of lists of strings. Returns the y where it ends."""
    x0 = 0.08
    xs = [x0]
    for w in widths[:-1]:
        xs.append(xs[-1] + w)
    step = size * 1.38 / 72 / A4[1]
    for x, c in zip(xs, cols):
        fig.text(x, top, c, fontsize=size, fontweight="bold", color=MUTE, va="top")
    y = top - step - 0.006
    fig.add_artist(__import__("matplotlib.pyplot").pyplot.Line2D([x0, 0.92], [y + 0.003, y + 0.003], color=LINE, lw=0.8))
    for r in rows:
        cells = [wrap(v, w) for v, w in zip(r, wraps)]
        h = max(len(c) for c in cells)
        for k, (x, c) in enumerate(zip(xs, cells)):
            col = INK
            if color_col is not None and k in color_col:
                col = color_col[k](r[k])
            for i, ln in enumerate(c):
                fig.text(x, y - i * step, ln, fontsize=size, color=col, va="top",
                         fontweight="bold" if (color_col and k in color_col) else "normal")
        y -= h * step + row_gap
        fig.add_artist(__import__("matplotlib.pyplot").pyplot.Line2D([x0, 0.92], [y + 0.003, y + 0.003], color=LINE, lw=0.5))
        y -= 0.004
    return y


# ---------------------------------------------------------------- main

def make_sheet(n_per_star: int = 20, seed: int = 42) -> None:
    if SHEET.exists():
        # keep the reviews already drawn, so the sample never changes once people have started labelling
        out = pd.read_csv(SHEET, dtype=str).fillna("")
        print(f"Reusing the {len(out)} reviews of {SHEET.relative_to(ROOT)}")
    else:
        df = pd.read_csv(PROCESSED / "reviews_sentiment.csv", low_memory=False)
        df = df[df["sentiment_label"].notna() & (df["text"].fillna("").str.len() >= 20)]
        parts = [g.sample(min(len(g), n_per_star), random_state=seed) for _, g in df.groupby("rating")]
        sheet = pd.concat(parts).sample(frac=1, random_state=seed)
        out = sheet[["review_id", "text"]].copy()
        out["human_label"] = ""
        SHEET.parent.mkdir(parents=True, exist_ok=True)
        out.to_csv(SHEET, index=False, encoding="utf-8-sig")
    write_xlsx(out)
    print(f"Wrote {SHEET_XLSX.relative_to(ROOT)}: one tab per team member ({', '.join(TEAM)}), {len(out)} reviews in all.")
    print("In each tab, pick positive, neutral or negative in the 'Your label' column, WITHOUT looking up the stars.")
    print("Save the file (keep the .xlsx format), then run this script again without --make-sheet.")


def write_xlsx(out: pd.DataFrame) -> None:
    from openpyxl import Workbook
    from openpyxl.formatting.rule import CellIsRule
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation

    wb = Workbook()
    info = wb.active
    info.title = "How to label"
    H = Font(name="Arial", bold=True, size=16, color="5A2640")
    B = Font(name="Arial", size=11)
    BB = Font(name="Arial", size=11, bold=True)
    S = Font(name="Arial", bold=True, size=12, color="5A2640")
    lines = [
        ("How to label the reviews · 리뷰 라벨링 방법", H),
        ("", B),
        ("English", S),
        ("Goal: check that our sentiment model (XLM-RoBERTa) agrees with real people.", B),
        ("1. Open YOUR tab at the bottom of the screen (Zayd, Nayun, Harin or Yeji). 25 reviews each.", B),
        ("2. Read each review in column B.", B),
        ("3. In column C ('Your label'), click the cell and choose from the drop-down list:", B),
        ("      positive  = the customer is mostly happy        e.g. \"Super café, très bon accueil\"", B),
        ("      negative  = the customer is mostly unhappy      e.g. \"Trop cher et serveur désagréable\"", B),
        ("      neutral   = mixed, or no real opinion           e.g. \"Bon café mais très cher\" / \"Ouvert le dimanche\"", B),
        ("4. Judge the WHOLE review. Use a translator if the review is in a language you do not read.", B),
        ("5. Do NOT look up the stars on Google Maps. Answer from the text only.", BB),
        ("6. Save the file (keep .xlsx) and send it back to Zayd.", B),
        ("", B),
        ("한국어", S),
        ("목적: 우리의 감성 분석 모델(XLM-RoBERTa)이 실제 사람의 판단과 일치하는지 확인하는 것입니다.", B),
        ("1. 화면 아래쪽에서 본인 이름의 탭(Zayd, Nayun, Harin, Yeji)을 여세요. 한 사람당 리뷰 25개입니다.", B),
        ("2. B열의 리뷰를 읽으세요.", B),
        ("3. C열('Your label') 칸을 클릭하고 목록에서 하나를 고르세요:", B),
        ("      positive  = 손님이 대체로 만족함           예: \"Super café, très bon accueil\" (커피 최고, 친절함)", B),
        ("      negative  = 손님이 대체로 불만족함         예: \"Trop cher et serveur désagréable\" (너무 비싸고 직원이 불친절함)", B),
        ("      neutral   = 장단점이 섞였거나 의견이 없음  예: \"Bon café mais très cher\" (커피는 좋지만 너무 비쌈)", B),
        ("4. 리뷰 전체를 보고 판단하세요. 모르는 언어는 번역기를 사용해도 됩니다.", B),
        ("5. Google 지도에서 별점을 찾아보지 마세요. 텍스트만 보고 판단하세요.", BB),
        ("6. 파일을 .xlsx 형식으로 저장해서 Zayd에게 보내 주세요.", B),
    ]
    for i, (t, f) in enumerate(lines, 1):
        info.cell(row=i, column=1, value=t).font = f
    info.column_dimensions["A"].width = 110

    header_fill = PatternFill("solid", fgColor="5A2640")
    out = out.reset_index(drop=True)
    bounds = np.linspace(0, len(out), len(TEAM) + 1).round().astype(int)
    chunks = [out.iloc[bounds[k]:bounds[k + 1]] for k in range(len(TEAM))]
    for name, part in zip(TEAM, chunks):
        ws = wb.create_sheet(name)
        for j, h in enumerate(["#", "Review", "Your label", "review_id"], 1):
            c = ws.cell(row=1, column=j, value=h)
            c.font = Font(name="Arial", bold=True, color="FFFFFF")
            c.fill = header_fill
        dv = DataValidation(type="list", formula1='"positive,neutral,negative"', allow_blank=True,
                            errorTitle="Pick from the list", error="Choose positive, neutral or negative.")
        ws.add_data_validation(dv)
        for i, row in enumerate(part.itertuples(index=False), 2):
            ws.cell(row=i, column=1, value=i - 1).font = Font(name="Arial", color="7F6B70")
            t = ws.cell(row=i, column=2, value=str(row.text))
            t.font = Font(name="Arial", size=11)
            t.alignment = Alignment(wrap_text=True, vertical="top")
            lab = ws.cell(row=i, column=3, value=str(row.human_label) if str(row.human_label) in LABELS else None)
            lab.font = Font(name="Arial", size=11, bold=True)
            lab.alignment = Alignment(vertical="top")
            dv.add(lab)
            ws.cell(row=i, column=4, value=str(row.review_id)).font = Font(name="Arial", size=8, color="B0A4A8")
        last = len(part) + 1
        for word, color in [("positive", "E1F3EA"), ("neutral", "EEEDF1"), ("negative", "FBE5E1")]:
            ws.conditional_formatting.add(f"C2:C{last}", CellIsRule(operator="equal", formula=[f'"{word}"'], fill=PatternFill("solid", fgColor=color)))
        ws.column_dimensions["A"].width = 5
        ws.column_dimensions["B"].width = 90
        ws.column_dimensions["C"].width = 14
        ws.column_dimensions["D"].width = 12
        ws.freeze_panes = "B2"
    SHEET_XLSX.parent.mkdir(parents=True, exist_ok=True)
    wb.save(SHEET_XLSX)


def read_human_labels() -> pd.DataFrame | None:
    """Reads the labels from the Excel file (all tabs) if it exists, otherwise from the CSV."""
    if SHEET_XLSX.exists():
        tabs = pd.read_excel(SHEET_XLSX, sheet_name=None, dtype=str)   # every tab that has a label column
        frames = [t.rename(columns={"Your label": "human_label"})[["review_id", "human_label"]]
                  for t in tabs.values() if "Your label" in t.columns and "review_id" in t.columns]
        return pd.concat(frames).fillna("")
    if SHEET.exists():
        return pd.read_csv(SHEET, dtype=str).fillna("")
    return None


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--make-sheet", action="store_true", help="create the hand-labelling sheet and stop")
    ap.add_argument("--input", default=str(PROCESSED / "reviews_sentiment.csv"))
    ap.add_argument("--backend", choices=["real", "fake"], default="real", help="model for the controlled sentences")
    ap.add_argument("--watermark", default=None, help=argparse.SUPPRESS)
    args = ap.parse_args()
    if args.make_sheet:
        make_sheet()
        return

    plt = setup_matplotlib()
    from matplotlib.backends.backend_pdf import PdfPages
    from sklearn.metrics import accuracy_score, f1_score

    df = pd.read_csv(args.input, low_memory=False)
    df = df[df["sentiment_label"].notna()].copy()
    if df.empty:
        raise SystemExit("No sentiment labels found: run  python3 pipeline/05_review_sentiment.py  first.")
    OUT.mkdir(parents=True, exist_ok=True)
    R: dict = {"reviews_scored": int(len(df))}

    # ---- Test 1: stars
    clear = df[df["rating"] != 3]
    truth_bin = star_class(clear["rating"])
    agree = float((clear["sentiment_binary"].values == truth_bin).mean())
    corr = float(np.corrcoef(df["sentiment_score"], df["rating"])[0, 1])
    from scipy.stats import spearmanr
    rho = float(spearmanr(df["sentiment_score"], df["rating"]).correlation)
    means = {s: float(df.loc[df["rating"] == s, "sentiment_score"].mean()) for s in range(1, 6) if (df["rating"] == s).any()}
    monotonic = all(means[a] < means[b] for a, b in zip(sorted(means), sorted(means)[1:]))
    # baseline: always answer "positive" (most reviews are positive, so a lazy model would already look good)
    base = float((truth_bin == "positive").mean())
    neg_rows = clear[truth_bin == "negative"]
    neg_recall = float((neg_rows["sentiment_binary"] == "negative").mean()) if len(neg_rows) else float("nan")
    R["stars"] = {"agreement_binary": round(agree, 4), "pearson": round(corr, 3), "spearman": round(rho, 3),
                  "mean_score_by_star": {str(k): round(v, 3) for k, v in means.items()}, "monotonic": monotonic,
                  "baseline_always_positive": round(base, 4), "negative_reviews_caught": round(neg_recall, 4),
                  "n_clear": int(len(clear))}

    # ---- Test 2: languages
    lang = df.copy()
    lang["lang"] = lang["language"].fillna("other").str.lower()
    top = lang["lang"].value_counts()
    keep = [l for l in top.index if top[l] >= 40][:4]
    lang.loc[~lang["lang"].isin(keep), "lang"] = "other"
    names = {"fr": "French", "en": "English", "es": "Spanish", "it": "Italian", "de": "German", "ko": "Korean", "pt": "Portuguese", "other": "Other languages"}
    per_lang = []
    for l, g in lang[lang["rating"] != 3].groupby("lang"):
        if len(g) < 20:
            continue
        per_lang.append({"language": names.get(l, l), "n": int(len(g)), "agreement": float((g["sentiment_binary"].values == star_class(g["rating"])).mean())})
    per_lang.sort(key=lambda r: -r["n"])
    R["languages"] = per_lang

    # ---- Test 3: controlled sentences
    mod = load_model_module()
    model = mod.FakeModel() if args.backend == "fake" else mod.RealModel(batch_size=16)
    probs = model.predict([s for _, _, s, _ in CONTROLLED])
    ctl = []
    for (kind, lg, s, exp), p in zip(CONTROLLED, probs):
        lab = LABELS[int(np.argmax(p))]
        ctl.append({"case": kind, "lang": lg, "sentence": s, "expected": " / ".join(exp), "model": lab, "score": round(float(p[2] - p[0]), 2), "ok": lab in exp})
    R["controlled"] = {"passed": sum(c["ok"] for c in ctl), "total": len(ctl), "rows": ctl}

    # ---- real examples
    clear = clear.assign(_truth=truth_bin)
    txt = clear["text"].fillna("").astype(str)
    clear = clear[txt.str.len().between(25, 260)]
    ok_pos = clear[(clear["_truth"] == "positive") & (clear["sentiment_binary"] == "positive")].nlargest(3, "sentiment_score")
    ok_neg = clear[(clear["_truth"] == "negative") & (clear["sentiment_binary"] == "negative")].nsmallest(3, "sentiment_score")
    bad = clear[clear["_truth"] != clear["sentiment_binary"]].copy()
    bad["_gap"] = bad["sentiment_score"].abs()
    bad = bad.nlargest(6, "_gap")
    examples = pd.concat([ok_pos, ok_neg, bad])

    # ---- Test 4: human labels (optional)
    human = None
    hs = read_human_labels()
    if hs is not None:
        hs["human_label"] = hs["human_label"].astype(str).str.strip().str.lower().replace({"pos": "positive", "neg": "negative", "neu": "neutral"})
        hs = hs[hs["human_label"].isin(LABELS)].merge(df[["review_id", "sentiment_label", "rating"]].astype({"review_id": str}), on="review_id", how="inner")
        if len(hs) >= 20:
            human = {
                "n": int(len(hs)),
                "accuracy": float(accuracy_score(hs["human_label"], hs["sentiment_label"])),
                "macro_f1": float(f1_score(hs["human_label"], hs["sentiment_label"], labels=LABELS, average="macro", zero_division=0)),
                "stars_accuracy": float(accuracy_score(hs["human_label"], star_class(hs["rating"]))),
            }
            R["human"] = human

    # ---- charts as PNG (for slides)
    figs = {
        "1_score_by_stars.png": chart_score_by_star(plt, df),
        "2_confusion_stars.png": chart_confusion(plt, star_class(df["rating"]), df["sentiment_label"], "Model label vs. star rating", "Stars say"),
        "3_languages.png": chart_languages(plt, per_lang) if per_lang else None,
    }
    if human:
        figs["4_confusion_human.png"] = chart_confusion(plt, hs["human_label"], hs["sentiment_label"], "Model label vs. human labels", "Human says")
    for name, f in figs.items():
        if f is not None:
            f.savefig(OUT / name, dpi=220, bbox_inches="tight")

    # ---- PDF
    pdf_path = OUT / "Sentiment_model_validation.pdf"
    wm = args.watermark or ("CODE TEST — NOT REAL RESULTS" if args.backend == "fake" else None)
    n_pages = 0
    with PdfPages(pdf_path) as pdf:
        # page 1: summary
        n_pages += 1
        fig = page(plt)
        fig.text(0.08, 0.93, "Does our sentiment model work?", fontsize=22, fontweight="bold")
        fig.text(0.08, 0.905, "Validation of the FR-5 sentiment analysis · XLM-RoBERTa on Google Maps reviews of Paris cafés", fontsize=10, color=MUTE)
        fig.add_artist(plt.Line2D([0.08, 0.92], [0.89, 0.89], color=ACCENT, lw=1.2))
        verdict = ("Yes." if agree >= 0.85 and monotonic else "Mostly." if agree >= 0.75 else "Only partly.")
        y = paragraph(fig, 0.08, 0.87, f"{verdict} We tested the model in four independent ways. The table below sums them up; each test has its own page with the evidence.", size=11, width=86)
        tiles = [
            (f"{agree:.0%}", "agreement with the stars", f"{R['stars']['n_clear']:,} reviews, 1–2★ vs 4–5★"),
            (f"{rho:.2f}", "rank correlation with the stars", "Spearman; 1 would be perfect"),
            (f"{R['controlled']['passed']}/{R['controlled']['total']}", "controlled sentences passed", "negation, sarcasm, Korean…"),
            ((f"{human['accuracy']:.0%}" if human else "—"), "agreement with a human", (f"{human['n']} reviews labelled by hand" if human else "optional test, not done yet")),
        ]
        for k, (big, lab, sub) in enumerate(tiles):
            x = 0.08 + k * 0.215
            fig.add_artist(plt.Rectangle((x, 0.69), 0.195, 0.125, transform=fig.transFigure, color="#F7F1EF", zorder=0))
            fig.text(x + 0.012, 0.797, big, fontsize=23, fontweight="bold", color=ACCENT, va="top")
            paragraph(fig, x + 0.012, 0.752, lab, width=26, size=8.6, weight="bold", line=1.25)
            paragraph(fig, x + 0.012, 0.722, sub, width=32, size=7.2, color=MUTE, line=1.25)
        y = 0.67
        y = paragraph(fig, 0.08, y, "What the model does", size=12, weight="bold")
        y = paragraph(fig, 0.08, y - 0.004,
                      f"For each of the {len(df):,} reviews with text, the pre-trained multilingual model cardiffnlp/twitter-xlm-roberta-base-sentiment "
                      "(Hugging Face) gives three probabilities: negative, neutral, positive. We keep the most likely class as the label, and "
                      "P(positive) − P(negative) as a score from −1 to +1. The model reads every language directly, without translation.", width=100)
        y = paragraph(fig, 0.08, y - 0.012, "How we tested it", size=12, weight="bold")
        tests = [
            f"1. Stars as a reference. A 1–2★ review should be negative, a 4–5★ review positive. The model never sees the stars, so this is a fair check on {R['stars']['n_clear']:,} real reviews (3★ reviews are left out, they are genuinely mixed).",
            "2. Languages. Our reviews are in several languages. We checked that the agreement is similar in each one.",
            f"3. Controlled sentences. We wrote {len(CONTROLLED)} sentences ourselves, each with a known answer, to test classic traps: negation (\"pas mauvais du tout\"), sarcasm, mixed opinions, Korean.",
            "4. Human labels. A team member labelled reviews by hand without seeing the stars or the model, then we measured how often the model agrees with a person (accuracy, macro-F1)." + ("" if human else " This test is optional and has not been done yet."),
        ]
        for t in tests:
            y = paragraph(fig, 0.095, y - 0.004, t, width=98)
        y = paragraph(fig, 0.08, y - 0.012, "Reading the numbers honestly", size=12, weight="bold")
        y = paragraph(fig, 0.08, y - 0.004,
                      f"Most reviews are positive, so a lazy model that always answers \"positive\" would already agree with the stars {base:.0%} of the time. "
                      f"Ours reaches {agree:.0%}, and, more importantly, it catches {neg_recall:.0%} of the negative (1–2★) reviews, which a lazy model would miss entirely. "
                      "Stars are not a perfect reference either: some people give 4★ and still complain about the price.", width=100)
        footer(fig, n_pages, wm)
        pdf.savefig(fig)
        plt.close(fig)

        # page 2: stars
        n_pages += 1
        fig = page(plt, "Test 1 · The model agrees with the stars")
        embed(fig, figs["1_score_by_stars.png"], [0.08, 0.60, 0.84, 0.31])
        mtxt = ", ".join(f"{k}★ {v:+.2f}" for k, v in means.items())
        y = paragraph(fig, 0.08, 0.585, f"Average score per star rating: {mtxt}. " + (
            "The average rises at every step: the model orders the reviews the same way the reviewers do." if monotonic
            else "The average does not rise at every step; see the examples page for why."), width=100)
        y = paragraph(fig, 0.08, y - 0.004, f"Correlation between the score and the stars: Pearson {corr:.2f}, Spearman {rho:.2f}.", width=100)
        embed(fig, figs["2_confusion_stars.png"], [0.2, 0.12, 0.6, 0.36])
        paragraph(fig, 0.08, 0.115, "How to read the grid: each row is a group of reviews by stars (1–2★ = negative, 3★ = neutral, 4–5★ = positive); each cell shows how the model labelled that group. "
                  "A good model puts most of each row on the diagonal. The neutral row is always the hardest: a 3★ review is often a mix of good and bad.", width=100, size=8.5, color=MUTE)
        footer(fig, n_pages, wm)
        pdf.savefig(fig)
        plt.close(fig)

        # page 3: languages + controlled sentences
        n_pages += 1
        fig = page(plt, "Tests 2 and 3 · Languages and traps")
        if figs["3_languages.png"] is not None:
            embed(fig, figs["3_languages.png"], [0.08, 0.70, 0.84, 0.21])
        y = paragraph(fig, 0.08, 0.68, f"Controlled sentences: {R['controlled']['passed']} of {R['controlled']['total']} passed. "
                      "We wrote these sentences before running the model; \"expected\" lists every answer we accept.", width=100, weight="bold")
        rows = [[c["case"], c["lang"], c["sentence"], c["expected"], c["model"], f"{c['score']:+.2f}", "✓" if c["ok"] else "✗"] for c in ctl]
        table(fig, y - 0.01, rows, ["Case", "Lang", "Sentence", "Expected", "Model", "Score", ""],
              [0.11, 0.05, 0.37, 0.14, 0.09, 0.06, 0.02], [14, 4, 52, 18, 10, 6, 2],
              color_col={4: lambda v: LABEL_COLOR.get(v, INK), 6: lambda v: POS if v == "✓" else NEG})
        footer(fig, n_pages, wm)
        pdf.savefig(fig)
        plt.close(fig)

        # page 4: real examples
        n_pages += 1
        fig = page(plt, "Real reviews · what it gets right, and where it fails")
        y = paragraph(fig, 0.08, 0.905, "The first six are the clearest successes; the last six are the strongest disagreements with the stars. "
                      "Reading the failures is part of the proof: they show where the limits are (mixed opinions, sarcasm, or stars that do not match the text).", width=100, color=MUTE)
        rows = []
        for _, r in examples.iterrows():
            t = " ".join(str(r["text"]).split())
            rows.append([f"{int(r['rating'])}★", t[:240] + ("…" if len(t) > 240 else ""), r["sentiment_label"], f"{r['sentiment_score']:+.2f}",
                         "agrees" if r["sentiment_binary"] == r["_truth"] else "disagrees"])
        table(fig, y - 0.012, rows, ["Stars", "Review (original text)", "Model", "Score", "vs stars"],
              [0.06, 0.55, 0.1, 0.07, 0.08], [5, 78, 10, 6, 10],
              color_col={2: lambda v: LABEL_COLOR.get(v, INK), 4: lambda v: POS if v == "agrees" else NEG}, size=8)
        footer(fig, n_pages, wm)
        pdf.savefig(fig)
        plt.close(fig)

        # page 5: human labels, if done
        if human:
            n_pages += 1
            fig = page(plt, "Test 4 · The model agrees with people")
            y = paragraph(fig, 0.08, 0.9, f"{human['n']} reviews, chosen at random (the same number for each star rating), were labelled by hand by a team member "
                          "without seeing the stars or the model's answer.", width=100)
            y = paragraph(fig, 0.08, y - 0.006, f"Accuracy {human['accuracy']:.0%} · macro-F1 {human['macro_f1']:.2f}. For comparison, guessing from the stars alone gives "
                          f"{human['stars_accuracy']:.0%} on the same reviews.", width=100, weight="bold")
            embed(fig, figs["4_confusion_human.png"], [0.2, 0.45, 0.6, 0.38])
            footer(fig, n_pages, wm)
            pdf.savefig(fig)
            plt.close(fig)

    (OUT / "results.json").write_text(json.dumps(R, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nWrote {pdf_path.relative_to(ROOT)} ({n_pages} pages) and the charts as PNG in {OUT.relative_to(ROOT)}/")
    print(f"Agreement with stars: {agree:.1%} (always-positive baseline {base:.1%}) · Spearman {rho:.2f} · "
          f"controlled sentences {R['controlled']['passed']}/{R['controlled']['total']}" + (f" · human labels {human['accuracy']:.1%}" if human else ""))


if __name__ == "__main__":
    main()
