"""Draws clauses to label by hand, to measure the real precision / recall of the ABSA.

Run AFTER 02_absa.py. Writes data/processed/validation/labeling_sheet.csv with two empty columns to fill in:
  human_aspect    one of: price, taste, coffee_quality, service, waiting_time, atmosphere, comfort, variety, takeaway, none
  human_sentiment one of: negative, neutral, positive, none   (use none when human_aspect is none)
Then run evaluate_absa.py. Labelling ~250 rows takes about 30-40 minutes.

Sample: 200 clauses the model attached to an aspect (stratified by aspect) + 50 clauses it left unassigned,
so that both precision (are assigned clauses right?) and recall (are we missing aspects?) can be estimated.
The model's own answer is hidden in the sheet (columns prefixed 'model_' are at the far right) to avoid anchoring.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from aspects import ASPECTS, split_clauses  # noqa: E402
from common import load_config, path_of  # noqa: E402

N_ASSIGNED, N_UNASSIGNED, SEED = 200, 50, 42


def main() -> None:
    config = load_config()
    processed = path_of(config, "processed_dir")
    mentions = pd.read_csv(processed / "aspect_mentions.csv")
    reviews = pd.read_csv(processed / "reviews_clean.csv", low_memory=False)
    reviews = reviews[reviews["analyzable"]]

    per_aspect = max(N_ASSIGNED // len(ASPECTS), 1)
    parts = [g.sample(min(len(g), per_aspect), random_state=SEED) for _, g in mentions.groupby("aspect")]
    assigned = pd.concat(parts)
    assigned = assigned.assign(group="assigned")

    keys = set(zip(mentions["review_id"], mentions["clause_idx"]))
    pool = [(rid, k, c) for rid, text in zip(reviews["review_id"], reviews["text"]) for k, c in enumerate(split_clauses(str(text)))
            if (rid, k) not in keys]
    unassigned = pd.DataFrame(pool, columns=["review_id", "clause_idx", "clause"]).sample(N_UNASSIGNED, random_state=SEED)
    unassigned = unassigned.assign(group="unassigned", aspect="none", sentiment="none")

    sheet = pd.concat([assigned, unassigned]).sample(frac=1, random_state=SEED).reset_index(drop=True)
    out = sheet[["review_id", "clause_idx", "clause"]].copy()
    out["human_aspect"] = ""
    out["human_sentiment"] = ""
    out["model_aspect"] = sheet["aspect"]
    out["model_sentiment"] = sheet["sentiment"]
    target = processed / "validation"
    target.mkdir(exist_ok=True)
    out.to_csv(target / "labeling_sheet.csv", index=False, encoding="utf-8-sig")
    print(f"Wrote {len(out)} rows to {target / 'labeling_sheet.csv'}. Fill human_aspect and human_sentiment, then run evaluate_absa.py")


if __name__ == "__main__":
    main()
