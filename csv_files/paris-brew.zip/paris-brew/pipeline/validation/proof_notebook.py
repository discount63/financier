"""Step-by-step proof that the review filter and the sentiment model work, as a PDF "lab notebook".

Each step shows: what we test, the exact code that runs, and what the terminal printed when it ran.
Every check prints PASS or FAIL; the last page lists them all.

Run from the project folder, with the virtual environment active:
  pip install matplotlib                                  (once)
  python3 pipeline/validation/proof_notebook.py

Output: docs/Proof_notebook_filter_and_model.pdf      (takes 1-3 minutes: the models run for real)
        docs/proof_notebook_output.txt                (the same terminal output, as plain text)
"""
from __future__ import annotations

import argparse
import contextlib
import importlib.util
import inspect
import io
import sys
import textwrap
import time
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "pipeline"))
from aspects import ASPECTS, NOISE_ANCHORS, split_clauses  # noqa: E402
from common import load_config  # noqa: E402

CONFIG = load_config()
PROCESSED = ROOT / "data" / "processed"
BACKEND = "real"          # set from the command line; "fake" only tests this script's layout
CHECKS: list[tuple[str, bool]] = []
CTX: dict = {}            # objects shared between steps (models, data)


def load(name: str, file: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / "pipeline" / file)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def make_sentiment_model():
    mod = load("review_sentiment", "05_review_sentiment.py")
    return mod, (mod.FakeModel() if BACKEND == "fake" else mod.RealModel(batch_size=16))


def make_embedder(absa_mod):
    return absa_mod.FakeBackend() if BACKEND == "fake" else absa_mod.RealBackend(CONFIG)


def check(condition, message: str) -> None:
    """Records a test and prints PASS or FAIL."""
    ok = bool(condition)
    CHECKS.append((message, ok))
    print(("PASS  " if ok else "FAIL  ") + message)


# ============================================================ the steps (their code is printed in the PDF)

def step_environment():
    import platform
    import torch
    import transformers
    device = "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu")
    print("Python        ", platform.python_version())
    print("PyTorch       ", torch.__version__)
    print("Transformers  ", transformers.__version__)
    print("Device        ", device, "(mps = Apple GPU)")
    print("Sentiment     ", CONFIG["absa"]["sentiment_model"])
    print("Embeddings    ", CONFIG["absa"]["embedding_model"])


def step_raw_files():
    raw = ROOT / "data" / "raw" / "reviews"
    total = 0
    for f in sorted(raw.iterdir()):
        if f.suffix == ".csv":
            n = len(pd.read_csv(f, low_memory=False))
        elif f.suffix == ".json":
            n = len(pd.read_json(f))
        else:
            continue
        total += n
        print(f"{f.name:<24} {n:>6,} rows")
    print(f"{'TOTAL':<24} {total:>6,} rows")
    check(total > 0, "the three Apify exports are found and readable")


def step_filter_rules():
    df = pd.read_csv(PROCESSED / "reviews_clean.csv", low_memory=False)
    scope = CONFIG["scope"]
    text = df["text"].fillna("").str.strip()
    # the three rules of the filter, written again independently of the pipeline
    rule_category = df["segment"].isin(scope["include_segments"])      # café, bar-brasserie or restaurant
    rule_has_text = text.str.len() >= 2                                # not a stars-only review
    rule_absa = df["language"].isin(scope["absa_languages"]) & (text.str.len() >= scope["min_text_chars"])
    kept = rule_category & rule_has_text
    print(f"Unique reviews after de-duplication   {len(df):>6,}")
    print(f"  removed: not a café / restaurant    {(~rule_category).sum():>6,}")
    print(f"  removed: stars only, no text        {(rule_category & ~rule_has_text).sum():>6,}")
    print(f"KEPT for the study                    {kept.sum():>6,}")
    print(f"  of which read by the aspect model   {(kept & rule_absa).sum():>6,}  (French or English, >= {scope['min_text_chars']} characters)")
    print()
    check(df["review_id"].is_unique, "no duplicate review left (every review_id is unique)")
    check((kept == df["in_scope"]).all(), f"our rules give the same decision as the pipeline for all {len(df):,} reviews")
    check(((kept & rule_absa) == df["analyzable"]).all(), "same for the 'read by the aspect model' decision")
    check(df.loc[kept, "arr"].between(1, 20).all(), "every kept review has an arrondissement between 1 and 20")
    CTX["df"] = df


def step_filter_examples():
    df = CTX["df"]
    scope = CONFIG["scope"]

    def decision(row) -> str:
        text = str(row["text"]) if isinstance(row["text"], str) else ""
        if row["segment"] not in scope["include_segments"]:
            return f"REMOVED  category '{row['place_category']}' is not a café/restaurant"
        if len(text.strip()) < 2:
            return "REMOVED  stars only, no text"
        if row["language"] not in scope["absa_languages"]:
            return f"KEPT     counts in ratings; language '{row['language']}' not read by aspect model"
        if len(text.strip()) < scope["min_text_chars"]:
            return "KEPT     counts in ratings; text too short for aspect model"
        return "KEPT     + aspect analysis"

    picks = [
        df[df["analyzable"]].sample(2, random_state=1),
        df[df["segment"] == "excluded"].sample(1, random_state=1),
        df[(df["segment"] != "excluded") & ~df["has_any_text"]].sample(1, random_state=1),
        df[df["in_scope"] & ~df["language"].isin(scope["absa_languages"])].sample(2, random_state=1),
        df[df["in_scope"] & ~df["analyzable"] & df["language"].isin(scope["absa_languages"])].sample(1, random_state=1),
    ]
    for _, row in pd.concat(picks).iterrows():
        text = " ".join(str(row["text"]).split()) if isinstance(row["text"], str) else "(no text)"
        print(f"{int(row['rating'])}*  {row['place_name'][:30]}")
        print(f"    \"{text[:80]}{'...' if len(text) > 80 else ''}\"")
        print(f"    -> {decision(row)}")


def step_clauses():
    example = "Le café est délicieux mais 20 minutes d'attente, et franchement c'est un peu cher."
    print("Review :", example)
    for i, c in enumerate(split_clauses(example), 1):
        print(f"  piece {i}: {c}")
    print()
    df = CTX["df"]
    short = df["text"].fillna("").str.len().between(80, 220)
    pool = df[df["analyzable"] & short & df["text"].str.contains(r"\bmais\b", na=False)]
    pool = pool[pool["text"].map(lambda t: len(split_clauses(t)) >= 3)]   # a review with several ideas
    real = pool.sample(1, random_state=3)
    text = " ".join(str(real["text"].iloc[0]).split())
    print("Real review :", text)
    pieces = split_clauses(text)
    for i, c in enumerate(pieces, 1):
        print(f"  piece {i}: {c}")
    print()
    check(len(split_clauses(example)) == 3, "the example review is cut into 3 pieces")
    check(all(len(c) >= 8 for c in pieces), "no piece shorter than 8 characters")


def step_load_model():
    mod, model = make_sentiment_model()
    CTX["model"] = model
    labels = {int(k): v for k, v in model.model.config.id2label.items()}
    n_params = sum(p.numel() for p in model.model.parameters())
    print("Labels inside the model :", labels)
    print("Order we use            :", mod.LABELS)
    print(f"Parameters              : {n_params / 1e6:.0f} million")
    check(sorted(v.lower()[:3] for v in labels.values()) == ["neg", "neu", "pos"], "the model has exactly 3 classes: negative, neutral, positive")


def step_test_sentences():
    sentences = [
        ("Le café est délicieux et le personnel adorable.", "positive"),
        ("Service très lent, 25 minutes pour un expresso.", "negative"),
        ("Pas mauvais du tout, je reviendrai !", "positive"),
        ("Beaucoup trop cher pour ce que c'est.", "negative"),
        ("The coffee was cold and the staff were rude.", "negative"),
        ("커피가 정말 맛있고 분위기도 좋아요.", "positive"),
        ("Le café est correct, sans plus.", "neutral"),
    ]
    probs = CTX["model"].predict([s for s, _ in sentences])
    labels = ["negative", "neutral", "positive"]
    print(f"{'sentence':<50} {'neg':>5} {'neu':>5} {'pos':>5}  label     expected")
    hits = 0
    for (s, expected), p in zip(sentences, probs):
        label = labels[int(np.argmax(p))]
        hits += label == expected
        print(f"{s[:48]:<50} {p[0]:5.2f} {p[1]:5.2f} {p[2]:5.2f}  {label:<9} {expected}{'' if label == expected else '   <- miss'}")
    print()
    check(np.allclose(probs.sum(axis=1), 1, atol=1e-4), "the 3 probabilities add up to 1 for every sentence")
    check(hits >= 5, f"{hits}/7 test sentences labelled as expected (we require at least 5)")


def step_robustness():
    model = CTX["model"]
    texts = ["Super café, je recommande.", "Horrible, plus jamais.", "Service correct."]
    a = model.predict(texts)
    b = model.predict(texts)
    one_by_one = np.vstack([model.predict([t]) for t in texts])
    long_review = "Le café était bon. " * 400
    c = model.predict([long_review])
    print("Same input twice, largest difference      :", f"{np.abs(a - b).max():.2e}")
    print("Batch vs one by one, largest difference   :", f"{np.abs(a - one_by_one).max():.2e}")
    print("Review of", len(long_review.split()), "words -> probabilities", np.round(c[0], 3))
    score = a[:, 2] - a[:, 0]
    print("Scores (P(pos) - P(neg))                  :", np.round(score, 3))
    print()
    check(np.abs(a - b).max() < 1e-5, "same input gives the same output (deterministic)")
    check(np.abs(a - one_by_one).max() < 1e-3, "result does not depend on the other reviews in the batch")
    check(np.isfinite(c).all(), "a very long review is handled (cut at 256 tokens) without error")
    check(((score >= -1) & (score <= 1)).all(), "every score stays between -1 and +1")


def step_real_reviews():
    df = CTX["df"]
    path = PROCESSED / "reviews_sentiment.csv"
    if path.exists():
        res = pd.read_csv(path, low_memory=False).dropna(subset=["sentiment_score"])
        print(f"Using the full run: {path.name} ({len(res):,} reviews)")
    else:
        res = df[df["in_scope"] & df["has_any_text"]].sample(400, random_state=42).copy()
        p = CTX["model"].predict(res["text"].astype(str).tolist())
        res["sentiment_score"] = p[:, 2] - p[:, 0]
        res["sentiment_binary"] = np.where(res["sentiment_score"] >= 0, "positive", "negative")
        print(f"No full run found: model run now on 400 random real reviews (seed 42)")
    clear = res[res["rating"] != 3]
    truth = np.where(clear["rating"] >= 4, "positive", "negative")
    agree = (clear["sentiment_binary"].values == truth).mean()
    baseline = (truth == "positive").mean()
    caught = (clear.loc[truth == "negative", "sentiment_binary"] == "negative").mean()
    means = res.groupby("rating")["sentiment_score"].mean()
    print(f"Agreement with stars (1-2* vs 4-5*)       : {agree:.1%}")
    print(f"'Always positive' lazy baseline           : {baseline:.1%}")
    print(f"Negative (1-2*) reviews caught            : {caught:.1%}")
    print("Mean score per star rating                :", "  ".join(f"{int(k)}*: {v:+.2f}" for k, v in means.items()))
    print()
    check(agree > baseline, "the model beats the lazy 'always positive' baseline")
    check(caught >= 0.7, "at least 70% of the negative reviews are detected")
    check(all(means.iloc[i] < means.iloc[i + 1] for i in range(len(means) - 1)), "the mean score rises at every star")


def step_aspects():
    absa_mod = load("absa", "02_absa.py")
    backend = make_embedder(absa_mod)
    names, anchors, _, noise = absa_mod.anchor_matrix(backend)
    clauses = [
        "c'est un peu cher pour un simple expresso",
        "on a attendu vingt minutes avant d'être servis",
        "le serveur était adorable et souriant",
        "the cappuccino was perfectly made",
        "nous sommes venus avec des amis samedi",
    ]
    expected = ["price", "waiting_time", "service", "coffee_quality", None]
    emb = backend.embed(clauses)
    picked = absa_mod.assign_aspects(emb @ anchors.T, names, emb @ noise.T, CONFIG)
    print(f"threshold = {CONFIG['absa']['aspect_threshold']}, margin over off-topic = {CONFIG['absa']['aspect_margin']}")
    hits = 0
    for c, p, e, sims in zip(clauses, picked, expected, emb @ anchors.T):
        got = p[0][0] if p else None
        hits += got == e
        best = float(sims.max())
        print(f"{c[:46]:<47} best sim {best:.2f} -> {got or 'no aspect (ignored)'}")
    print()
    check(hits >= 4, f"{hits}/5 pieces matched to the expected aspect (we require at least 4)")


STEPS = [
    (step_environment, "Environment",
     "Which versions and which hardware ran this notebook. Anyone can re-run it and should get the same results."),
    (step_raw_files, "Raw data: the three Apify exports",
     "Counts the rows in the files we collected from Google Maps, before any cleaning."),
    (step_filter_rules, "The filter: rules and counts",
     "We rewrite the filter's three rules independently and check that they give exactly the same decision as the pipeline, review by review."),
    (step_filter_examples, "The filter in action: real reviews",
     "Real reviews picked at random, one for each case, with the decision the filter takes and why."),
    (step_clauses, "Cutting a review into pieces",
     "Before the aspect analysis, each review is cut into pieces so that one review can be positive on taste and negative on price."),
    (step_load_model, "Loading the sentiment model (XLM-RoBERTa)",
     "Downloads (first time only) and loads the pre-trained model from Hugging Face, then checks its classes."),
    (step_test_sentences, "Test sentences with a known answer",
     "Sentences written by us, each with an expected answer, including a negation and a Korean sentence."),
    (step_robustness, "Technical checks on the model",
     "The same input must always give the same output, results must not depend on the batch, and long reviews must not crash."),
    (step_real_reviews, "The model on real reviews, checked against the stars",
     "The model never sees the stars, so they act as an answer key. We also compare with a lazy model that always says 'positive'."),
    (step_aspects, "Matching pieces to topics (MiniLM embeddings)",
     "Each piece is compared with example sentences for each of the 9 topics. Off-topic pieces must be ignored."),
]


DATA_STEPS = (step_raw_files, step_filter_rules, step_filter_examples, step_clauses)


# ============================================================ PDF layout

A4 = (8.27, 11.69)
INK, MUTE, ACCENT = "#2B1A1D", "#7F6B70", "#B5214F"
CODE_BG, TERM_BG, TERM_FG = "#F6F1EF", "#1E1A1C", "#EDE6E3"


def visual_width(s: str) -> int:
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in s)


def hard_wrap(line: str, width: int) -> list[str]:
    out, cur = [], ""
    for ch in line:
        if visual_width(cur + ch) > width:
            out.append(cur)
            cur = "    " + ch
        else:
            cur += ch
    out.append(cur)
    return out


def printable(s: str) -> str:
    """Drops emoji and other pictograms that no PDF font can draw."""
    return "".join(ch for ch in s if ord(ch) < 0x10000 and (unicodedata.category(ch) != "So" or ch in "✓✗★"))


class Doc:
    mono = ["DejaVu Sans Mono"]

    def __init__(self, plt, pdf):
        self.plt, self.pdf, self.fig, self.y, self.n = plt, pdf, None, 0, 0

    def new_page(self):
        if self.fig is not None:
            self.finish_page()
        self.fig = self.plt.figure(figsize=A4)
        self.n += 1
        self.y = 0.94

    def finish_page(self):
        self.fig.text(0.08, 0.03, "Financier · proof notebook · filter and sentiment model", fontsize=7, color=MUTE)
        self.fig.text(0.92, 0.03, str(self.n), fontsize=7, color=MUTE, ha="right")
        self.pdf.savefig(self.fig)
        self.plt.close(self.fig)
        self.fig = None

    def need(self, h):
        if self.fig is None or self.y - h < 0.06:
            self.new_page()

    def text(self, s, size=9.5, color=INK, weight="normal", width=100, gap=0.004, family=None):
        step = size * 1.42 / 72 / A4[1]
        for line in (textwrap.wrap(s, width) or [""]):
            self.need(step)
            self.fig.text(0.08, self.y, line, fontsize=size, color=color, fontweight=weight, va="top", family=family)
            self.y -= step
        self.y -= gap

    def block(self, lines, bg, fg, size=7.2, colorize=False):
        step = size * 1.45 / 72 / A4[1]
        wrapped = [w for ln in lines for w in hard_wrap(ln.expandtabs(4), 112)]
        i = 0
        while i < len(wrapped):
            self.need(step * 2 + 0.01)
            room = int((self.y - 0.06 - 0.012) / step)
            chunk = wrapped[i:i + max(room, 1)]
            h = len(chunk) * step + 0.012
            self.fig.add_artist(self.plt.Rectangle((0.075, self.y - h), 0.85, h, transform=self.fig.transFigure, color=bg, zorder=0))
            yy = self.y - 0.006
            for ln in chunk:
                c = fg
                if colorize and ln.startswith("PASS"):
                    c = "#7BD389"
                elif colorize and ln.startswith("FAIL"):
                    c = "#FF7B72"
                self.fig.text(0.085, yy, printable(ln), fontsize=size, color=c, va="top", family=self.mono)
                yy -= step
            self.y -= h + 0.008
            i += len(chunk)


def source_of(func) -> list[str]:
    lines = inspect.getsource(func).splitlines()
    body = textwrap.dedent("\n".join(lines[1:])).splitlines()     # drop the "def" line
    return [ln for ln in body]


def main() -> None:
    global BACKEND
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--backend", choices=["real", "fake"], default="real", help=argparse.SUPPRESS)
    ap.add_argument("--data-only", action="store_true", help="only the data and filter steps (no model download)")
    args = ap.parse_args()
    BACKEND = args.backend
    steps = [s for s in STEPS if not args.data_only or s[0] in DATA_STEPS]

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from matplotlib.backends.backend_pdf import PdfPages
    installed = {f.name for f in font_manager.fontManager.ttflist}
    cjk = [f for f in ["Apple SD Gothic Neo", "AppleGothic", "Noto Sans CJK KR", "Noto Sans CJK JP", "Noto Sans CJK TC"] if f in installed]
    plt.rcParams["font.family"] = [f for f in ["Helvetica Neue", "Arial"] if f in installed] + cjk + ["DejaVu Sans"]
    Doc.mono = [f for f in ["Menlo", "Monaco"] if f in installed] + ["DejaVu Sans Mono"] + cjk

    results = []
    log = io.StringIO()
    for func, title, why in steps:
        print(f"Running: {title}", flush=True)
        buf = io.StringIO()
        start = time.time()
        try:
            with contextlib.redirect_stdout(buf):
                func()
        except Exception as e:  # a step that crashes is reported as a failed check, the notebook goes on
            buf.write(f"\nERROR: {type(e).__name__}: {e}\n")
            CHECKS.append((f"{title}: step ran without error", False))
        out = buf.getvalue().rstrip("\n")
        results.append((func, title, why, out, time.time() - start))
        log.write(f"\n=== {title} ===\n{out}\n")
        print(textwrap.indent(out, "   "), flush=True)

    docs = ROOT / "docs"
    docs.mkdir(exist_ok=True)
    (docs / "proof_notebook_output.txt").write_text(log.getvalue(), encoding="utf-8")
    pdf_path = docs / ("Proof_notebook_filter_only.pdf" if args.data_only else "Proof_notebook_filter_and_model.pdf")
    passed = sum(ok for _, ok in CHECKS)
    with PdfPages(pdf_path) as pdf:
        d = Doc(plt, pdf)
        d.new_page()
        d.text("Proof notebook: the review filter and the sentiment model", size=17, weight="bold", width=60)
        d.text(f"Financier · Applied Data Science · Sookmyung Women's University · generated {time.strftime('%Y-%m-%d %H:%M')}", size=8.5, color=MUTE)
        d.y -= 0.01
        d.text(f"Result: {passed} of {len(CHECKS)} checks passed.", size=12, weight="bold", color=ACCENT if passed == len(CHECKS) else "#C23A32")
        d.text("How to read this document. Each step shows what we test, then the exact Python code that ran (light box), "
               "then what the terminal printed when it ran (dark box). Lines starting with PASS or FAIL are automatic checks. "
               "Nothing in the dark boxes was typed by hand: it is the real output of pipeline/validation/proof_notebook.py, "
               "which anyone can re-run.", width=105)
        if args.data_only:
            d.y -= 0.006
            d.text("Partial version: data and filter only", size=11, weight="bold", color="#C23A32")
            d.text("The main point of this notebook is to show that the sentiment model, XLM-RoBERTa, gives correct answers. "
                   "This version does not contain that part yet. It only shows the steps that check the data and the filter, "
                   "which need nothing but Python and our review files.", width=105)
            d.text("Why: the model steps need to download two pre-trained models from Hugging Face (XLM-RoBERTa and MiniLM, about "
                   "1.5 GB). The computer that produced this version could not reach Hugging Face. We did not replace the missing "
                   "results with invented ones: a proof must show the real output of the real model.", width=105)
            d.text("The full version is produced by running the same script on a computer with internet access:", width=105)
            d.block(["python3 pipeline/validation/proof_notebook.py"], CODE_BG, INK)
            d.text("It adds these steps, which test the model itself:", width=105)
            missing = [f"- {title}: {why}" for func, title, why in STEPS if func not in DATA_STEPS]
            for m in missing:
                d.text(m, width=103, size=9)
        if BACKEND == "fake":
            d.text("LAYOUT TEST: a fake model was used, the model results are meaningless.", weight="bold", color="#C23A32")
        d.y -= 0.006
        d.text("All checks", size=11, weight="bold")
        d.block([("PASS  " if ok else "FAIL  ") + m for m, ok in CHECKS], TERM_BG, TERM_FG, colorize=True)
        for i, (func, title, why, out, secs) in enumerate(results, 1):
            d.need(0.12)
            d.y -= 0.012
            d.text(f"Step {i} · {title}", size=12.5, weight="bold", color=ACCENT, width=80)
            d.text(why, width=105, color=INK)
            d.text("Code", size=8, weight="bold", color=MUTE, gap=0.002)
            d.block(source_of(func), CODE_BG, INK)
            d.text(f"Terminal output ({secs:.1f} s)", size=8, weight="bold", color=MUTE, gap=0.002)
            d.block(out.splitlines() or ["(no output)"], TERM_BG, TERM_FG, colorize=True)
        d.finish_page()
    print(f"\n{passed}/{len(CHECKS)} checks passed. Wrote {pdf_path.relative_to(ROOT)} and docs/proof_notebook_output.txt")


if __name__ == "__main__":
    main()
