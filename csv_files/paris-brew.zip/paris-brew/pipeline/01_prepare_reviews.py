"""Étape 1 — Fusionner, dédoublonner et qualifier les avis Google Maps (exports Apify).

Entrée  : tous les fichiers .csv / .json de data/raw/reviews/
Sorties : data/processed/reviews_clean.csv   (un avis par ligne, standardisé)
          data/processed/venues.csv           (un établissement par ligne)
          data/processed/audit.json           (chiffres d'audit : ce qui est gardé, écarté, et pourquoi)

Usage :  python3 pipeline/01_prepare_reviews.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import ROOT, arrondissement_from_address, load_config, normalize, path_of, write_json  # noqa: E402

COLUMN_MAP = {
    "reviewId": "review_id",
    "placeId": "place_id",
    "placeName": "place_name",
    "placeCategory": "place_category",
    "placeAddress": "place_address",
    "placeLatitude": "lat",
    "placeLongitude": "lon",
    "placeRating": "place_rating",
    "placeTotalReviews": "place_total_reviews",
    "rating": "rating",
    "text": "text",
    "textTranslated": "text_translated",
    "language": "language",
    "publishedAt": "published_at",
    "likesCount": "likes",
    "ownerResponseText": "owner_response",
    "inputQuery": "input_query",
    "subRatings.Service": "sub_service",
    "subRatings.Ambiance": "sub_ambiance",
    "subRatings.Cuisine": "sub_food",
    "reviewContext.Prix par personne": "ctx_price_band",
    "reviewContext.Niveau de bruit": "ctx_noise",
    "reviewContext.Temps d’attente": "ctx_wait",
    "reviewContext.Type de commande": "ctx_order_type",
    "reviewContext.Type de repas": "ctx_meal",
}

# Catégories Google Maps -> segment d'analyse.
EXCLUDED_WORDS = ("musee", "salle de spectacle", "centre commercial", "siege social", "association", "cybercafe")
CORE_PREFIXES = ("cafe", "salon de the", "torrefacteur", "coffee")
ADJACENT_WORDS = ("brunch", "brasserie", "bar", "bistro", "pub", "cafeteria", "restauration rapide",
                  "boulangerie", "patisserie", "magasin de the", "saladerie", "traiteur", "glacier", "chicha")


def segment_of(category: object) -> str:
    cat = normalize(category)
    if not cat:
        return "unknown"
    if any(word in cat for word in EXCLUDED_WORDS):
        return "excluded"
    if cat.startswith(CORE_PREFIXES) and not cat.startswith("cafeteria"):
        return "core"
    if any(word in cat for word in ADJACENT_WORDS):
        return "adjacent"
    if "restaurant" in cat:
        return "restaurant"
    return "excluded"


def read_export(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".json":
        with open(path, encoding="utf-8") as handle:
            frame = pd.json_normalize(json.load(handle))
    else:
        frame = pd.read_csv(path, low_memory=False)
    frame.columns = [str(col).replace("/", ".") for col in frame.columns]
    frame["source_file"] = path.name
    return frame


def standardize(frame: pd.DataFrame) -> pd.DataFrame:
    keep = {src: dst for src, dst in COLUMN_MAP.items() if src in frame.columns}
    out = frame[list(keep) + ["source_file"]].rename(columns=keep).copy()
    for dst in COLUMN_MAP.values():
        if dst not in out.columns:
            out[dst] = pd.NA
    return out


def price_band_midpoint(value: object) -> float | None:
    """« 10–20 € » -> 15.0 (milieu de la tranche déclarée par l'auteur de l'avis)."""
    text = "" if value is None or value is pd.NA else str(value).replace("\xa0", " ")
    digits = [int(tok) for tok in __import__("re").findall(r"\d+", text)]
    if "+" in text and digits:
        return float(digits[0])
    if len(digits) >= 2:
        return (digits[0] + digits[1]) / 2
    return None


def main() -> None:
    config = load_config()
    raw_dir = path_of(config, "raw_reviews_dir")
    files = sorted([*raw_dir.glob("*.csv"), *raw_dir.glob("*.json")])
    if not files:
        raise SystemExit(f"Aucun export trouvé dans {raw_dir}. Déposez-y vos fichiers Apify (.csv ou .json).")

    frames = [standardize(read_export(path)) for path in files]
    merged = pd.concat(frames, ignore_index=True)
    audit: dict = {"files": {p.name: int(len(f)) for p, f in zip(files, frames)}, "rows_read": int(len(merged))}

    merged["review_id"] = merged["review_id"].astype("string").str.strip()
    merged = merged[merged["review_id"].notna() & (merged["review_id"] != "")]
    before = len(merged)
    merged = merged.drop_duplicates("review_id", keep="first")
    audit["duplicate_review_ids_removed"] = int(before - len(merged))

    merged["text"] = merged["text"].fillna("").astype(str).str.strip()
    # Les exports JSON notent « N/A » quand l'avis n'a qu'une note, sans texte.
    merged.loc[merged["text"].str.upper().isin(["N/A", "NA", "NONE", "NULL"]), "text"] = ""
    before = len(merged)
    # Copier-coller exact (≥ 40 caractères) du même établissement : doublon probable entre deux scrapings.
    # Les avis courts (« Top », « Super ») ne sont PAS dédoublonnés : plusieurs clients peuvent écrire la même chose.
    long_dup = merged["text"].str.len().ge(40) & merged.duplicated(["place_id", "text", "rating"], keep="first")
    merged = merged[~long_dup]
    audit["duplicate_long_texts_removed"] = int(before - len(merged))
    audit["rating_only_reviews_excluded_from_stats"] = int((merged["text"].str.len() < 2).sum())

    merged["arr"] = merged["place_address"].map(arrondissement_from_address)
    audit["rows_without_paris_postcode"] = int(merged["arr"].isna().sum())
    merged = merged[merged["arr"].notna()].copy()
    merged["arr"] = merged["arr"].astype(int)

    merged["segment"] = merged["place_category"].map(segment_of)
    merged["is_chain"] = merged["place_name"].map(normalize).apply(
        lambda name: any(chain in name for chain in config["scope"]["chains"])
    )
    merged["rating"] = pd.to_numeric(merged["rating"], errors="coerce")
    merged = merged[merged["rating"].between(1, 5)].copy()
    merged["published_at"] = pd.to_datetime(merged["published_at"], errors="coerce", utc=True)
    merged["has_text"] = merged["text"].str.len() >= config["scope"]["min_text_chars"]
    # Base commune des statistiques : avis avec un texte. Les exports ne contiennent pas tous les avis « note seule »
    # (premier export : textes uniquement) ; les inclure pour certains arrondissements seulement fausserait les comparaisons.
    merged["has_any_text"] = merged["text"].str.len() >= 2
    merged["language"] = merged["language"].fillna("und").astype(str)
    merged["analyzable"] = (
        merged["has_text"]
        & merged["language"].isin(config["scope"]["absa_languages"])
        & merged["segment"].isin(config["scope"]["include_segments"])
    )
    merged["in_scope"] = merged["segment"].isin(config["scope"]["include_segments"]) & merged["has_any_text"]
    merged["price_band_eur"] = merged["ctx_price_band"].map(price_band_midpoint)
    merged["owner_replied"] = merged["owner_response"].notna() & (merged["owner_response"].astype(str).str.strip() != "")

    # Établissements dont l'adresse ne correspond pas à la requête (contrôle qualité).
    queries_path = ROOT / "data" / "external" / "apify_bulk_queries.csv"
    mismatches = 0
    if queries_path.exists():
        expected = pd.read_csv(queries_path)
        lookup = dict(zip(expected["search_query"], expected["expected_arrondissement"]))
        merged["expected_arr"] = merged["input_query"].map(lookup)
        mismatches = int(
            (merged.drop_duplicates("place_id")["expected_arr"].notna()
             & (merged.drop_duplicates("place_id")["expected_arr"] != merged.drop_duplicates("place_id")["arr"])).sum()
        )
    audit["venues_whose_address_differs_from_query"] = mismatches

    audit.update(
        unique_reviews_paris=int(len(merged)),
        unique_venues_paris=int(merged["place_id"].nunique()),
        by_segment={k: int(v) for k, v in merged["segment"].value_counts().items()},
        venues_by_segment={k: int(v) for k, v in merged.drop_duplicates("place_id")["segment"].value_counts().items()},
        reviews_with_text=int(merged["has_any_text"].sum()),
        reviews_in_scope=int(merged["in_scope"].sum()),
        reviews_analyzable_by_absa=int(merged["analyzable"].sum()),
        languages_in_scope={k: int(v) for k, v in merged.loc[merged["in_scope"], "language"].value_counts().head(8).items()},
        reviews_in_scope_by_arr={int(k): int(v) for k, v in merged.loc[merged["in_scope"]].groupby("arr").size().items()},
        venues_in_scope_by_arr={int(k): int(v) for k, v in merged.loc[merged["in_scope"]].groupby("arr")["place_id"].nunique().items()},
        chain_reviews_in_scope=int((merged["in_scope"] & merged["is_chain"]).sum()),
        review_date_min=str(merged["published_at"].min())[:10],
        review_date_max=str(merged["published_at"].max())[:10],
        share_2026=float((merged["published_at"].dt.year == 2026).mean()),
        max_reviews_per_venue=int(merged.groupby("place_id").size().max()),
    )

    out_dir = path_of(config, "processed_dir")
    out_dir.mkdir(parents=True, exist_ok=True)
    merged.drop(columns=["owner_response"]).to_csv(out_dir / "reviews_clean.csv", index=False, encoding="utf-8")

    venues = (
        merged.groupby("place_id")
        .agg(
            place_name=("place_name", "first"), place_category=("place_category", "first"),
            place_address=("place_address", "first"), arr=("arr", "first"), lat=("lat", "first"),
            lon=("lon", "first"), segment=("segment", "first"), is_chain=("is_chain", "first"),
            place_rating=("place_rating", "first"), place_total_reviews=("place_total_reviews", "first"),
            reviews_collected=("review_id", "count"), mean_rating_collected=("rating", "mean"),
        )
        .reset_index()
    )
    venues.to_csv(out_dir / "venues.csv", index=False, encoding="utf-8")
    write_json(out_dir / "audit.json", audit)

    print(json.dumps(audit, ensure_ascii=False, indent=2))
    print(f"\nWritten: {out_dir / 'reviews_clean.csv'}  ({len(merged)} reviews)")


if __name__ == "__main__":
    main()
