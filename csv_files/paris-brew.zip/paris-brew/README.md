# Financier · 파이낭시에

**Where in Paris could a Korean-style €1.50 café find its customers?**
**한국식 1.50유로 카페는 파리의 어느 구에서 손님을 찾을 수 있을까?**

Applied Data Science · Sookmyung Women's University
A project by Zayd El Khiri, 강나윤, 남하린 & 이예지

An interactive website (animated intro, map of the 20 arrondissements, customer-aspect analysis, top 3, profit simulator, method page) built from 8,377 Google Maps reviews and public open data, with a Python pipeline behind it. No value is invented: anything missing is shown as "Not available".

---

## Quick start: open the website · 빠른 시작: 웹사이트 열기

You only need **Node.js** (LTS version, from nodejs.org) and **VS Code**.
**Node.js**(nodejs.org에서 LTS 버전)와 **VS Code**만 있으면 됩니다.

1. Get the project / 프로젝트 받기
   - With GitHub Desktop or VS Code: **Clone** this repository.
     GitHub Desktop 또는 VS Code에서 이 저장소를 **Clone** 하세요.
   - Or on this GitHub page: green **Code** button → **Download ZIP**, then unzip.
     또는 이 페이지에서 초록색 **Code** 버튼 → **Download ZIP** → 압축 풀기.
2. In VS Code: **File → Open Folder** → choose the `paris-brew` folder.
   VS Code에서 **File → Open Folder** → `paris-brew` 폴더 선택.
3. Open a terminal (**Terminal → New Terminal**) and paste:
   터미널을 열고 (**Terminal → New Terminal**) 아래를 붙여넣으세요:

   ```bash
   cd web
   npm install
   npm run dev
   ```

4. Open the address shown, usually **http://localhost:5173**.
   표시된 주소를 여세요 (보통 **http://localhost:5173**).

`npm install` is only needed the first time. Next time: `cd web && npm run dev`.
`npm install`은 처음 한 번만 필요합니다. 다음부터는 `cd web && npm run dev`.

Stop the site with **Ctrl + C** in the terminal. / 터미널에서 **Ctrl + C**로 종료합니다.

---

## Editing the site · 사이트 수정하기

All the website code is in `web/src`. With `npm run dev` running, every save (**Cmd + S**) updates the page instantly.
웹사이트 코드는 모두 `web/src`에 있습니다. `npm run dev` 실행 중에는 저장(**Cmd + S**)할 때마다 페이지가 바로 바뀝니다.

| What · 내용 | File · 파일 |
|---|---|
| Animated stories in the intro · 인트로 애니메이션 | `web/src/components/CoffeeFilm.tsx` |
| Start screen with the logo · 로고 시작 화면 | `web/src/components/Intro.tsx` |
| Map · 지도 | `web/src/components/MapView.tsx`, `MapSection.tsx` |
| District detail panel · 구 상세 패널 | `web/src/components/DistrictPanel.tsx`, `DistrictScene.tsx` |
| Profit simulator · 수익 시뮬레이터 | `web/src/components/SimulatorSection.tsx`, `web/src/lib/sim.ts` |
| Colour themes · 색상 테마 | `web/src/lib/theme.tsx` |
| Footer and team names · 푸터, 팀원 이름 | `web/src/components/Footer.tsx` |
| Map landmarks · 지도 랜드마크 | `web/src/lib/monuments.ts` |
| Site data (generated) · 사이트 데이터 | `web/public/data/*.json` |

### Sharing changes with the team · 변경 사항 공유

```bash
git pull                         # get the others' changes first / 먼저 다른 사람의 변경 사항 받기
git add -A
git commit -m "describe your change"
git push
```

In VS Code you can do the same from the **Source Control** tab: write a message → **Commit** → **Sync Changes**.
VS Code의 **Source Control** 탭에서도 가능합니다: 메시지 입력 → **Commit** → **Sync Changes**.

If the site is connected to Vercel, every `git push` updates the online version within about a minute.
사이트가 Vercel에 연결되어 있으면 `git push` 후 약 1분 안에 온라인 버전이 업데이트됩니다.

---

## Data pipeline (optional) · 데이터 파이프라인 (선택)

The website already contains its data (`web/public/data`). You only need the pipeline to **recompute** the analysis, for example with new reviews.
웹사이트에는 이미 데이터가 들어 있습니다. 새 리뷰로 분석을 **다시 계산**할 때만 파이프라인이 필요합니다.

The raw reviews (`data/raw`, `data/processed`) are **not** in this repository, on purpose: ask Zayd for them.
원본 리뷰(`data/raw`, `data/processed`)는 의도적으로 이 저장소에 **포함되어 있지 않습니다**. Zayd에게 요청하세요.

Requirements: Python 3.9+ and an internet connection for the first run (model download, ~1.5 GB).

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python3 pipeline/run_all.py
```

`run_all.py` runs, in order: `01_prepare_reviews` (clean, dedupe, audit) → `02_absa` (aspect analysis with pre-trained multilingual models, ~10–25 min on an M-series Mac) → `03_metrics` (scores, sensitivity analysis, clustering) → `04_export_site_data` (JSON for the site).

```bash
python3 pipeline/run_all.py --skip-absa   # everything except the aspect analysis (fast)
```

All methodological choices (scope, thresholds, weights) are in `pipeline/config.toml`; change a value and re-run. Method, assumptions and limits: `docs/METHODOLOGY.md`.

---

## Project layout · 폴더 구조

```
web/                    the website: React + TypeScript + Tailwind + MapLibre + Motion + Recharts
web/src/                website code / 웹사이트 코드
web/public/data/        data read by the website / 웹사이트가 읽는 데이터
pipeline/               Python scripts 01..04, config.toml, run_all.py, validation/
data/external/          INSEE population, SIRENE files, district outlines, optional indicators
data/raw/, data/processed/   reviews (not shared on GitHub / GitHub에 공유되지 않음)
exports/                summary CSV per district
docs/METHODOLOGY.md     method, assumptions, limits
```

## Troubleshooting · 문제 해결

- `npm: command not found` → install Node.js from nodejs.org, then reopen VS Code. / Node.js 설치 후 VS Code를 다시 여세요.
- `Could not read package.json` → you are not in the `web` folder: run `cd web` first. / `web` 폴더에서 실행하세요.
- `cd: no such file or directory: web` → you are already in `web`: skip `cd web`. / 이미 `web` 폴더 안에 있습니다.
- Port already in use → another copy of the site is running: press **Ctrl + C** in that terminal. / 다른 터미널에서 **Ctrl + C**.
- Blank map → use a recent Chrome or Safari (the map needs WebGL). / 최신 Chrome 또는 Safari를 사용하세요.
- `ModuleNotFoundError` (pipeline) → `source .venv/bin/activate` then `pip install -r requirements.txt`.
