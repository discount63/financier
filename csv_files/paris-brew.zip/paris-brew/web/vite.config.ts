import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// On Vercel, the public address of the site is known at build time: it is written into the share-preview tags
// (WhatsApp, KakaoTalk, LinkedIn need an absolute image URL). Locally it falls back to a relative path.
const site = process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : ''

export default defineConfig({
  plugins: [react(), { name: 'site-url', transformIndexHtml: (html) => html.replace(/%SITE_URL%/g, site) }],
  server: { port: 5173 },
  build: { chunkSizeWarningLimit: 1600 },
})
