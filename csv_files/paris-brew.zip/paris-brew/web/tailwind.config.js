/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: { 950: 'rgb(var(--ink-950) / <alpha-value>)', 900: 'rgb(var(--ink-900) / <alpha-value>)', 800: 'rgb(var(--ink-800) / <alpha-value>)', 700: 'rgb(var(--ink-700) / <alpha-value>)', 600: 'rgb(var(--ink-600) / <alpha-value>)', 500: 'rgb(var(--ink-500) / <alpha-value>)' },
        paper: { DEFAULT: 'rgb(var(--paper) / <alpha-value>)', dim: 'rgb(var(--paper-dim) / <alpha-value>)', mute: 'rgb(var(--paper-mute) / <alpha-value>)' },
        crema: { DEFAULT: 'rgb(var(--crema) / <alpha-value>)', deep: 'rgb(var(--crema-deep) / <alpha-value>)', on: 'rgb(var(--on-crema) / <alpha-value>)' },
        teal: { glow: 'rgb(var(--teal-glow) / <alpha-value>)', mid: 'rgb(var(--teal-mid) / <alpha-value>)', deep: 'rgb(var(--teal-deep) / <alpha-value>)' },
        pos: { DEFAULT: 'rgb(var(--pos) / <alpha-value>)', soft: 'rgb(var(--pos-soft) / <alpha-value>)', ink: 'rgb(var(--pos-ink) / <alpha-value>)' },
        neg: { DEFAULT: 'rgb(var(--neg) / <alpha-value>)', soft: 'rgb(var(--neg-soft) / <alpha-value>)', ink: 'rgb(var(--neg-ink) / <alpha-value>)' },
        neu: 'rgb(var(--neu) / <alpha-value>)',
        deep: { 900: 'rgb(var(--deep-900) / <alpha-value>)', 800: 'rgb(var(--deep-800) / <alpha-value>)', 700: 'rgb(var(--deep-700) / <alpha-value>)', text: 'rgb(var(--deep-text) / <alpha-value>)', mute: 'rgb(var(--deep-mute) / <alpha-value>)' },
        glow: { 1: 'rgb(var(--glow-1) / <alpha-value>)', 2: 'rgb(var(--glow-2) / <alpha-value>)' },
        sky: '#3E8FC9', violet: '#8E6BD1', rose: '#D9488A', lime: '#3FA37A', coral: '#E0585F', amber: '#E2793A', indigo: '#5C6BC9',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        sans: ['"Hanken Grotesk"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        xs: ['0.8125rem', '1.2rem'],
        sm: ['0.9375rem', '1.5rem'],
        base: ['1.0625rem', '1.7rem'],
      },
      boxShadow: { panel: '0 24px 60px -28px rgb(var(--paper) / .45)' },
    },
  },
  plugins: [],
}
