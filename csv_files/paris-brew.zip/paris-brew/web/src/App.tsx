import { useCallback, useEffect, useMemo, useState } from 'react'
import { MapSection } from './components/MapSection'
import { TopNav } from './components/TopNav'
import { AspectsSection } from './components/AspectsSection'
import { TopThreeSection } from './components/TopThreeSection'
import { SimulatorSection } from './components/SimulatorSection'
import { MethodSection } from './components/MethodSection'
import { Footer } from './components/Footer'
import { Intro } from './components/Intro'
import { AnimatePresence } from 'motion/react'
import { loadAll } from './lib/data'
import { parseCsv, toOverrides, type IndicatorOverride } from './lib/csv'
import type { AppData } from './lib/types'

const STORE_KEY = 'paris-brew-overrides'

function readStored(): IndicatorOverride[] {
  try { return JSON.parse(localStorage.getItem(STORE_KEY) ?? '[]') } catch { return [] }
}

/** Fusionne un CSV d'indicateurs importé dans le navigateur (étudiants, transports, loyers) avec les données du pipeline. */
function applyOverrides(data: AppData, overrides: IndicatorOverride[]): AppData {
  if (!overrides.length) return data
  const districts = data.districts.map((d) => {
    const o = overrides.find((x) => x.arr === d.arr)
    if (!o) return d
    const metrics = { ...d.metrics }
    const put = (key: string, unit: string, value?: number) => {
      if (value != null) metrics[key] = { value, unit, status: 'measured', source: o.source, note: 'imported in the browser' }
    }
    put('students', 'students', o.students)
    put('transit', 'stations', o.transit)
    put('rent', '€/m²/an', o.rent)
    return { ...d, metrics }
  })
  return { ...data, districts }
}

export default function App() {
  const [raw, setRaw] = useState<AppData | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [selected, setSelected] = useState<number | null>(null)
  const [simDistrict, setSimDistrict] = useState<number | null>(null)
  const [overrides, setOverrides] = useState<IndicatorOverride[]>(readStored)
  // the intro (big logo, then a short story) covers the site at every start; the map loads underneath meanwhile
  // a shared link like /#d15 skips the intro and opens that district directly
  const linked = useMemo(() => { const m = /^#d(\d{1,2})$/.exec(window.location.hash); const n = m ? Number(m[1]) : NaN; return n >= 1 && n <= 20 ? n : null }, [])
  const [entered, setEntered] = useState(linked != null)
  const [warm, setWarm] = useState(false)
  const warmUp = useCallback(() => setWarm(true), [])
  useEffect(() => {
    document.documentElement.style.overflow = entered ? '' : 'hidden'
    if (entered) {
      // a link like /#top3 still works: after the intro, jump to that section
      const target = window.location.hash && linked == null ? document.getElementById(window.location.hash.slice(1)) : null
      if (target) target.scrollIntoView(); else window.scrollTo(0, 0)
    }
  }, [entered])

  useEffect(() => { loadAll().then(setRaw).catch((e) => setError(String(e.message ?? e))) }, [])
  useEffect(() => { if (raw && linked != null) window.setTimeout(() => setSelected(linked), 600) }, [raw, linked])
  // keep the address in sync with the open district, so it can be copied and shared
  useEffect(() => {
    if (!entered) return
    const want = selected != null ? `#d${selected}` : (/^#d\d+$/.test(window.location.hash) ? '#carte' : window.location.hash)
    if (want !== window.location.hash) history.replaceState(null, '', want || window.location.pathname)
  }, [selected, entered])
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setSelected(null) }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])
  const data = useMemo(() => (raw ? applyOverrides(raw, overrides) : null), [raw, overrides])

  const importCsv = (text: string, name: string, parse: (t: string, n: string) => IndicatorOverride[]) => {
    const parsed = parse(text, name)
    setOverrides(parsed)
    try { localStorage.setItem(STORE_KEY, JSON.stringify(parsed)) } catch { /* stockage indisponible : l'import reste valable pour la session */ }
    return parsed.length
  }
  const clearImport = () => {
    setOverrides([])
    try { localStorage.removeItem(STORE_KEY) } catch { /* ignore */ }
  }

  if (error) {
    return (
      <main className="grid min-h-screen place-items-center p-6">
        <div className="card max-w-lg p-6">
          <h1 className="font-display text-2xl font-bold">The site data could not be found</h1>
          <p className="mt-3 text-paper-dim">{error}</p>
          <pre className="mt-4 overflow-x-auto rounded-lg bg-ink-950 p-3 text-sm text-crema">python3 pipeline/run_all.py</pre>
        </div>
      </main>
    )
  }
  const intro = <AnimatePresence>{!entered && <Intro key="intro" stats={raw ? { reviews: raw.meta.global.reviews, venues: raw.meta.global.venues } : null} onEnter={() => setEntered(true)} onWarm={warmUp} />}</AnimatePresence>
  if (!data) return <>{intro}<main className="grid min-h-screen place-items-center text-paper-mute">Loading data…</main></>

  const goSimulate = (arr: number) => {
    setSimDistrict(arr)
    document.getElementById('simulateur')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <>
      {intro}
      {(entered || warm) && (
        <>
      <TopNav ranking={data.ranking} />
      <main>
        <MapSection data={data} selected={selected} setSelected={setSelected} onSimulate={goSimulate} />
        <AspectsSection data={data} />
        <TopThreeSection data={data} onSelect={(arr) => { setSelected(arr); document.getElementById('carte')?.scrollIntoView({ behavior: 'smooth' }) }} onSimulate={goSimulate} />
        <SimulatorSection data={data} focusDistrict={simDistrict} />
        <MethodSection data={data} overrides={overrides} onImport={(t, n) => importCsv(t, n, (text, name) => toOverrides(parseCsv(text), name))} onClear={clearImport} />
      </main>
      <Footer data={data} />
        </>
      )}
    </>
  )
}
