import { motion } from 'motion/react'
import { NEG, NEU, POS } from '../lib/colors'

/** Barre empilée négatif / neutre / positif (jamais la couleur seule : les pourcentages sont écrits). */
export function SentimentBar({ negative, neutral, positive }: { negative: number; neutral: number; positive: number }) {
  const parts = [
    { v: negative, c: NEG, l: 'negative' },
    { v: neutral, c: NEU, l: 'neutral' },
    { v: positive, c: POS, l: 'positive' },
  ]
  return (
    <div className="flex h-2.5 w-full gap-[2px] overflow-hidden rounded-full" role="img"
      aria-label={`${Math.round(negative * 100)}% negative, ${Math.round(neutral * 100)}% neutral, ${Math.round(positive * 100)}% positive`}>
      {parts.map((p) => (
        <motion.div key={p.l} initial={{ width: 0 }} animate={{ width: `${Math.max(p.v * 100, 0)}%` }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }} style={{ background: p.c }} className="h-full" />
      ))}
    </div>
  )
}

export function HBar({ value, max = 1, color = '#6C7BC9', label }: { value: number; max?: number; color?: string; label?: string }) {
  return (
    <div className="h-2 w-full rounded-full bg-ink-600/70" role="img" aria-label={label}>
      <motion.div initial={{ width: 0 }} animate={{ width: `${Math.min(100, Math.max(0, (value / max) * 100))}%` }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }} className="h-full rounded-full" style={{ background: color }} />
    </div>
  )
}
