import { useCountUp } from '../hooks/useCountUp'

export function Counter({ value, format, className = '' }: { value: number | null | undefined; format: (v: number | null) => string; className?: string }) {
  const v = useCountUp(value)
  return <span className={className}>{format(v)}</span>
}
