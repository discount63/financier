import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useMemo, useState } from 'react'
import { ConfidenceBadge } from './Badges'
import { DistrictPanel } from './DistrictPanel'
import { useLandmarks } from '../hooks/useLandmarkImage'
import { DISTRICT_HUE, isGood } from '../lib/landmarks'
import type { AppData, District } from '../lib/types'
import type { LandmarkInfo } from '../lib/landmarks'

const EASE: [number, number, number, number] = [0.7, 0, 0.2, 1]

/** Full-page "inside the district" scene: monuments as a cinematic backdrop, the stats on the same page. Opens as an iris from the click. */
export function DistrictScene({ d, data, origin, size, onClose, onSimulate }: {
  d: District; data: AppData; origin: { x: number; y: number }; size: { w: number; h: number }
  onClose: () => void; onSimulate: (arr: number) => void
}) {
  const fetched = useLandmarks(d.arr)
  // keep only photos that work full-screen (wide, sharp); if none qualifies, keep whatever has a photo, else the colour cards
  const landmarks = useMemo(() => {
    const good = fetched.filter(isGood)
    if (good.length) return good.slice(0, 4)
    const any = fetched.filter((l) => l.image)
    return any.length ? any.slice(0, 4) : fetched.slice(0, 3)
  }, [fetched])
  const [active, setActive] = useState(0)
  useEffect(() => setActive(0), [d.arr])
  useEffect(() => setActive(0), [landmarks.length])
  const withPhoto = landmarks.filter((l) => l.image)
  const current = landmarks[active] ?? landmarks[0]
  const hue = DISTRICT_HUE[d.arr]
  const R = Math.hypot(Math.max(origin.x, size.w - origin.x), Math.max(origin.y, size.h - origin.y)) + 40
  const inTop = data.ranking.status === 'reliable' && data.ranking.top.includes(d.arr)
  const ranked = data.districts.filter((x) => x.score != null).length

  return (
    <motion.div
      className="absolute inset-0 z-40 overflow-hidden text-white"
      initial={{ clipPath: `circle(0px at ${origin.x}px ${origin.y}px)` }}
      animate={{ clipPath: `circle(${R}px at ${origin.x}px ${origin.y}px)`, transition: { duration: 1.05, delay: 0.55, ease: EASE } }}
      exit={{ clipPath: `circle(0px at ${origin.x}px ${origin.y}px)`, transition: { duration: 0.8, ease: EASE } }}
      aria-label={`Paris ${d.name} district`}
    >
      {/* backdrop: colour card, then the monument photo with a slow Ken Burns */}
      <div className="absolute inset-0" style={{ background: `radial-gradient(120% 90% at 20% 10%, hsl(${hue} 70% 42%), hsl(${(hue + 60) % 360} 60% 18%))` }} />
      <AnimatePresence>
        {current?.image && <Backdrop key={current.title} info={current} />}
      </AnimatePresence>
      <div className="absolute inset-0" style={{ background: 'linear-gradient(90deg, rgb(var(--deep-900) / .86) 0%, rgb(var(--deep-900) / .55) 42%, rgb(var(--deep-900) / .12) 100%), linear-gradient(0deg, rgb(var(--deep-900) / .75) 0%, rgb(var(--deep-900) / 0) 45%)' }} />

      <div className="relative flex h-full flex-col gap-4 p-4 md:grid md:grid-cols-[minmax(0,1fr)_minmax(0,520px)] md:gap-8 md:p-8">
        {/* left: identity + monuments */}
        <div className="flex min-h-0 flex-col md:justify-between">
          <div>
            <motion.button onClick={onClose} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.2 }}
              className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/30 bg-black/30 px-4 py-2 text-sm font-medium backdrop-blur hover:bg-black/50">
              <span aria-hidden>←</span> Back to the map
            </motion.button>
            <CopyLink arr={d.arr} />
            <div className="overflow-hidden">
              <motion.h2 initial={{ y: '110%' }} animate={{ y: 0 }} transition={{ delay: 1.0, duration: 0.9, ease: [0.2, 0.9, 0.2, 1] }}
                className="font-display text-[44px] font-extrabold leading-[0.95] md:text-[84px]" style={{ fontFamily: 'Fraunces, Georgia, serif', letterSpacing: '-0.02em' }}>
                Paris {d.name}
              </motion.h2>
            </div>
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.3 }} className="mt-3 flex flex-wrap items-center gap-2 text-sm">
              <span className="text-lg font-medium text-white/90">{d.label}</span>
              {d.rank && <span className="rounded-full border border-white/40 bg-ink-800/15 px-3 py-1 backdrop-blur">Rank {d.rank} of {ranked}</span>}
              {inTop && <span className="rounded-full border border-[#F4C95D] bg-[#F4C95D]/25 px-3 py-1 font-medium text-[#FFE6A8]">Top 3</span>}
              <span className="rounded-full bg-ink-800/90 px-0.5 py-0.5"><ConfidenceBadge level={d.confidence} /></span>
            </motion.div>
          </div>

          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.5, duration: 0.7 }} className="mt-auto">
            {current && (
              <div className="mb-3 hidden max-w-md md:block">
                <div className="font-display text-xl font-semibold md:text-2xl" style={{ fontFamily: 'Fraunces, Georgia, serif' }}>{current.name}</div>
                {current.description && <div className="text-sm text-white/80">{current.description}</div>}
              </div>
            )}
            <div className="flex gap-2.5 overflow-x-auto pb-1">
              {landmarks.map((l, i) => (
                <button key={l.title} onClick={() => setActive(i)} aria-pressed={i === active} aria-label={l.name}
                  className={`group relative h-16 w-28 shrink-0 overflow-hidden rounded-xl border-2 transition md:h-[84px] md:w-36 ${i === active ? 'border-[#F4C95D]' : 'border-white/30 hover:border-white/80'}`}>
                  <span className="absolute inset-0" style={{ background: `linear-gradient(135deg, hsl(${(hue + i * 30) % 360} 60% 40%), hsl(${(hue + 80 + i * 30) % 360} 55% 22%))` }} />
                  {(l.preview ?? l.image) && <img src={(l.preview ?? l.image)!} alt="" referrerPolicy="no-referrer" loading="lazy" className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-110" />}
                  <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent px-2 pb-1.5 pt-5 text-left text-xs font-medium leading-tight">{l.name}</span>
                </button>
              ))}
            </div>
            {withPhoto.length > 0 && <div className="mt-1.5 text-[11px] text-white/60">Photos: Wikipedia</div>}
          </motion.div>
        </div>

        {/* right: the stats, same page */}
        <motion.div initial={{ opacity: 0, x: 70 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.25, duration: 0.85, ease: [0.2, 0.9, 0.2, 1] }}
          className="min-h-0 flex-1 overflow-hidden rounded-2xl border border-white/40 bg-ink-800/95 text-paper shadow-panel backdrop-blur-xl md:flex-none">
          <DistrictPanel d={d} data={data} onSimulate={onSimulate} />
        </motion.div>
      </div>
    </motion.div>
  )
}

/** Monument photo: a quick 960px look first, then the 1920px version fades in over it, with a slow Ken Burns drift. */
function Backdrop({ info }: { info: LandmarkInfo }) {
  const [sharp, setSharp] = useState(false)
  const [failed, setFailed] = useState(false)
  // very wide photos fill the screen; squarer ones are shown whole over a blurred copy of themselves, so nothing is cropped to a detail
  const wide = (info.ratio ?? 2) >= 1.6
  const fit = wide ? 'object-cover object-[center_55%]' : 'object-contain'
  return (
    <motion.div className="absolute inset-0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.9 }}>
      {!wide && <img src={info.preview ?? info.image!} alt="" aria-hidden referrerPolicy="no-referrer" className="absolute inset-0 h-full w-full scale-110 object-cover opacity-80 blur-2xl" />}
      <motion.div className="absolute inset-0" initial={{ scale: 1.0 }} animate={{ scale: 1.035 }} transition={{ duration: 24, ease: 'linear' }}>
        {info.preview && <img src={info.preview} alt="" referrerPolicy="no-referrer" decoding="async" className={`absolute inset-0 h-full w-full ${fit}`} />}
        {!failed && (
          <img src={info.image!} alt={info.name} referrerPolicy="no-referrer" decoding="async" onLoad={() => setSharp(true)} onError={() => setFailed(true)}
            className={`absolute inset-0 h-full w-full ${fit} transition-opacity duration-1000`} style={{ opacity: sharp ? 1 : 0 }} />
        )}
      </motion.div>
    </motion.div>
  )
}

/** Copies a direct link to this district (…/#d15): whoever opens it lands straight on this view. */
function CopyLink({ arr }: { arr: number }) {
  const [done, setDone] = useState(false)
  const copy = async () => {
    const url = `${window.location.origin}${window.location.pathname}#d${arr}`
    try { await navigator.clipboard.writeText(url); setDone(true); window.setTimeout(() => setDone(false), 1800) } catch { window.prompt('Copy this link', url) }
  }
  return (
    <motion.button onClick={copy} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 1.3 }}
      className="mb-4 ml-2 inline-flex items-center gap-2 rounded-full border border-white/30 bg-black/30 px-4 py-2 text-sm font-medium backdrop-blur hover:bg-black/50">
      {done ? 'Link copied ✓' : 'Copy link'}
    </motion.button>
  )
}
