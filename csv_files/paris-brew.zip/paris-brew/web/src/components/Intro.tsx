import { AnimatePresence, motion } from 'motion/react'
import { useCallback, useEffect, useState, type ReactNode } from 'react'
import { FinancierMark } from './Logo'
import { Counter } from './Counter'
import { CoffeeFilm } from './CoffeeFilm'
import { int } from '../lib/format'

const SERIF = 'Fraunces, Georgia, serif'
const EASE: [number, number, number, number] = [0.2, 0.9, 0.2, 1]

interface Stats { reviews: number; venues: number }

/* ---------- visuals for each chapter ---------- */

/** A cup drawn line by line, with steam. */
function CupDrawing() {
  const draw = (delay: number) => ({ initial: { pathLength: 0, opacity: 0 }, animate: { pathLength: 1, opacity: 1 }, transition: { duration: 1.3, delay, ease: 'easeInOut' as const } })
  return (
    <svg viewBox="0 0 320 300" className="w-full max-w-[380px]" fill="none" stroke="#FFE9D2" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <motion.path d="M70 120 h170 v52 a85 85 0 0 1 -170 0 z" {...draw(0.1)} />
      <motion.path d="M240 138 h14 a34 34 0 0 1 0 68 h-24" {...draw(0.5)} />
      <motion.path d="M40 262 h230" {...draw(0.9)} />
      <motion.path d="M104 92 q-18 -24 0 -46 t0 -42" stroke="#F4A97F" {...draw(1.2)} />
      <motion.path d="M155 92 q18 -24 0 -46 t0 -42" stroke="#F4A97F" {...draw(1.4)} />
      <motion.path d="M206 92 q-16 -22 0 -42 t0 -38" stroke="#F4A97F" {...draw(1.6)} />
      <motion.path d="M96 168 q60 48 120 0" stroke="#E0A526" {...draw(1.1)} />
    </svg>
  )
}

/** Two culture circles sliding together; the overlap is the project. */
function Overlap() {
  return (
    <div className="relative mx-auto h-[270px] w-full max-w-[420px]">
      <motion.div className="absolute left-0 top-4 grid h-[230px] w-[230px] place-items-center rounded-full border border-[#FFE9D2]/40 bg-glow-1/25"
        initial={{ x: -50, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 1.1, ease: EASE }}>
        <span className="-translate-x-9 text-center text-sm leading-tight text-[#FFE9D2]" style={{ fontFamily: SERIF }}>Paris<br />the classic café</span>
      </motion.div>
      <motion.div className="absolute right-0 top-4 grid h-[230px] w-[230px] place-items-center rounded-full border border-[#FFE9D2]/40 bg-[#3E8FC9]/25"
        initial={{ x: 50, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 1.1, ease: EASE }}>
        <span className="translate-x-9 text-center text-sm leading-tight text-[#FFE9D2]" style={{ fontFamily: SERIF }}>Seoul<br />the café boom</span>
      </motion.div>
      <div className="absolute left-1/2 top-[88px] -translate-x-1/2">
        <motion.div className="whitespace-nowrap rounded-full bg-[#FBD16B] px-4 py-2 text-lg font-bold text-[#3A2400] shadow-xl" style={{ fontFamily: SERIF }}
          initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 1, type: 'spring', stiffness: 260, damping: 16 }}>
          €1.50 ?
        </motion.div>
      </div>
    </div>
  )
}

function PriceTag() {
  return (
    <div className="text-center">
      <motion.div className="text-[112px] font-semibold leading-none text-[#FBD16B] md:text-[150px]" style={{ fontFamily: SERIF }}
        initial={{ opacity: 0, scale: 0.7, rotate: -6 }} animate={{ opacity: 1, scale: 1, rotate: -3 }} transition={{ duration: 0.9, ease: EASE }}>
        €1.50
      </motion.div>
      <motion.div className="mx-auto mt-3 h-1 rounded-full bg-glow-1" initial={{ width: 0 }} animate={{ width: 220 }} transition={{ delay: 0.7, duration: 0.8, ease: EASE }} />
      <motion.div className="mt-3 text-lg italic text-[#E8D5CF]" style={{ fontFamily: SERIF }} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }}>per cup, in which arrondissement?</motion.div>
    </div>
  )
}

function Numbers({ stats }: { stats: Stats | null }) {
  const items: { v: number | null; label: string; c: string }[] = [
    { v: stats?.reviews ?? null, label: 'Google Maps reviews, read aspect by aspect', c: '#F4A97F' },
    { v: stats?.venues ?? null, label: 'venues across Paris', c: '#8FD0B0' },
    { v: 20, label: 'arrondissements compared', c: '#9DB8F5' },
  ]
  return (
    <div className="w-full max-w-[420px] space-y-3">
      {items.map((it, i) => (
        <motion.div key={it.label} initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 + i * 0.18, duration: 0.7, ease: EASE }}
          className="flex items-baseline gap-4 rounded-2xl border border-white/15 bg-white/[0.06] px-5 py-4 ">
          <span className="min-w-[96px] text-4xl font-semibold" style={{ fontFamily: SERIF, color: it.c }}><Counter value={it.v} format={(v) => (v == null ? '…' : int(Math.round(v)))} /></span>
          <span className="text-[15px] text-[#E8D5CF]">{it.label}</span>
        </motion.div>
      ))}
    </div>
  )
}

/* ---------- chapters ---------- */

interface Chapter { title: string; body: ReactNode; note?: string; visual: (s: Stats | null) => ReactNode }

const CHAPTERS: Chapter[] = [
  {
    title: 'Paris runs on coffee.',
    body: <>The café is the living room of Paris. Since Café Procope opened in 1686, people have met, argued and worked over a cup: a quick espresso at the counter, or a long hour on the terrace.</>,
    note: 'General background, not a measurement from this study.',
    visual: () => <CupDrawing />,
  },
  {
    title: 'Seoul built a café culture of its own.',
    body: <>In Korea, cafés are where people study, meet and spend an afternoon: careful interiors, seasonal desserts, and a classic iced americano that high-volume chains sell at a very low price.</>,
    note: 'General background, not a measurement from this study.',
    visual: () => <Overlap />,
  },
  {
    title: 'Our question.',
    body: <>Could a Korean-style café selling its classic cup for <b className="text-[#FBD16B]">€1.50</b> work in Paris? And in which arrondissement would it find its customers?</>,
    visual: () => <PriceTag />,
  },
  {
    title: 'How we answer it.',
    body: <>We read what Parisians say about their cafés (price, taste, service, waiting time…), match it with public data, rank the 20 arrondissements and test how stable that ranking is. Then you can try the numbers yourself in a profit simulator.</>,
    visual: (s) => <Numbers stats={s} />,
  },
]

/** Start screen: the big logo (click it to start), then a four-step story, then the site opens from the logo. */
export function Intro({ stats, onEnter, onWarm }: { stats: Stats | null; onEnter: () => void; onWarm: () => void }) {
  const [stage, setStage] = useState<'logo' | 'story' | 'film'>('logo')
  const [i, setI] = useState(0)
  const [dir, setDir] = useState(1)
  const last = i === CHAPTERS.length - 1

  const go = useCallback((n: number) => {
    setDir(n > i ? 1 : -1)
    setI(Math.max(0, Math.min(CHAPTERS.length - 1, n)))
  }, [i])
  const next = useCallback(() => (last ? onEnter() : go(i + 1)), [last, onEnter, go, i])

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (stage === 'film') return // the film handles its own keys
      if (e.key === 'Escape') { e.stopPropagation(); onEnter(); return }
      if (stage === 'logo') { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setStage('story') } return }
      if (e.key === 'ArrowRight' || e.key === 'Enter') next()
      if (e.key === 'ArrowLeft') go(i - 1)
    }
    window.addEventListener('keydown', k, true)
    return () => window.removeEventListener('keydown', k, true)
  }, [stage, next, go, i, onEnter])

  // the heavy part (the map) only starts loading from the third step, so the first screens stay perfectly smooth
  useEffect(() => { if (stage === 'story' && i >= 2) onWarm() }, [stage, i, onWarm])

  const ch = CHAPTERS[i]
  return (
    <motion.div
      className="fixed inset-0 z-[90] overflow-hidden text-[#FFF3E6]"
      style={{ background: 'radial-gradient(120% 90% at 50% 0%, rgb(var(--deep-700)) 0%, rgb(var(--deep-800)) 55%, rgb(var(--deep-900)) 100%)' }}
      exit={{ opacity: 0, scale: 1.05, transition: { duration: 0.7, ease: [0.4, 0, 0.2, 1] } }}
      aria-label="Introduction"
    >
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(600px 500px at 8% 45%, rgb(var(--glow-1) / .28), transparent 70%), radial-gradient(640px 560px at 95% 90%, rgb(var(--glow-2) / .22), transparent 70%)' }} />

      {stage !== 'film' && <button onClick={onEnter} className="absolute right-4 top-4 z-10 rounded-full border border-white/25 px-4 py-1.5 text-sm text-[#E8D5CF] transition hover:bg-white/10 md:right-8 md:top-6">Skip intro</button>}

      <AnimatePresence mode="wait">
        {stage === 'film' ? (
          <motion.div key="film" className="absolute inset-0" initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: 0.5 } }} exit={{ opacity: 0, transition: { duration: 0.3 } }}>
            <CoffeeFilm onClose={() => setStage('logo')} onFinish={() => { setI(0); setStage('story') }} onEnter={onEnter} />
          </motion.div>
        ) : stage === 'logo' ? (
          <motion.div key="logo" className="absolute inset-0 grid place-items-center px-6"
            exit={{ opacity: 0, scale: 0.94, transition: { duration: 0.4 } }}>
            <div className="flex flex-col items-center text-center">
              <div className="relative">
                {/* pulsing rings invite the click */}
                {[0, 1].map((n) => (
                  <motion.span key={n} className="pointer-events-none absolute inset-0 rounded-full border border-[#FBD16B]/60"
                    initial={{ scale: 1, opacity: 0 }} animate={{ scale: [1, 1.55], opacity: [0.55, 0] }} transition={{ duration: 2.6, repeat: Infinity, delay: 1.4 + n * 1.3, ease: 'easeOut' }} />
                ))}
                <motion.div initial={{ scale: 0.4, opacity: 0, rotate: -12 }} animate={{ scale: 1, opacity: 1, rotate: 0 }} transition={{ duration: 1.1, ease: EASE }}>
                  <FinancierMark size={Math.min(230, typeof window !== 'undefined' ? window.innerWidth * 0.55 : 230)} onActivate={() => setStage('story')} />
                </motion.div>
              </div>
              <motion.h1 className="mt-9 text-[56px] font-semibold leading-none md:text-[84px]" style={{ fontFamily: SERIF, letterSpacing: '-0.02em' }}
                initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.9, ease: EASE }}>
                Financier
              </motion.h1>
              <motion.p className="mt-3 text-lg italic text-[#E8D5CF] md:text-xl" style={{ fontFamily: SERIF }}
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9, duration: 0.9 }}>
                coffee &amp; pastry, €1.50, Paris
              </motion.p>
              <motion.p className="mt-10 text-sm text-[#FBD16B]" initial={{ opacity: 0 }} animate={{ opacity: [0, 1, 0.55, 1] }} transition={{ delay: 1.6, duration: 2.4, repeat: Infinity, repeatType: 'mirror' }}>
                Click the logo to start
              </motion.p>
              <motion.button onClick={() => setStage('film')} className="group mt-5 inline-flex items-center gap-3 rounded-full border border-[#FBD16B]/50 bg-white/[0.06] py-2 pl-2 pr-5 text-[15px] text-[#FFF3E6] transition hover:border-[#FBD16B] hover:bg-white/10"
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.3, duration: 0.6 }}>
                <span className="grid h-8 w-8 place-items-center rounded-full bg-[#FBD16B] text-[#3A2400] transition group-hover:scale-110" aria-hidden>
                  <svg width="12" height="12" viewBox="0 0 12 12"><path d="M3 1.5v9l7-4.5z" fill="currentColor" /></svg>
                </span>
                Understand Parisians and their coffee
              </motion.button>
            </div>
            <motion.div className="absolute bottom-5 left-0 right-0 px-4 text-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.1, duration: 0.8 }}>
              <div className="text-sm text-[#EBD9D2] md:text-[15px]">A project by <span className="text-[#FFF3E6]">Zayd El Khiri</span>, <span className="text-[#FFF3E6]">강나윤</span>, <span className="text-[#FFF3E6]">남하린</span> &amp; <span className="text-[#FFF3E6]">이예지</span></div>
              <div className="mt-1 text-xs text-[#BFA8AE]">Applied Data Science · Sookmyung Women's University</div>
            </motion.div>
          </motion.div>
        ) : (
          <motion.div key="story" className="absolute inset-0 flex flex-col" initial={{ opacity: 0 }} animate={{ opacity: 1, transition: { duration: 0.6, delay: 0.1 } }}>
            <div className="mx-auto flex w-full max-w-[1200px] flex-1 items-center px-6 py-20 md:px-10">
              <AnimatePresence mode="wait" custom={dir}>
                <motion.div key={i} custom={dir} className="grid w-full items-center gap-10 md:grid-cols-[1.05fr_1fr] md:gap-16"
                  initial={{ opacity: 0, x: dir * 50 }} animate={{ opacity: 1, x: 0, transition: { duration: 0.6, ease: EASE } }}
                  exit={{ opacity: 0, x: dir * -50, transition: { duration: 0.25 } }}>
                  <div>
                    <div className="mb-4 text-sm text-[#FBD16B]" style={{ fontFamily: SERIF }}>{i + 1} of {CHAPTERS.length}</div>
                    <h2 className="text-[38px] font-semibold leading-[1.05] md:text-[64px]" style={{ fontFamily: SERIF, letterSpacing: '-0.02em' }}>{ch.title}</h2>
                    <p className="mt-5 max-w-xl text-[17px] leading-relaxed text-[#EBD9D2] md:text-xl md:leading-relaxed">{ch.body}</p>
                    {ch.note && <p className="mt-4 text-xs text-[#BFA8AE]">{ch.note}</p>}
                  </div>
                  <div className="grid min-h-[240px] place-items-center md:min-h-[320px]">{ch.visual(stats)}</div>
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="mx-auto flex w-full max-w-[1200px] items-center justify-between px-6 pb-8 md:px-10 md:pb-10">
              <div className="flex items-center gap-2" role="tablist" aria-label="Intro steps">
                {CHAPTERS.map((_, n) => (
                  <button key={n} role="tab" aria-selected={n === i} aria-label={`Step ${n + 1}`} onClick={() => go(n)}
                    className={`h-2 rounded-full transition-all duration-500 ${n === i ? 'w-9 bg-[#FBD16B]' : 'w-2 bg-white/30 hover:bg-white/60'}`} />
                ))}
              </div>
              <div className="flex items-center gap-3">
                {i > 0 && <button onClick={() => go(i - 1)} className="rounded-full border border-white/25 px-5 py-2.5 text-sm font-medium hover:bg-white/10">Back</button>}
                <button onClick={next} className="rounded-full bg-[#FBD16B] px-6 py-2.5 text-sm font-semibold text-[#3A2400] shadow-lg transition hover:bg-[#FFDD85]">
                  {last ? 'Open the map' : 'Next'}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}
