import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useState } from 'react'
import type { Ranking } from '../lib/types'
import { Wordmark } from './Logo'
import { ThemeSwitch } from './ThemeSwitch'

const LINKS = [
  ['carte', 'Map'],
  ['clients', 'Customers'],
  ['top3', 'Top 3'],
  ['simulateur', 'Simulator'],
  ['methode', 'Method'],
] as const

export function TopNav({ ranking }: { ranking: Ranking | null }) {
  const [menu, setMenu] = useState(false)
  useEffect(() => {
    if (!menu) return
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setMenu(false) }
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [menu])

  return (
    <header className="sticky top-0 z-40 border-b border-paper/10 bg-ink-900/90 backdrop-blur-md">
      <nav className="mx-auto flex h-14 max-w-[1500px] items-center justify-between gap-2 px-3 md:px-6" aria-label="Main navigation">
        <a href="#carte" aria-label="Financier, back to the map" className="shrink-0"><Wordmark /></a>
        <ul className="hidden items-center gap-1 md:flex">
          {LINKS.map(([id, label]) => (
            <li key={id}><a href={`#${id}`} className="rounded-lg px-3 py-1.5 text-sm text-paper-dim transition-colors hover:bg-ink-600 hover:text-paper">{label}</a></li>
          ))}
        </ul>
        <div className="flex items-center gap-2">
          {ranking && (
            <span className={`hidden rounded-full border px-3 py-1 text-xs font-medium lg:inline ${ranking.status === 'reliable' ? 'border-pos/40 text-pos' : 'border-crema/40 text-crema'}`}>
              {ranking.status === 'reliable' ? 'Reliable ranking' : 'Provisional ranking'}
            </span>
          )}
          <ThemeSwitch />
          <button onClick={() => setMenu((m) => !m)} aria-label={menu ? 'Close menu' : 'Open menu'} aria-expanded={menu}
            className="grid h-9 w-9 place-items-center rounded-full border border-ink-600 bg-ink-800 text-paper md:hidden">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
              {menu ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </nav>
      <AnimatePresence>
        {menu && (
          <motion.ul initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.22 }}
            className="overflow-hidden border-t border-paper/10 bg-ink-900 px-3 pb-3 pt-1 md:hidden">
            {LINKS.map(([id, label]) => (
              <li key={id}><a href={`#${id}`} onClick={() => setMenu(false)} className="block rounded-lg px-3 py-3 text-[17px] font-medium text-paper hover:bg-ink-700">{label}</a></li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </header>
  )
}
