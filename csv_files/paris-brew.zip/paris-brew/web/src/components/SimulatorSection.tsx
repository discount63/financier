import { TIP } from '../lib/chartStyle'
import { useEffect, useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Counter } from './Counter'
import { Note, Section } from './Section'
import { dec1, eur, int } from '../lib/format'
import { DEFAULT_SIM, simulate, type SimInputs } from '../lib/sim'
import type { AppData } from '../lib/types'

type Tag = 'Project' | 'Assumption' | 'To verify'

function Slider({ label, tag, value, min, max, step, onChange, format }: {
  label: string; tag: Tag; value: number; min: number; max: number; step: number; onChange: (v: number) => void; format: (v: number) => string
}) {
  const id = `sl-${label.replace(/\W+/g, '')}`
  return (
    <div>
      <div className="mb-1 flex items-center justify-between gap-2 text-sm">
        <label htmlFor={id} className="text-paper-dim">{label}</label>
        <span className="flex items-center gap-2">
          <span className={`rounded-full border px-1.5 py-px text-xs ${tag === 'Project' ? 'border-teal-mid/60 text-teal-glow' : 'border-crema-deep/60 text-crema'}`}>{tag}</span>
          <b className="min-w-[72px] text-right">{format(value)}</b>
        </span>
      </div>
      <input id={id} type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </div>
  )
}

const KPI_COLORS = ['#3E8FC9', '#8E6BD1', '#E0A526', '#D9488A', '#3FA37A', '#E2793A']
function Kpi({ label, value, format, tone = 'text-paper', sub }: { label: string; value: number | null; format: (v: number | null) => string; tone?: string; sub?: string }) {
  const accent = KPI_COLORS[[...label].reduce((a, c) => a + c.charCodeAt(0), 0) % KPI_COLORS.length]
  return (
    <div className="card px-4 py-3.5" style={{ borderTop: `3px solid ${accent}` }}>
      <div className={`font-display text-3xl font-bold ${tone}`}><Counter value={value} format={format} /></div>
      <div className="text-xs text-paper-mute">{label}</div>
      {sub && <div className="mt-0.5 text-xs text-paper-mute">{sub}</div>}
    </div>
  )
}

export function SimulatorSection({ data, focusDistrict }: { data: AppData; focusDistrict: number | null }) {
  const [s, setS] = useState<SimInputs>(DEFAULT_SIM)
  const set = <K extends keyof SimInputs>(k: K) => (v: number) => setS((p) => ({ ...p, [k]: v }))
  const r = useMemo(() => simulate(s), [s])
  const [picked, setPicked] = useState<number[]>(() => data.ranking.top.slice(0, 3))
  const [overrides, setOverrides] = useState<Record<number, { rent?: number; cups?: number }>>({})
  const [surface, setSurface] = useState(40)

  useEffect(() => { if (focusDistrict != null) setPicked((p) => (p.includes(focusDistrict) ? p : [focusDistrict, ...p].slice(0, 3))) }, [focusDistrict])

  const curve = useMemo(() => Array.from({ length: 41 }, (_, i) => {
    const cups = i * 20
    return { cups, profit: Math.round(simulate({ ...s, cupsPerDay: cups }).profit) }
  }), [s])

  const bars = [
    { name: 'Revenue', v: r.revenue, c: '#6C7BC9' },
    { name: 'Variable', v: r.variable, c: '#9A6B45' },
    { name: 'Fixed', v: r.fixed, c: '#8A8397' },
    { name: r.profit >= 0 ? 'Profit' : 'Loss', v: Math.abs(r.profit), c: r.profit >= 0 ? '#3FA37A' : '#D6453D' },
  ]

  const rows = picked.map((arr) => {
    const d = data.districts.find((x) => x.arr === arr)!
    const importedRent = d.metrics.rent.value != null ? (d.metrics.rent.value * surface) / 12 : null
    const o = overrides[arr] ?? {}
    const rent = o.rent ?? importedRent ?? s.rent
    const cups = o.cups ?? s.cupsPerDay
    const res = simulate({ ...s, rent, cupsPerDay: cups })
    return { d, rent, cups, res, rentSource: o.rent != null ? 'entered' : importedRent != null ? 'imported' : 'global assumption' }
  })
  const anyImportedRent = data.districts.some((d) => d.metrics.rent.value != null)

  return (
    <Section id="simulateur" title="Can a €1.50 cup make money?"
      intro="Adjust the assumptions and everything recalculates. The starting values are working assumptions, labelled as such; they are not measurements.">
      <div className="grid gap-8 lg:grid-cols-[minmax(0,380px)_minmax(0,1fr)]">
        <div className="card space-y-4 p-5">
          <Slider label="Selling price incl. VAT" tag="Project" value={s.priceTtc} min={0.8} max={3} step={0.05} onChange={set('priceTtc')} format={(v) => eur(v, 2)} />
          <Slider label="Cups sold per day" tag="Assumption" value={s.cupsPerDay} min={0} max={800} step={10} onChange={set('cupsPerDay')} format={(v) => int(v)} />
          <Slider label="Opening days per month" tag="Assumption" value={s.daysPerMonth} min={20} max={31} step={1} onChange={set('daysPerMonth')} format={(v) => int(v)} />
          <hr className="border-ink-600" />
          <Slider label="Monthly rent" tag="Assumption" value={s.rent} min={1000} max={12000} step={100} onChange={set('rent')} format={(v) => eur(v)} />
          <Slider label="Staff (full-time equivalents)" tag="Assumption" value={s.staffCount} min={1} max={10} step={0.5} onChange={set('staffCount')} format={(v) => dec1(v)} />
          <Slider label="Other costs / month (energy, insurance…)" tag="Assumption" value={s.other} min={400} max={4000} step={100} onChange={set('other')} format={(v) => eur(v)} />
          <p className="rounded-lg bg-ink-700 px-3 py-2 text-xs leading-relaxed text-paper-mute">
            Fixed in the model, not adjustable: VAT {Math.round(s.vat * 100)}%, ingredients and packaging {eur(s.ingredients + s.packaging, 2)} per cup, card fees {(s.paymentFee * 100).toFixed(1)}%, employer cost {eur(s.costPerStaff)} per position. They matter less than price, volume and rent.
          </p>
          <button onClick={() => setS(DEFAULT_SIM)} className="w-full rounded-lg border border-ink-500 py-2 text-sm text-paper-dim hover:bg-ink-600">Reset to starting values</button>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <Kpi label="Revenue excl. VAT / month" value={r.revenue} format={(v) => eur(v)} />
            <Kpi label="Variable costs / month" value={r.variable} format={(v) => eur(v)} />
            <Kpi label="Fixed costs / month" value={r.fixed} format={(v) => eur(v)} />
            <Kpi label={r.profit >= 0 ? 'Profit / month' : 'Loss / month'} value={r.profit} format={(v) => eur(v)} tone={r.profit >= 0 ? 'text-pos' : 'text-neg'} />
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            <Kpi label="Break-even (cups per day)" value={r.breakEvenCupsPerDay} format={(v) => (v == null ? 'never' : int(Math.ceil(v)))}
              sub={r.breakEvenCupsPerDay ? `${int(Math.ceil(r.breakEvenCupsPerDay * s.daysPerMonth))} cups per month` : 'The margin per cup is negative'} />
            <Kpi label="Margin per cup (excl. VAT, before fixed costs)" value={r.contributionPerCup} format={(v) => eur(v, 2)} sub={`Price excl. VAT ${eur(r.priceHt, 2)}`} />
            <Kpi label="Minimum price incl. VAT at this volume" value={r.breakEvenPrice} format={(v) => (v != null && Number.isFinite(v) ? eur(v, 2) : '—')} sub={`for ${int(s.cupsPerDay)} cups per day`} />
          </div>
          <div className="grid gap-4 xl:grid-cols-2">
            <div className="card p-5">
              <h3 className="font-display text-base font-bold">Monthly profit by daily sales</h3>
              <div className="mt-3 h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={curve} margin={{ top: 8, right: 12, bottom: 4, left: 0 }}>
                    <CartesianGrid stroke="rgb(var(--ink-600))" vertical={false} />
                    <XAxis dataKey="cups" tick={{ fill: 'rgb(var(--paper-mute))', fontSize: 11 }} axisLine={false} tickLine={false} label={{ value: 'cups per day', position: 'insideBottomRight', offset: -2, fill: 'rgb(var(--paper-mute))', fontSize: 11 }} />
                    <YAxis tick={{ fill: 'rgb(var(--paper-mute))', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `€${Math.round(v / 1000)}k`} width={58} />
                    <Tooltip {...TIP} formatter={(v: number) => [eur(v), 'Profit']} labelFormatter={(l) => `${l} cups per day`} />
                    <ReferenceLine y={0} stroke="rgb(var(--neu))" />
                    <ReferenceLine x={Math.round(s.cupsPerDay / 20) * 20} stroke="#E0A526" strokeDasharray="4 4" />
                    <Line type="monotone" dataKey="profit" stroke="#3FA37A" strokeWidth={2} dot={false} activeDot={{ r: 4, stroke: 'rgb(var(--ink-800))', strokeWidth: 2 }} animationDuration={500} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="card p-5">
              <h3 className="font-display text-base font-bold">Where the money comes from and where it goes</h3>
              <div className="mt-3 h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bars} margin={{ top: 8, right: 8, bottom: 4, left: 0 }}>
                    <CartesianGrid stroke="rgb(var(--ink-600))" vertical={false} />
                    <XAxis dataKey="name" tick={{ fill: 'rgb(var(--paper-mute))', fontSize: 11 }} axisLine={false} tickLine={false} interval={0} />
                    <YAxis tick={{ fill: 'rgb(var(--paper-mute))', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `€${Math.round(v / 1000)}k`} width={58} />
                    <Tooltip cursor={{ fill: 'rgb(var(--paper) / 0.06)' }} {...TIP} formatter={(v: number) => [eur(v), '']} />
                    <Bar dataKey="v" radius={[4, 4, 0, 0]} maxBarSize={56} animationDuration={500}>{bars.map((b) => <Cell key={b.name} fill={b.c} />)}</Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="card p-5">
            <h3 className="font-display text-lg font-bold">Compare districts</h3>
            <p className="mt-1 text-xs leading-relaxed text-paper-mute">
              Pick up to three districts. Rent comes from the imported file (Method section) multiplied by the floor area, otherwise it is the global assumption; edit it or the sales for each location.
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {data.districts.map((d) => (
                <button key={d.arr} onClick={() => setPicked((p) => (p.includes(d.arr) ? p.filter((x) => x !== d.arr) : p.length >= 3 ? [...p.slice(1), d.arr] : [...p, d.arr]))}
                  aria-pressed={picked.includes(d.arr)}
                  className={`rounded-full border px-2.5 py-1 text-xs ${picked.includes(d.arr) ? 'border-crema bg-crema/15 text-crema' : 'border-ink-500 text-paper-dim hover:bg-ink-600'}`}>{d.name}</button>
              ))}
            </div>
            {anyImportedRent && (
              <label className="mt-3 flex items-center gap-2 text-xs text-paper-dim">Premises floor area (m²)
                <input type="number" value={surface} min={10} max={200} onChange={(e) => setSurface(Number(e.target.value))} className="w-20 rounded-md border border-ink-500 bg-ink-800 px-2 py-1 text-paper" />
              </label>
            )}
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[640px] text-left text-sm">
                <thead className="text-xs text-paper-mute"><tr>
                  <th className="py-2 pr-3 font-medium">District</th><th className="pr-3 font-medium">Rent / month</th><th className="pr-3 font-medium">Cups / day</th>
                  <th className="pr-3 font-medium">Break-even (cups / day)</th><th className="pr-3 font-medium">Result / month</th><th className="font-medium">Cafés (SIRENE)</th></tr></thead>
                <tbody>
                  {rows.map(({ d, rent, cups, res, rentSource }) => (
                    <tr key={d.arr} className="border-t border-ink-600">
                      <td className="py-2.5 pr-3 font-semibold">Paris {d.name}</td>
                      <td className="pr-3">
                        <input aria-label={`Rent ${d.name}`} type="number" value={Math.round(rent)} step={100} onChange={(e) => setOverrides((o) => ({ ...o, [d.arr]: { ...o[d.arr], rent: Number(e.target.value) } }))}
                          className="w-24 rounded-md border border-ink-500 bg-ink-800 px-2 py-1" />
                        <div className="mt-0.5 text-xs text-paper-mute">{rentSource}</div>
                      </td>
                      <td className="pr-3"><input aria-label={`Cups per day ${d.name}`} type="number" value={cups} step={10} onChange={(e) => setOverrides((o) => ({ ...o, [d.arr]: { ...o[d.arr], cups: Number(e.target.value) } }))}
                        className="w-20 rounded-md border border-ink-500 bg-ink-800 px-2 py-1" /></td>
                      <td className="pr-3">{res.breakEvenCupsPerDay ? int(Math.ceil(res.breakEvenCupsPerDay)) : '—'}</td>
                      <td className={`pr-3 font-semibold ${res.profit >= 0 ? 'text-pos' : 'text-neg'}`}>{eur(res.profit)}</td>
                      <td>{int(d.metrics.cafes_sirene.value)} <span className="text-xs text-paper-mute">({dec1(d.metrics.cafes_per_10k.value)} / 10,000 res.)</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </Section>
  )
}
