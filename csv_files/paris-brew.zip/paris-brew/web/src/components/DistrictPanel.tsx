import { motion } from 'motion/react'
import { useMemo, useState } from 'react'
import { Cell, Pie, PieChart, PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer, Tooltip } from 'recharts'
import { TIP } from '../lib/chartStyle'
import { Counter } from './Counter'
import { SentimentBar } from './Bars'
import { StatusBadge } from './Badges'
import { ASPECT_COLORS, NEG, NEU, POS, inkOf, scoreColor } from '../lib/colors'
import { usePalette } from '../lib/theme'
import { dec1, dec2, eur, int, pct } from '../lib/format'
import { insightsFor, shortLabel } from '../lib/insights'
import type { AppData, District, Metric } from '../lib/types'

const METRIC_ROWS: { key: string; label: string; fmt: (v: number) => string }[] = [
  { key: 'population', label: 'Population', fmt: int },
  { key: 'students', label: 'Students', fmt: int },
  { key: 'hospitality', label: 'Hospitality venues (SIRENE)', fmt: int },
  { key: 'cafes_sirene', label: 'Competing cafés (SIRENE)', fmt: int },
  { key: 'cafes_per_10k', label: 'Cafés per 10,000 residents', fmt: dec1 },
  { key: 'transit', label: 'Transit access (stations)', fmt: int },
  { key: 'rent', label: 'Estimated commercial rent', fmt: (v) => eur(v) },
  { key: 'rating', label: 'Average Google rating', fmt: dec2 },
  { key: 'negative_share', label: '1–2 star reviews', fmt: (v) => pct(v) },
  { key: 'service_rating', label: 'Service sub-rating (Google)', fmt: dec2 },
  { key: 'ambiance_rating', label: 'Atmosphere sub-rating (Google)', fmt: dec2 },
  { key: 'takeaway', label: 'Takeaway orders', fmt: (v) => pct(v) },
  { key: 'price_band', label: 'Declared price per person', fmt: (v) => eur(v) },
  { key: 'long_wait', label: 'Wait of 10 min or more', fmt: (v) => pct(v) },
  { key: 'loud', label: 'Venues rated noisy', fmt: (v) => pct(v) },
  { key: 'chain_share', label: 'Share of reviews about Starbucks', fmt: (v) => pct(v) },
]

const TABS = ['Overview', 'Customers', 'Sources'] as const
type Tab = (typeof TABS)[number]

/** Ring gauge: the score out of 100, coloured like the district on the map. */
function Gauge({ value, color }: { value: number; color: string }) {
  const r = 44, c = 2 * Math.PI * r
  return (
    <div className="relative h-[112px] w-[112px] shrink-0" role="img" aria-label={`Score ${Math.round(value)} out of 100`}>
      <svg viewBox="0 0 112 112" className="h-full w-full -rotate-90">
        <circle cx="56" cy="56" r={r} fill="none" stroke="rgb(var(--ink-700))" strokeWidth="11" />
        <motion.circle cx="56" cy="56" r={r} fill="none" stroke={color} strokeWidth="11" strokeLinecap="round" strokeDasharray={c}
          initial={{ strokeDashoffset: c }} animate={{ strokeDashoffset: c * (1 - value / 100) }} transition={{ duration: 1.3, delay: 1.5, ease: [0.2, 0.9, 0.2, 1] }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">
        <div>
          <div className="font-display text-[34px] font-bold leading-none" style={{ color: inkOf(color) }}>
            <Counter value={value} format={(v) => (v == null ? '—' : Math.round(v).toString())} />
          </div>
          <div className="mt-0.5 text-[11px] text-paper-mute">out of 100</div>
        </div>
      </div>
    </div>
  )
}

function Card({ title, hint, children, className = '' }: { title: string; hint?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-ink-600 bg-ink-800 p-3.5 ${className}`}>
      <div className="mb-1 flex items-baseline justify-between gap-2">
        <h3 className="font-display text-[15px] font-bold">{title}</h3>
        {hint && <span className="text-[11px] text-paper-mute">{hint}</span>}
      </div>
      {children}
    </div>
  )
}

function Chip({ tone, children, title }: { tone: 'pos' | 'neg'; children: React.ReactNode; title?: string }) {
  return (
    <span title={title} className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${tone === 'pos' ? 'bg-pos-soft text-pos-ink' : 'bg-neg-soft text-neg-ink'}`}>
      <span aria-hidden>{tone === 'pos' ? '▲' : '▼'}</span>{children}
    </span>
  )
}

function MetricLine({ label, m, fmt }: { label: string; m: Metric; fmt: (v: number) => string }) {
  return (
    <div className="border-b border-ink-600/70 py-2 last:border-0" title={`${m.source}${m.note ? ' · ' + m.note : ''}`}>
      <div className="flex items-baseline justify-between gap-3">
        <span className="text-sm text-paper-dim">{label}</span>
        <span className="flex items-center gap-2">
          <span className="text-sm font-semibold">{m.value != null ? fmt(m.value) : '—'}</span>
          <StatusBadge status={m.status} />
        </span>
      </div>
      <div className="truncate text-[11px] leading-4 text-paper-mute">{m.source}{m.note ? ` · ${m.note}` : ''}</div>
    </div>
  )
}

export function DistrictPanel({ d, data, onSimulate }: { d: District; data: AppData; onSimulate: (arr: number) => void }) {
  usePalette() // re-render when the theme (and so the colour ramp) changes
  const [tab, setTab] = useState<Tab>('Overview')
  const { strengths, weaknesses } = insightsFor(d, data.ranking)
  const aspectKeys = Object.keys(data.aspects.labels).filter((k) => d.aspects?.[k]?.reliable)

  const [lo, hi] = useMemo(() => {
    const s = data.districts.filter((x) => x.score != null).map((x) => x.score as number)
    return [Math.floor(Math.min(...s)), Math.ceil(Math.max(...s))]
  }, [data.districts])
  const color = d.score != null ? scoreColor(d.score, lo, hi) : 'rgb(var(--ink-500))'

  // customer mood: 4–5★ positive, 3★ neutral, 1–2★ negative
  const total = d.rating_hist.reduce((a, b) => a + b, 0)
  const mood = [
    { name: 'Happy (4–5★)', v: d.rating_hist[3] + d.rating_hist[4], c: POS },
    { name: 'Neutral (3★)', v: d.rating_hist[2], c: NEU },
    { name: 'Unhappy (1–2★)', v: d.rating_hist[0] + d.rating_hist[1], c: NEG },
  ]

  // score profile vs the average ranked district
  const radar = useMemo(() => {
    if (!d.components) return []
    const ranked = data.districts.filter((x) => x.components)
    return Object.keys(d.components).filter((k) => data.ranking.criteria[k]).map((k) => {
      const vals = ranked.map((x) => x.components![k]).filter((v): v is number => v != null)
      return {
        key: k, axis: shortLabel(k, data.ranking.criteria[k].label), full: data.ranking.criteria[k].label,
        you: d.components![k] ?? 0, avg: vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0,
      }
    })
  }, [d, data])

  // what customers talk about
  const talk = aspectKeys.map((k) => ({ key: k, name: data.aspects.labels[k], v: d.aspects![k].mentions, c: ASPECT_COLORS[k] }))
  const talkTotal = talk.reduce((a, b) => a + b.v, 0)
  const byPos = [...aspectKeys].sort((a, b) => (d.aspects![b].positive ?? 0) - (d.aspects![a].positive ?? 0))
  const byNeg = [...aspectKeys].sort((a, b) => (d.aspects![b].negative ?? 0) - (d.aspects![a].negative ?? 0))

  const stats = [
    { l: 'Reviews', v: d.metrics.reviews?.value, c: '#3E8FC9' },
    { l: 'Venues', v: d.metrics.venues?.value, c: '#8E6BD1' },
    { l: 'Cafés (SIRENE)', v: d.metrics.cafes_sirene?.value, c: '#D9488A' },
    { l: 'Residents', v: d.metrics.population?.value, c: '#3FA37A' },
  ].filter((s) => s.v != null)

  return (
    <div className="flex h-full min-h-0 flex-col">
      {/* header: score gauge + the one-line story */}
      <div className="flex items-center gap-5 border-b border-ink-600 px-5 py-4">
        {d.score != null ? (
          <>
            <Gauge value={d.score} color={color} />
            <div className="min-w-0">
              <div className="font-display text-lg font-bold leading-tight">Attractiveness score{data.ranking.status === 'provisional' ? ' (provisional)' : ''}</div>
              {d.top3_stability != null && (
                <p className="mt-1 text-sm text-paper-dim">
                  In the top 3 in <b className="text-paper">{pct(d.top3_stability)}</b> of weight draws
                  {d.rank_interval && <> · plausible rank {d.rank_interval[0]}–{d.rank_interval[1]}</>}
                </p>
              )}
            </div>
          </>
        ) : (
          <p className="text-sm text-paper-dim">
            <b className="text-paper">Not enough data to rank this district.</b> {d.metrics.reviews.value} reviews and {d.metrics.venues.value} venues collected;
            at least {data.ranking.min_reviews} reviews are needed.
          </p>
        )}
      </div>

      {/* tabs */}
      <div className="flex gap-1 px-4 pt-3" role="tablist">
        {TABS.map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}
            className={`relative rounded-full px-4 py-1.5 text-sm font-medium transition-colors ${tab === t ? 'text-crema-on' : 'text-paper-dim hover:bg-ink-600/60'}`}>
            {tab === t && <motion.span layoutId="panel-tab" className="absolute inset-0 rounded-full bg-crema" transition={{ type: 'spring', stiffness: 420, damping: 34 }} />}
            <span className="relative">{t}</span>
          </button>
        ))}
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-4 py-3">
        {tab === 'Overview' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 gap-3 min-[480px]:grid-cols-2">
              <Card title="Customer mood" hint={total ? `${int(total)} ratings` : undefined}>
                {total > 0 ? (
                  <>
                    <div className="relative mx-auto h-[148px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={mood} dataKey="v" nameKey="name" innerRadius={46} outerRadius={66} paddingAngle={3} cornerRadius={5} stroke="none" startAngle={90} endAngle={-270} animationDuration={900}>
                            {mood.map((m) => <Cell key={m.name} fill={m.c} />)}
                          </Pie>
                          <Tooltip {...TIP} formatter={(v: number, n) => [`${int(v)} (${pct(v / total)})`, n]} />
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
                        <div>
                          <div className="font-display text-2xl font-bold leading-none">{dec2(d.metrics.rating?.value)}</div>
                          <div className="text-[11px] text-paper-mute">avg rating</div>
                        </div>
                      </div>
                    </div>
                    <ul className="mt-1 space-y-0.5 text-xs">
                      {mood.map((m) => (
                        <li key={m.name} className="flex items-center justify-between gap-2">
                          <span className="flex items-center gap-1.5 text-paper-dim"><span className="h-2.5 w-2.5 rounded-full" style={{ background: m.c }} />{m.name}</span>
                          <b>{pct(m.v / total)}</b>
                        </li>
                      ))}
                    </ul>
                  </>
                ) : <p className="text-sm text-paper-mute">No ratings collected yet.</p>}
              </Card>

              <Card title="Score profile" hint="vs Paris average">
                {radar.length >= 3 ? (
                  <>
                    <div className="h-[160px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart data={radar} outerRadius="72%" margin={{ top: 4, right: 38, bottom: 4, left: 38 }}>
                          <PolarGrid stroke="rgb(var(--ink-600))" />
                          <PolarAngleAxis dataKey="axis" tick={{ fill: 'rgb(var(--paper-dim))', fontSize: 10.5 }} />
                          <PolarRadiusAxis domain={[0, 1]} tick={false} axisLine={false} />
                          <Radar name="Paris average" dataKey="avg" stroke="rgb(var(--neu))" strokeDasharray="4 3" fill="none" strokeWidth={1.5} isAnimationActive={false} />
                          <Radar name={`Paris ${d.name}`} dataKey="you" stroke="rgb(var(--crema))" fill="rgb(var(--crema-deep))" fillOpacity={0.32} strokeWidth={2} animationDuration={900} />
                          <Tooltip {...TIP} formatter={(v: number, n) => [dec2(v), n]} labelFormatter={(l) => radar.find((r) => r.axis === l)?.full ?? l} />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="mt-1 flex items-center justify-center gap-4 text-xs text-paper-dim">
                      <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-crema-deep" />This district</span>
                      <span className="flex items-center gap-1.5"><span className="h-0 w-3.5 border-t-2 border-dashed border-neu" />Average</span>
                    </div>
                  </>
                ) : <p className="text-sm text-paper-mute">Not enough criteria to draw a profile.</p>}
              </Card>
            </div>

            {stats.length > 0 && (
              <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${stats.length}, minmax(0, 1fr))` }}>
                {stats.map((s) => (
                  <div key={s.l} className="rounded-xl px-3 py-2" style={{ background: `${s.c}1A` }}>
                    <div className="font-display text-xl font-bold leading-tight" style={{ color: inkOf(s.c) }}><Counter value={s.v} format={int as any} /></div>
                    <div className="text-[11px] text-paper-dim">{s.l}</div>
                  </div>
                ))}
              </div>
            )}

            {(strengths.length > 0 || weaknesses.length > 0) && (
              <div className="space-y-2 rounded-2xl border border-ink-600 bg-ink-800 p-3.5">
                {strengths.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="mr-1 w-[76px] text-xs font-semibold text-pos">Strengths</span>
                    {strengths.slice(0, 3).map((s) => <Chip key={s.key} tone="pos" title={s.detail}>{shortLabel(s.key, s.label)}</Chip>)}
                  </div>
                )}
                {weaknesses.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="mr-1 w-[76px] text-xs font-semibold text-neg">Weaknesses</span>
                    {weaknesses.slice(0, 3).map((s) => <Chip key={s.key} tone="neg" title={s.detail}>{shortLabel(s.key, s.label)}</Chip>)}
                  </div>
                )}
              </div>
            )}
            {d.imputed.length > 0 && (
              <p className="px-1 text-[11px] text-paper-mute">Median used for lack of data: {d.imputed.map((k) => shortLabel(k, data.ranking.criteria[k]?.label)).join(', ')}.</p>
            )}
          </div>
        )}

        {tab === 'Customers' && (
          <div className="space-y-3">
            {d.aspects && aspectKeys.length > 0 ? (
              <>
                <Card title="What customers talk about" hint={`${int(talkTotal)} mentions`}>
                  <div className="flex items-center gap-3">
                    <div className="h-[132px] w-[132px] shrink-0">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie data={talk} dataKey="v" nameKey="name" innerRadius={38} outerRadius={62} paddingAngle={2} cornerRadius={4} stroke="none" animationDuration={900}>
                            {talk.map((t) => <Cell key={t.key} fill={t.c} />)}
                          </Pie>
                          <Tooltip {...TIP} formatter={(v: number, n) => [`${int(v)} (${pct(v / talkTotal)})`, n]} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="min-w-0 flex-1 space-y-2 text-sm">
                      <div>
                        <div className="text-[11px] font-semibold uppercase tracking-wide text-pos">Most loved</div>
                        {byPos.slice(0, 2).map((k) => <div key={k} className="flex justify-between"><span>{data.aspects.labels[k]}</span><b className="text-pos">{pct(d.aspects![k].positive)}</b></div>)}
                      </div>
                      <div>
                        <div className="text-[11px] font-semibold uppercase tracking-wide text-neg">Most criticised</div>
                        {byNeg.slice(0, 2).map((k) => <div key={k} className="flex justify-between"><span>{data.aspects.labels[k]}</span><b className="text-neg">{pct(d.aspects![k].negative)}</b></div>)}
                      </div>
                    </div>
                  </div>
                </Card>
                <Card title="Sentiment by aspect" hint="red = negative · green = positive">
                  <ul className="space-y-1.5">
                    {aspectKeys.map((k) => {
                      const a = d.aspects![k]
                      return (
                        <li key={k} className="grid grid-cols-[124px_1fr_40px] items-center gap-2 text-xs" title={`${a.mentions} mentions`}>
                          <span className="flex items-center gap-1.5 truncate text-paper"><span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: ASPECT_COLORS[k] }} />{data.aspects.labels[k]}</span>
                          <SentimentBar negative={a.negative!} neutral={a.neutral!} positive={a.positive!} />
                          <b className="text-right text-pos">{pct(a.positive)}</b>
                        </li>
                      )
                    })}
                  </ul>
                </Card>
              </>
            ) : (
              <Card title="Customer themes">
                <p className="text-sm text-paper-dim">
                  {d.aspects ? 'Too few mentions in this district to draw reliable themes.' : <>Aspect analysis has not been run yet. Run <code>python3 pipeline/run_all.py</code>.</>}
                </p>
              </Card>
            )}
          </div>
        )}

        {tab === 'Sources' && (
          <div className="rounded-2xl border border-ink-600 bg-ink-800 px-3.5 py-1.5">
            {METRIC_ROWS.filter((r) => d.metrics[r.key]?.value != null).map((r) => <MetricLine key={r.key} label={r.label} m={d.metrics[r.key]} fmt={r.fmt} />)}
          </div>
        )}
      </div>

      <footer className="border-t border-ink-600 p-3.5">
        <button onClick={() => onSimulate(d.arr)} className="w-full rounded-xl bg-crema px-4 py-2.5 font-semibold text-white transition hover:bg-[#8F1840]">
          Simulate profitability in the {d.name}
        </button>
      </footer>
    </div>
  )
}
