import type { ReactNode } from 'react'

export function Section({ id, title, intro, children }: { id: string; title: string; intro?: ReactNode; children: ReactNode }) {
  return (
    <section id={id} className="border-t border-paper/10">
      <div className="mx-auto max-w-[1200px] px-4 py-16 md:px-6 md:py-24">
        <div className="mb-5 h-1.5 w-24 rounded-full" style={{ background: 'linear-gradient(90deg,#E0A526,#D9488A,#3E8FC9,#3FA37A)' }} />
        <h2 className="max-w-3xl font-display text-3xl font-bold leading-tight md:text-5xl">{title}</h2>
        {intro && <p className="mt-4 max-w-2xl text-base leading-relaxed text-paper-dim">{intro}</p>}
        <div className="mt-10 md:mt-12">{children}</div>
      </div>
    </section>
  )
}

export function Note({ children, tone = 'info' }: { children: ReactNode; tone?: 'info' | 'warn' }) {
  return (
    <div className={`rounded-xl border p-4 text-sm leading-relaxed ${tone === 'warn' ? 'border-crema/30 bg-crema/5 text-paper-dim' : 'border-ink-500 bg-ink-700/60 text-paper-dim'}`}>
      {children}
    </div>
  )
}
