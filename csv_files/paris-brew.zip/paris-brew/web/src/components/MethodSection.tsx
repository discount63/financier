import { useRef, useState } from 'react'
import { Note, Section } from './Section'
import { int, pct } from '../lib/format'
import type { IndicatorOverride } from '../lib/csv'
import type { AppData } from '../lib/types'

const TEMPLATE = 'arrondissement,students,transit_stations,rent_eur_m2_year,source\n13,,,,My source\n'

function download(name: string, text: string) {
  const url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url; a.download = name; a.click()
  URL.revokeObjectURL(url)
}

export function MethodSection({ data, overrides, onImport, onClear }: {
  data: AppData; overrides: IndicatorOverride[]; onImport: (text: string, name: string) => number; onClear: () => void
}) {
  const { meta, ranking } = data
  const a = meta.audit
  const file = useRef<HTMLInputElement>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const weights = Object.entries(ranking.criteria).sort((x, y) => y[1].weight - x[1].weight)
  const cfg = meta.absa_config

  const onFile = async (f: File | undefined) => {
    if (!f) return
    const n = onImport(await f.text(), f.name)
    setMsg(n ? `${n} districts imported from ${f.name}. The values now appear in the panels and the simulator.` : 'No valid row: check the "arrondissement" column (1 to 20).')
  }

  return (
    <Section id="methode" title="Method, data and limits"
      intro="Everything used to produce a number is written down here: where it comes from, how it is computed, what it does not say.">
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="font-display text-lg font-bold">The attractiveness score</h3>
          <p className="mt-1 text-sm leading-relaxed text-paper-dim">
            Each criterion is scaled between 0 and 1 (the lowest and highest 5% are clipped), oriented so that 1 is favourable, then weighted.
            A criterion missing for every district is dropped and the weights are renormalised; a value missing for a single district takes the median.
          </p>
          <table className="mt-4 w-full text-left text-sm">
            <thead className="text-xs text-paper-mute"><tr><th className="py-1.5 font-medium">Criterion</th><th className="font-medium">Source</th><th className="text-right font-medium">Weight</th></tr></thead>
            <tbody>
              {weights.map(([k, c]) => <tr key={k} className="border-t border-ink-600"><td className="py-2 pr-3 text-paper-dim">{c.label}</td><td className="pr-3 text-xs text-paper-mute">{c.source}</td><td className="whitespace-nowrap pl-2 text-right font-semibold">{pct(c.weight)}</td></tr>)}
            </tbody>
          </table>
          {ranking.dropped_criteria.length > 0 && <p className="mt-3 text-xs text-crema">Criteria not used for now: {ranking.dropped_criteria.map((k) => (k === 'price_pain' ? 'price frustration' : k === 'wait_pain' ? 'waiting-time frustration' : k)).join(', ')} (they depend on the aspect analysis).</p>}
          <p className="mt-3 text-xs leading-relaxed text-paper-mute">
            The ranking is "reliable" only if: the aspect analysis has been run, at most two districts lack data (fewer than {ranking.min_reviews} reviews), and each top-3 member stays in the top 3 in at least {pct(ranking.min_top3_stability)} of the {int(ranking.draws)} weight draws.
            K-Means clustering is a separate analysis: it describes similarities, it does not rank.
          </p>
        </div>

        <div className="card p-5">
          <h3 className="font-display text-lg font-bold">Aspect-based sentiment analysis (ABSA)</h3>
          <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-sm leading-relaxed text-paper-dim">
            <li>Each French or English review is split into clauses (“excellent coffee”, “unpleasant staff”).</li>
            <li>A multilingual embedding model (<code className="text-xs">{cfg.embedding_model?.split('/').pop()}</code>) compares each clause with sentences describing the nine aspects, in French and English, and with off-topic sentences.</li>
            <li>An XLM-RoBERTa model (<code className="text-xs">{cfg.sentiment_model?.split('/').pop()}</code>) gives the polarity of each clause: negative, neutral or positive.</li>
            <li>Results are aggregated by aspect and by district; below {int(30)} mentions, no percentage is shown.</li>
          </ol>
          <p className="mt-3 text-xs leading-relaxed text-paper-mute">
            Validation: results are compared with Google's sub-ratings (service, atmosphere, food), and a script draws 250 clauses to label by hand to measure precision and recall (<code>pipeline/validation</code>).
            Until that validation is done, errors on irony, mixed-language or very short reviews remain possible.
          </p>
          {meta.run_info && <p className="mt-2 text-xs text-paper-mute">Last run: {int(meta.run_info.reviews_analyzed)} reviews, {int(meta.run_info.clauses)} clauses, {int(meta.run_info.aspect_mentions)} aspect mentions.</p>}
        </div>

        <div className="card p-5">
          <h3 className="font-display text-lg font-bold">Data audit</h3>
          <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            {[
              ['Rows read from the exports', a.rows_read], ['Unique reviews in Paris', a.unique_reviews_paris], ['Venues', a.unique_venues_paris],
              ['Reviews with text, in scope', a.reviews_in_scope], ['Reviews analysed by ABSA (fr, en)', a.reviews_analyzable_by_absa],
              ['Duplicate IDs removed', a.duplicate_review_ids_removed], ['Reviews without text (left out of statistics)', a.rating_only_reviews_excluded_from_stats],
              ['Non-Paris addresses removed', a.rows_without_paris_postcode], ['Venues whose address differs from the query', a.venues_whose_address_differs_from_query],
            ].map(([l, v]) => <div key={String(l)} className="contents"><dt className="text-paper-dim">{l}</dt><dd className="text-right font-semibold">{int(v as number)}</dd></div>)}
          </dl>
          <p className="mt-3 text-xs leading-relaxed text-paper-mute">
            Venues by type: {Object.entries(a.venues_by_segment as Record<string, number>).map(([k, v]) => `${({ core: 'cafés', adjacent: 'bars and brasseries', restaurant: 'restaurants', excluded: 'off-topic (museums…)', unknown: 'unknown' } as any)[k] ?? k} ${v}`).join(' · ')}.
            Reviews from {a.review_date_min} to {a.review_date_max}, {pct(a.share_2026)} of them in 2026.
          </p>
        </div>

        <div className="card p-5">
          <h3 className="font-display text-lg font-bold">Add data: students, transit, rents</h3>
          <p className="mt-1 text-sm leading-relaxed text-paper-dim">These indicators are not filled in yet: no reliable source was found for all 20 districts, so nothing is made up. Import a CSV (one row per district) to display them and feed the simulator.</p>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <input ref={file} type="file" accept=".csv,text/csv" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
            <button onClick={() => file.current?.click()} className="rounded-lg bg-crema px-3.5 py-2 text-sm font-semibold text-crema-on hover:brightness-90">Import a CSV</button>
            <button onClick={() => download('district_indicators_template.csv', TEMPLATE)} className="rounded-lg border border-ink-500 px-3.5 py-2 text-sm hover:bg-ink-600">Download the template</button>
            {overrides.length > 0 && <button onClick={() => { onClear(); setMsg('Import removed.') }} className="rounded-lg border border-ink-500 px-3.5 py-2 text-sm text-paper-dim hover:bg-ink-600">Remove the import</button>}
          </div>
          {msg && <p className="mt-3 text-sm text-pos" role="status">{msg}</p>}
          <p className="mt-3 text-xs leading-relaxed text-paper-mute">
            Columns: <code>arrondissement</code>, <code>students</code>, <code>transit_stations</code>, <code>rent_eur_m2_year</code>, <code>source</code>. To include these values in the score, add them to <code>data/external/district_indicators.csv</code> and re-run the pipeline.
          </p>
        </div>
      </div>

      <h3 className="mb-3 mt-12 font-display text-2xl font-bold">What these results do not say</h3>
      <ul className="grid gap-3 text-sm leading-relaxed text-paper-dim md:grid-cols-2">
        {[
          'Google reviews come from customers who chose to write. They do not represent all Parisians, and above all not those who do not go to these venues.',
          `Collection takes the 25 to 50 most recent reviews of each venue (${pct(a.share_2026)} date from 2026). The number of reviews therefore does not measure a venue's popularity.`,
          'Cafés per resident counts residents, not visitors: it overstates competition in the centre. Hospitality activity is a footfall indicator, not a measured flow.',
          'The scope includes restaurants with café-type names: without them, some districts would have almost no reviews. Starbucks accounts for about 14% of reviews and is compared separately.',
          'Rents, students and transit are absent until a reliable file is provided. The score does not use them.',
          'With 20 districts, K-Means is exploratory. A score is a decision aid, not a revenue forecast.',
          meta.geometry_quality === 'official' ? 'Boundaries come from the official City of Paris file.' : 'The boundaries shown are a simplified version: drop the official "arrondissements" export from Paris Open Data into data/external/arrondissements.geojson for an accurate map.',
        ].map((t) => <li key={t} className="card p-4">{t}</li>)}
      </ul>

      <h3 className="mb-3 mt-12 font-display text-2xl font-bold">Sources</h3>
      <ul className="space-y-2 text-sm text-paper-dim">
        {meta.sources.map((s) => <li key={s.name}><a href={s.url} target="_blank" rel="noreferrer" className="font-medium text-paper underline decoration-ink-500 underline-offset-4 hover:decoration-crema">{s.name}</a>: {s.detail}</li>)}
      </ul>
      <Note>
        <b className="text-paper">Updating.</b> Drop new Apify exports into <code>data/raw/reviews</code>, run <code>python3 pipeline/run_all.py</code> and reload the site. Data generated on {new Date(meta.generated_at).toLocaleString('en-GB')}.
      </Note>
    </Section>
  )
}
