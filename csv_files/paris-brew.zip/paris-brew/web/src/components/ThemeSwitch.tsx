import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useRef, useState } from 'react'
import { THEMES, THEME_ORDER, useTheme, type ThemeId } from '../lib/theme'


/** Small palette button in the top bar: opens a grid of looks. The choice is remembered. */
export function ThemeSwitch() {
  const { theme, setTheme } = useTheme()
  const [open, setOpen] = useState(false)
  const box = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!open) return
    const down = (e: PointerEvent) => { if (!box.current?.contains(e.target as Node)) setOpen(false) }
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    window.addEventListener('pointerdown', down)
    window.addEventListener('keydown', key)
    return () => { window.removeEventListener('pointerdown', down); window.removeEventListener('keydown', key) }
  }, [open])

  const pick = (t: ThemeId) => {
    const root = document.documentElement
    root.classList.add('theme-fade')
    window.setTimeout(() => root.classList.remove('theme-fade'), 450)
    setTheme(t)
    setOpen(false)
  }
  const [a, b] = THEMES[theme].swatch

  return (
    <div ref={box} className="relative">
      <button onClick={() => setOpen((o) => !o)} aria-haspopup="menu" aria-expanded={open} aria-label={`Colour theme: ${THEMES[theme].label}`}
        className="flex h-9 items-center gap-2 rounded-full border border-ink-600 bg-ink-800 pl-1.5 pr-3 text-sm text-paper-dim transition-colors hover:border-ink-500 hover:text-paper">
        <span className="relative h-6 w-6 overflow-hidden rounded-full ring-1 ring-black/10" style={{ background: `linear-gradient(135deg, ${a} 50%, ${b} 50%)` }} />
        <span className="hidden sm:inline">Theme</span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div role="menu" initial={{ opacity: 0, y: -6, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.16 }}
            className="absolute right-0 top-11 z-50 w-[296px] rounded-2xl border border-ink-600 bg-ink-800 p-3 shadow-panel">
            <div className="mb-2 px-1 text-xs font-medium text-paper-mute">Colour theme</div>
            <div className="grid grid-cols-3 gap-1.5">
              {THEME_ORDER.map((id: ThemeId) => {
                const [c1, c2] = THEMES[id].swatch
                const on = id === theme
                const r = THEMES[id].map.ramp
                return (
                  <button key={id} role="menuitemradio" aria-checked={on} onClick={() => pick(id)}
                    className={`flex flex-col items-center gap-1.5 rounded-xl px-1 py-2 text-[12px] transition-colors ${on ? 'bg-ink-700 font-semibold text-paper ring-1 ring-crema' : 'text-paper-dim hover:bg-ink-700 hover:text-paper'}`}>
                    <span className="relative h-10 w-10 overflow-hidden rounded-full ring-1 ring-black/10" style={{ background: `conic-gradient(${c1} 0 33%, ${r[1]} 0 55%, ${r[2]} 0 75%, ${c2} 0)` }} />
                    <span className="leading-tight">{THEMES[id].label}</span>
                  </button>
                )
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
