import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useRef, useState, type ReactNode } from 'react'
import { Wordmark } from './Logo'
import type { AppData } from '../lib/types'

const NOTICE_KEY = 'financier-notice-seen'

const EXPLORE = [['carte', 'District map'], ['clients', 'What customers say'], ['top3', 'Top 3 districts'], ['simulateur', 'Profit simulator'], ['methode', 'Method & data']] as const

const DATA_LINKS = [
  ['Google Maps reviews (Apify)', 'https://apify.com'],
  ['SIRENE business register', 'https://www.data.gouv.fr/datasets/base-sirene-des-entreprises-et-de-leurs-etablissements-siren-siret'],
  ['INSEE population', 'https://www.insee.fr/fr/statistiques/fichier/7728806/dep75.pdf'],
  ['Paris Open Data', 'https://opendata.paris.fr/explore/dataset/arrondissements/'],
] as const

const TEAM = [
  ['Zayd El Khiri', 'EPF Graduate School of Engineering'],
  ['강나윤 · Nayun', "Sookmyung Women's University"],
  ['남하린 · Harin', "Sookmyung Women's University"],
  ['이예지 · Yeji', "Sookmyung Women's University"],
] as const

type Doc = 'privacy' | 'credits' | 'disclaimer'

const DOCS: Record<Doc, { title: string; body: ReactNode }> = {
  privacy: {
    title: 'Privacy',
    body: (
      <>
        <p>Financier is a static website: there is no account, no analytics and no tracking cookie.</p>
        <p>The only thing the site can store is a CSV of indicators that you import yourself (students, transit, rents). It stays in your browser and the "Clear" button in the Method section removes it.</p>
        <p>The site is hosted on Vercel. The typefaces come from Google Fonts and the landmark photos and descriptions from Wikipedia. Like any website you visit, these services receive your IP address; we do not collect anything ourselves.</p>
      </>
    ),
  },
  credits: {
    title: 'Credits & licences',
    body: (
      <>
        <p>Reviews: Google Maps, collected with Apify and analysed for this study only. Open data: INSEE and the SIRENE business register. Arrondissement boundaries: Paris open data. Surrounding departments: Étalab open licence (france-geojson).</p>
        <p>Landmark photos and descriptions come from Wikipedia and Wikimedia Commons; each image keeps the licence of its author (mostly CC BY-SA).</p>
        <p>Typefaces: Fraunces, Bricolage Grotesque and Hanken Grotesk (SIL Open Font License). Map rendering: MapLibre GL.</p>
      </>
    ),
  },
  disclaimer: {
    title: 'Disclaimer',
    body: (
      <>
        <p>Financier is an academic project (Applied Data Science, Sookmyung Women's University). It is not financial or investment advice.</p>
        <p>Scores come from public data and a sample of online reviews. Indicators without a source are left out rather than guessed, and every estimate is labelled as such. Read the Method section before relying on a number.</p>
      </>
    ),
  },
}

function Modal({ doc, onClose }: { doc: Doc; onClose: () => void }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); onClose() } }
    window.addEventListener('keydown', k, true)
    return () => window.removeEventListener('keydown', k, true)
  }, [onClose])
  const { title, body } = DOCS[doc]
  return (
    <motion.div className="fixed inset-0 z-[70] grid place-items-center bg-deep-900/60 p-4 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose}>
      <motion.div role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}
        initial={{ y: 24, opacity: 0, scale: 0.98 }} animate={{ y: 0, opacity: 1, scale: 1 }} exit={{ y: 12, opacity: 0 }} transition={{ duration: 0.3, ease: [0.2, 0.9, 0.2, 1] }}
        className="w-full max-w-lg rounded-2xl bg-ink-800 p-6 shadow-panel">
        <h2 className="font-display text-2xl font-bold">{title}</h2>
        <div className="mt-3 space-y-3 text-sm leading-relaxed text-paper-dim">{body}</div>
        <button onClick={onClose} className="mt-5 rounded-lg bg-crema px-4 py-2 text-sm font-semibold text-crema-on hover:brightness-90">Close</button>
      </motion.div>
    </motion.div>
  )
}

function Col({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <h3 className="font-display text-base font-bold text-deep-text">{title}</h3>
      <ul className="mt-4 space-y-2.5 text-[15px] text-deep-mute">{children}</ul>
    </div>
  )
}
const linkCls = 'transition-colors hover:text-deep-text'

export function Footer({ data }: { data: AppData }) {
  const [doc, setDoc] = useState<Doc | null>(null)
  const [notice, setNotice] = useState(false)
  const footerRef = useRef<HTMLElement>(null)
  // like a cookie banner, but it only slides up once the footer comes into view, so it never covers the map or the district panel
  useEffect(() => {
    let seen = false
    try { seen = !!localStorage.getItem(NOTICE_KEY) } catch { /* storage unavailable: show the notice */ }
    if (seen || !footerRef.current) return
    const io = new IntersectionObserver(([e]) => setNotice(e.isIntersecting), { threshold: 0 })
    io.observe(footerRef.current)
    return () => io.disconnect()
  }, [])
  const dismissedRef = useRef(false)
  const dismiss = () => {
    dismissedRef.current = true
    setNotice(false)
    try { localStorage.setItem(NOTICE_KEY, '1') } catch { /* storage unavailable: the notice simply shows again next time */ }
  }
  const open = (d: Doc) => (e: React.MouseEvent) => { e.preventDefault(); setDoc(d) }

  return (
    <>
      <footer ref={footerRef} className="relative overflow-hidden bg-deep-900 text-deep-mute" aria-label="Site footer">
        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full opacity-30 blur-3xl" style={{ background: 'radial-gradient(circle, rgb(var(--glow-1)), transparent 65%)' }} />
        <div className="relative mx-auto max-w-[1200px] px-4 pb-28 pt-16 md:px-6 md:pb-24">
          <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr_1.1fr] lg:gap-12">
            <div>
              <Wordmark light />
              <p className="mt-5 max-w-xs text-[15px] leading-relaxed">
                A decision tool for opening a €1.50 Korean-style café in Paris: {data.meta.global.reviews.toLocaleString('en-GB')} Google Maps reviews, public open data and a profit simulator, district by district.
              </p>
              <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-white/15 px-3 py-1.5 text-xs">
                <span className="h-2 w-2 rounded-full bg-[#5FD3A0]" /> No account · no tracking
              </div>
            </div>
            <Col title="Explore">
              {EXPLORE.map(([id, label]) => <li key={id}><a className={linkCls} href={`#${id}`}>{label}</a></li>)}
            </Col>
            <Col title="Data">
              {DATA_LINKS.map(([name, url]) => <li key={name}><a className={linkCls} href={url} target="_blank" rel="noreferrer">{name}</a></li>)}
              <li><a className={linkCls} href="https://www.wikipedia.org" target="_blank" rel="noreferrer">Wikipedia (photos)</a></li>
            </Col>
            <Col title="Team">
              {TEAM.map(([name, note]) => <li key={name}><span className="text-deep-text">{name}</span>{note && <span className="block text-[13px] opacity-80">{note}</span>}</li>)}
            </Col>
            <Col title="Project">
              <li>Applied Data Science</li>
              <li>Sookmyung Women's University</li>
              <li><a className={linkCls} href="#privacy" onClick={open('privacy')}>Privacy</a></li>
              <li><a className={linkCls} href="#credits" onClick={open('credits')}>Credits & licences</a></li>
              <li><a className={linkCls} href="#disclaimer" onClick={open('disclaimer')}>Disclaimer</a></li>
            </Col>
          </div>
          <div className="mt-14 flex flex-col items-start justify-between gap-3 border-t border-white/10 pt-6 text-sm md:flex-row md:items-center">
            <span>© 2026 Financier. Academic project, not financial advice.</span>
            <a href="#carte" className={`${linkCls} inline-flex items-center gap-1.5`}>Back to the map <span aria-hidden>↑</span></a>
          </div>
        </div>
      </footer>

      {/* notice, same idea as a cookie banner but honest: nothing to accept */}
      <AnimatePresence>
        {notice && !dismissedRef.current && (
          <motion.div role="region" aria-label="Privacy notice" initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 40, opacity: 0 }} transition={{ duration: 0.4, delay: 0.3 }}
            className="fixed inset-x-3 bottom-3 z-50 mx-auto flex max-w-4xl items-center gap-4 rounded-2xl border border-glow-1/50 bg-deep-900/95 p-4 text-deep-text shadow-2xl backdrop-blur md:bottom-5 md:gap-5 md:p-5">
            <span className="hidden h-12 w-12 shrink-0 place-items-center rounded-xl bg-glow-1/20 text-2xl md:grid" aria-hidden>☕</span>
            <div className="min-w-0 flex-1 text-sm">
              <div className="font-display text-base font-bold md:text-lg">We value your privacy</div>
              <p className="mt-0.5 text-deep-mute">
                This site sets no tracking cookies. It only remembers what you import (a CSV of indicators) in your own browser, and nothing is sent anywhere.{' '}
                <a href="#privacy" onClick={open('privacy')} className="font-medium text-glow-1 underline-offset-2 hover:underline">Read the privacy note</a>
              </p>
            </div>
            <button onClick={dismiss} className="shrink-0 rounded-xl border border-white/25 px-5 py-2.5 text-sm font-semibold hover:bg-white/10">Got it</button>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>{doc && <Modal doc={doc} onClose={() => setDoc(null)} />}</AnimatePresence>
    </>
  )
}
