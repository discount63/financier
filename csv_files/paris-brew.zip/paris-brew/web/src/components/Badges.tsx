import type { Status } from '../lib/types'

const LABEL: Record<Status, string> = { measured: 'Measured', estimate: 'Estimate', unavailable: 'Not available' }
const STYLE: Record<Status, string> = {
  measured: 'text-teal-glow border-teal-mid/60 bg-teal-deep/50',
  estimate: 'text-crema border-crema-deep/60 bg-crema-deep/10',
  unavailable: 'text-paper-mute border-ink-500 bg-ink-700/60',
}

export function StatusBadge({ status, title }: { status: Status; title?: string }) {
  return (
    <span title={title} className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium leading-4 ${STYLE[status]}`}>
      {LABEL[status]}
    </span>
  )
}

export function ConfidenceBadge({ level }: { level: 'high' | 'medium' | 'low' }) {
  const map = {
    high: ['High confidence', 'text-pos border-pos/40'],
    medium: ['Medium confidence', 'text-crema border-crema/40'],
    low: ['Low confidence', 'text-neg border-neg/40'],
  } as const
  return <span className={`rounded-full border px-2 py-0.5 text-xs font-medium ${map[level][1]}`}>{map[level][0]}</span>
}
