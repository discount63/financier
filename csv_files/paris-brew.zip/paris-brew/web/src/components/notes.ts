export const ARR_COLOR_NOTE =
  'The score combines population, activity, competition, customer frustration and takeaway demand; the weights are in the Method section.'
