import { TIP } from '../lib/chartStyle'
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { HBar, SentimentBar } from './Bars'
import { Note, Section } from './Section'
import { ASPECT_COLORS, inkOf, NEG, NEU, POS } from '../lib/colors'
import { dec1, dec2, int, pct } from '../lib/format'
import type { AppData, AspectStats, Dist } from '../lib/types'

function DistBars({ rows, color = '#3E8FC9' }: { rows: Dist[]; color?: string }) {
  return (
    <div className="space-y-2.5">
      {rows.map((r) => (
        <div key={r.label}>
          <div className="mb-1 flex justify-between text-xs"><span className="text-paper-dim">{r.label}</span><span className="text-paper">{pct(r.share)} <span className="text-paper-mute">({int(r.count)})</span></span></div>
          <HBar value={r.share} color={color} label={`${r.label} : ${pct(r.share)}`} />
        </div>
      ))}
    </div>
  )
}

function Panel({ title, note, children }: { title: string; note?: string; children: React.ReactNode }) {
  return (
    <div className="card p-5">
      <h3 className="font-display text-lg font-bold">{title}</h3>
      {note && <p className="mt-1 text-xs leading-relaxed text-paper-mute">{note}</p>}
      <div className="mt-4">{children}</div>
    </div>
  )
}

const RECO: { title: string; aspects: string[]; idea: string }[] = [
  { title: 'Menu design', aspects: ['variety', 'price'], idea: 'A short menu with one clear price, rather than a long list of extras.' },
  { title: 'Drink selection', aspects: ['coffee_quality', 'taste'], idea: 'Focus expertise on a few consistent recipes, and measure consistency cup by cup.' },
  { title: 'Service organisation', aspects: ['service', 'waiting_time'], idea: 'Size the counter for peak hours and train for hospitality, not just preparation.' },
  { title: 'Takeaway strategy', aspects: ['takeaway'], idea: 'A dedicated takeaway flow with pre-ordering, if the declared demand justifies it.' },
  { title: 'Venue layout', aspects: ['comfort', 'atmosphere'], idea: 'Decide early how much seating to keep: comfort affects the rating but costs rent.' },
]

function finding(a: AspectStats | undefined, label: string): string {
  if (!a || !a.reliable) return `${label}: too few mentions to conclude.`
  const motif = a.top_complaints?.[0]?.term
  return `${label}: ${pct(a.negative)} negative mentions out of ${int(a.mentions)}${motif ? `, most frequent theme “${motif}”` : ''}.`
}

export function AspectsSection({ data }: { data: AppData }) {
  const { aspects, meta } = data
  const s = meta.structured
  const keys = Object.keys(aspects.labels)
  const global = aspects.global
  const ordered = global ? [...keys].sort((a, b) => (global[b]?.mentions ?? 0) - (global[a]?.mentions ?? 0)) : keys
  const subs = [
    { k: 'service', l: 'Service' }, { k: 'ambiance', l: 'Atmosphere' }, { k: 'food', l: 'Food and drinks' },
  ].map((x) => ({ ...x, ...s.sub_ratings[x.k] }))
  const ch = meta.chains
  const rating = s.rating_hist.map((count, i) => ({ star: `${i + 1}★`, count, tone: i < 2 ? NEG : i === 2 ? NEU : POS }))

  return (
    <Section id="clients" title="What customers want, and what frustrates them"
      intro={`Analysis of ${int(meta.global.reviews)} reviews. The nine aspects are measured clause by clause with pre-trained language models, not with a keyword list.`}>
      {aspects.available && global ? (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {ordered.map((k) => {
              const a = global[k]
              return (
                <article key={k} className="card p-5" style={{ borderTop: `3px solid ${ASPECT_COLORS[k]}`, background: `linear-gradient(180deg, ${ASPECT_COLORS[k]}1A, transparent 55%), var(--panel)` }}>
                  <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                    <h3 className="font-display text-lg font-bold" style={{ color: inkOf(ASPECT_COLORS[k]) }}>{aspects.labels[k]}</h3>
                    <span className="text-xs text-paper-mute">{int(a.mentions)} mentions · {pct(a.review_share, 1)} of reviews</span>
                  </div>
                  {a.reliable ? (
                    <>
                      <div className="mt-3"><SentimentBar negative={a.negative!} neutral={a.neutral!} positive={a.positive!} /></div>
                      <div className="mt-1 flex justify-between text-xs text-paper-mute"><span>{pct(a.negative)} negative</span><span>{pct(a.neutral)} neutral</span><span>{pct(a.positive)} positive</span></div>
                      {a.rating_correlation != null && (
                        <p className="mt-3 text-xs text-paper-dim">
                          Link with the Google rating: correlation of {dec2(a.rating_correlation)}
                          {a.rating_when_negative != null && a.rating_when_positive != null && <> · average rating {dec1(a.rating_when_negative)} when the aspect is negative, {dec1(a.rating_when_positive)} when it is positive</>}.
                        </p>
                      )}
                      {!!a.top_complaints?.length && (
                        <div className="mt-3"><div className="text-xs font-medium text-neg">Most frequent complaints</div>
                          <div className="mt-1.5 flex flex-wrap gap-1.5">{a.top_complaints.map((t) => <span key={t.term} title={`“${t.example}”`} className="rounded-full border border-neg/30 px-2 py-0.5 text-xs text-paper-dim">{t.term} · {t.count}</span>)}</div></div>
                      )}
                      {!!a.top_praise?.length && (
                        <div className="mt-3"><div className="text-xs font-medium text-pos">What is most appreciated</div>
                          <div className="mt-1.5 flex flex-wrap gap-1.5">{a.top_praise.map((t) => <span key={t.term} title={`“${t.example}”`} className="rounded-full border border-pos/30 px-2 py-0.5 text-xs text-paper-dim">{t.term} · {t.count}</span>)}</div></div>
                      )}
                    </>
                  ) : <p className="mt-3 text-sm text-paper-mute">Too few mentions for a reliable percentage.</p>}
                </article>
              )
            })}
          </div>

          {data.aspects.validation && Object.keys(data.aspects.validation).length > 0 && (
            <div className="mt-6">
              <Note>
                <b className="text-paper">Consistency check.</b> Google also asks some customers for sub-ratings (service, atmosphere, food). If the text analysis is right, it should point the same way:{' '}
                {Object.entries(data.aspects.validation).map(([k, v]) => `${aspects.labels[k]} ↔ ${v.google_sub_rating} sub-rating: correlation ${dec2(v.spearman)} (${int(v.n)} reviews)`).join('; ')}.
              </Note>
            </div>
          )}

          <h3 className="mb-4 mt-14 font-display text-2xl font-bold">What this changes for the concept</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {RECO.map((r) => (
              <div key={r.title} className="card p-5">
                <h4 className="font-display text-lg font-bold">{r.title}</h4>
                <ul className="mt-2 space-y-1 text-sm text-paper-dim">{r.aspects.map((k) => <li key={k}>{finding(global[k], aspects.labels[k])}</li>)}</ul>
                <p className="mt-3 text-sm"><span className="text-crema">Idea to test:</span> {r.idea}</p>
              </div>
            ))}
          </div>
        </>
      ) : (
        <Note tone="warn">
          <b className="text-crema">Aspect analysis has not been run yet.</b> It needs to download two language models (internet required, about 1.5 GB the first time):
          <pre className="mt-2 overflow-x-auto rounded-lg bg-ink-950 p-3 text-sm text-crema">python3 pipeline/run_all.py</pre>
          The nine aspects (price, taste, coffee quality, service, waiting time, atmosphere, comfort, variety, takeaway), the most frequent complaints and the recommendations will appear here. In the meantime, here is what Google already measures without any text analysis.
        </Note>
      )}

      <h3 className="mb-4 mt-14 font-display text-2xl font-bold">What Google already measures</h3>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Panel title="Rating distribution" note={`${int(meta.global.reviews)} reviews with text. ${pct(meta.global.pct_1_2)} are 1- or 2-star ratings.`}>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={rating} margin={{ top: 6, right: 4, left: 4, bottom: 0 }}>
                <XAxis dataKey="star" tickLine={false} axisLine={false} tick={{ fill: 'rgb(var(--paper-mute))', fontSize: 12 }} />
                <YAxis hide />
                <Tooltip cursor={{ fill: 'rgb(var(--paper) / 0.06)' }} {...TIP} formatter={(v: number) => [`${int(v)} reviews`, '']} labelFormatter={() => ''} />
                <Bar dataKey="count" radius={[4, 4, 0, 0]} maxBarSize={44}>{rating.map((r) => <Cell key={r.star} fill={r.tone} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
        <Panel title="Sub-ratings given by customers" note="Share of 1- or 2-star sub-ratings, by theme (field provided by Google).">
          <div className="space-y-3">
            {subs.map((x) => (
              <div key={x.k}>
                <div className="mb-1 flex justify-between text-xs"><span className="text-paper-dim">{x.l}</span><span>{pct(x.share_1_2)} at 1–2★ · mean {dec2(x.mean)} <span className="text-paper-mute">({int(x.n)})</span></span></div>
                <HBar value={x.share_1_2} max={0.4} color={NEG} label={`${x.l}: ${pct(x.share_1_2)} low ratings`} />
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Chain vs independents" note={`Starbucks is analysed separately: ${ch.chain.venues} venues, ${pct(ch.chain.reviews / meta.global.reviews)} of reviews.`}>
          <div className="space-y-4 text-sm">
            {([['chain', 'Starbucks'], ['independent', 'Other venues']] as const).map(([k, l]) => (
              <div key={k}>
                <div className="flex justify-between"><span className="text-paper-dim">{l}</span><span className="font-semibold">{dec2(ch[k].rating_mean)} / 5</span></div>
                <div className="mt-1 text-xs text-paper-mute">{int(ch[k].reviews)} reviews · {int(ch[k].venues)} venues · {pct(ch[k].pct_1_2)} rated 1–2★</div>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Declared price per person" note="Band given by the reviewer, when they fill it in."><DistBars rows={s.price_band} /></Panel>
        <Panel title="Declared waiting time"><DistBars rows={s.wait} color="#9A6B45" /></Panel>
        <Panel title="Dine-in or takeaway" note="Order type declared in the review."><DistBars rows={s.order_type} /></Panel>
      </div>
      {s.lexical.terms.length > 0 && (
        <details className="mt-6 text-sm text-paper-dim">
          <summary className="cursor-pointer text-paper-mute hover:text-paper">Words most associated with 1–2 star reviews</summary>
          <p className="mt-2 max-w-2xl text-xs text-paper-mute">{s.lexical.note} ({int(s.lexical.negative_reviews)} reviews.) The words are in French, as in the reviews. This list describes a vocabulary of annoyance; it does not replace the aspect analysis.</p>
          <div className="mt-2 flex flex-wrap gap-1.5">{s.lexical.terms.map((t) => <span key={t.term} className="rounded-full border border-ink-500 px-2 py-0.5 text-xs">{t.term} · {t.count}</span>)}</div>
        </details>
      )}
    </Section>
  )
}
