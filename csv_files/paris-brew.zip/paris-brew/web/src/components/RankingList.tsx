import { motion } from 'motion/react'
import { ARR_COLOR_NOTE } from './notes'
import { dec1 } from '../lib/format'
import { scoreColor } from '../lib/colors'
import { usePalette } from '../lib/theme'
import type { AppData } from '../lib/types'

const relPoint = (e: React.MouseEvent) => {
  const sec = (e.currentTarget as HTMLElement).closest('section')
  const r = sec?.getBoundingClientRect()
  return r ? { x: e.clientX - r.left, y: e.clientY - r.top } : undefined
}

export function RankingList({ data, onSelect, scoreDomain, highlight }: {
  data: AppData; onSelect: (arr: number, at?: { x: number; y: number }) => void; scoreDomain: [number, number]; highlight: number[]
}) {
  usePalette() // re-render when the theme (and so the colour ramp) changes
  const ranked = data.districts.filter((d) => d.score != null).sort((a, b) => (a.rank ?? 99) - (b.rank ?? 99))
  const out = data.districts.filter((d) => d.score == null)
  const provisional = data.ranking.status === 'provisional'
  return (
    <div className="flex h-full flex-col">
      <div className="px-5 pb-3 pt-5">
        <h2 className="font-display text-xl font-bold">District ranking</h2>
        <p className="mt-1 text-sm text-paper-dim">
          {provisional ? 'Provisional: see the caveats on the left.' : 'Attractiveness score for a €1.50 café.'} Click a row or the map.
        </p>
      </div>
      <ol className="flex-1 space-y-1 overflow-y-auto px-3 pb-3">
        {ranked.map((d, i) => (
          <motion.li key={d.arr} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.02, duration: 0.35 }}>
            <button onClick={(e) => onSelect(d.arr, relPoint(e))}
              className="group flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition-colors hover:bg-ink-600/60">
              <span className="w-6 text-right font-display text-sm text-paper-mute">{d.rank}</span>
              <span className="w-14 text-sm font-semibold">
                {d.name}
                {highlight.includes(d.arr) && <span className="ml-1 text-crema" title="Top 3">★</span>}
              </span>
              <span className="relative h-2 flex-1 rounded-full bg-ink-600/70">
                <span className="absolute inset-y-0 left-0 rounded-full"
                  style={{ width: `${d.score}%`, background: scoreColor(d.score!, scoreDomain[0], scoreDomain[1]) }} />
              </span>
              <span className="w-10 text-right text-sm font-semibold">{dec1(d.score)}</span>
            </button>
          </motion.li>
        ))}
        {out.length > 0 && (
          <li className="px-2 pt-4">
            <div className="text-xs font-medium text-paper-mute">Not ranked: insufficient data</div>
            {out.map((d) => (
              <button key={d.arr} onClick={(e) => onSelect(d.arr, relPoint(e))} className="mt-1 flex w-full items-center justify-between rounded-lg px-2 py-2 text-left text-sm text-paper-dim hover:bg-ink-600/60">
                <span>{d.name}</span>
                <span className="text-xs">{d.metrics.reviews.value} reviews, {d.metrics.venues.value} venues</span>
              </button>
            ))}
          </li>
        )}
      </ol>
      <p className="border-t border-ink-600 px-5 py-3 text-xs text-paper-mute">{ARR_COLOR_NOTE}</p>
    </div>
  )
}
