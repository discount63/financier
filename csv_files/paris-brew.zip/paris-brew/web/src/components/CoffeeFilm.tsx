import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useMemo, useRef, useState } from 'react'

/* ============================================================================
   "Parisians & coffee": three short animated stories, drawn in SVG.
   Everything moves with CSS keyframes (legs, steam, rain) and Motion (positions),
   so it stays light. The stories are illustrations, not data.
   ========================================================================== */

const SERIF = 'Fraunces, Georgia, serif'
const GROUND = 345
const K = 1.08 // character scale

type Mood = 'happy' | 'ok' | 'sad' | 'sleepy'
type Fx = 'rain' | 'zzz' | 'sparkle' | 'talk' | null

interface Beat {
  caption?: string
  x?: number; dur?: number; hold?: number
  walk?: boolean; step?: number
  pose?: 'stand' | 'sit'
  mood?: Mood; fx?: Fx; cup?: boolean; gone?: boolean
  clock?: string; energy?: number; gloom?: number; sunX?: number
  sign?: string; queue?: number; tableCups?: boolean; friendTalk?: boolean; coin?: string
  choice?: { label: string; go: string }[]
}
interface Episode { id: string; tab: string; start: Beat; beats: Record<string, Beat[]>; outro: string }

const EPISODES: Episode[] = [
  {
    id: 'metro', tab: '08:10 · The metro run',
    start: { x: 90, pose: 'stand', mood: 'sleepy', fx: null, cup: false, clock: '08:10', energy: 25, gloom: 0.5, sunX: 150, sign: 'Next train: 8 min' },
    beats: {
      main: [
        { caption: '08:10. Léa steps out of her building. Her metro leaves in 8 minutes, and she has not had a coffee yet.', hold: 2.6 },
        { caption: 'On the corner, the café smells of fresh coffee…', x: 400, dur: 2.8, walk: true, step: 0.55, fx: 'zzz', hold: 0.6 },
        { caption: 'What should Léa do?', fx: null, choice: [{ label: 'Grab a coffee (1 minute)', go: 'a' }, { label: 'No time, skip it', go: 'b' }] },
      ],
      a: [
        { caption: 'One minute at the counter.', x: 430, dur: 0.6, walk: true, hold: 0.9 },
        { caption: 'The first sip. The street suddenly looks brighter.', cup: true, mood: 'happy', fx: 'sparkle', energy: 85, gloom: 0, hold: 2.4 },
        { caption: 'She walks faster, says bonjour to the baker and reaches the metro with two minutes to spare.', x: 800, dur: 1.9, walk: true, step: 0.36, clock: '08:16', energy: 92, sign: 'Next train: 1 min', hold: 0.8 },
        { caption: 'For many Parisians the day starts exactly like this: a quick coffee on the way.', gone: true, hold: 2.8 },
      ],
      b: [
        { caption: 'No coffee. Every step feels heavier, and a little grey cloud follows her.', x: 650, dur: 3.8, walk: true, step: 0.85, mood: 'sad', fx: 'rain', gloom: 1, energy: 12, hold: 0.4 },
        { caption: 'The doors close right in front of her. Next train in 6 minutes.', x: 790, dur: 1.9, walk: true, step: 0.85, clock: '08:19', sign: 'Next train: 6 min', hold: 2.2 },
        { caption: 'In Paris, coffee is part of the commute. Skip it and the whole morning drags.', mood: 'sleepy', fx: 'zzz', hold: 2.8 },
      ],
    },
    outro: 'Coffee is a daily ritual, and very often it is drunk on the move.',
  },
  {
    id: 'terrace', tab: '13:30 · The terrace',
    start: { x: -40, pose: 'stand', mood: 'happy', fx: null, cup: false, clock: '13:30', energy: 60, gloom: 0, sunX: 260, tableCups: false, friendTalk: false },
    beats: {
      main: [
        { caption: 'Lunch break. Léa meets an old friend on a café terrace.', x: 420, dur: 2.8, walk: true, step: 0.5, hold: 0.3 },
        { caption: 'Two coffees arrive.', pose: 'sit', tableCups: true, clock: '13:32', hold: 2 },
        { caption: 'The cups are empty after five minutes…', fx: 'talk', sunX: 480, clock: '13:50', hold: 2.6 },
        { caption: '…the conversation lasts forty-five.', fx: null, friendTalk: true, sunX: 690, clock: '14:15', hold: 2.6 },
        { caption: 'In Paris a café is a place as much as a drink: people pay for the seat, the sun and the time.', friendTalk: false, fx: 'sparkle', hold: 3 },
      ],
    },
    outro: 'The classic Parisian café sells time and a seat. That is its strength, and also why it is rarely cheap.',
  },
  {
    id: 'queue', tab: '18:00 · The queue',
    start: { x: -40, pose: 'stand', mood: 'ok', fx: null, cup: false, clock: '18:00', energy: 35, gloom: 0.15, sunX: 820, queue: 0 },
    beats: {
      main: [
        { caption: '18:00, after class. Léa needs a coffee before two hours of revision, on a student budget.', x: 470, dur: 2.6, walk: true, step: 0.55, hold: 0.8 },
        { caption: 'Two options on the same street.', choice: [{ label: 'Join the queue at the classic café', go: 'a' }, { label: 'Try the €1.50 counter', go: 'b' }] },
      ],
      a: [
        { caption: 'Three people ahead of her. The queue barely moves.', x: 350, dur: 1.1, walk: true, hold: 1.2 },
        { caption: 'Four minutes…', queue: 1, x: 308, dur: 0.7, walk: true, clock: '18:05', hold: 1.4 },
        { caption: 'Eight minutes…', queue: 2, x: 266, dur: 0.7, walk: true, clock: '18:09', mood: 'sad', hold: 1.4 },
        { caption: 'A good coffee, but eleven minutes and €3.50 later.', queue: 3, x: 224, dur: 0.7, walk: true, cup: true, coin: '−€3.50', clock: '18:11', mood: 'ok', energy: 70, hold: 2.8 },
      ],
      b: [
        { caption: 'A quick counter: order, pay, pick up.', x: 712, dur: 1.6, walk: true, step: 0.45, hold: 0.6 },
        { caption: 'One minute and €1.50 later, she is on her way to the library.', cup: true, coin: '−€1.50', clock: '18:01', mood: 'happy', fx: 'sparkle', energy: 85, hold: 2.8 },
      ],
    },
    outro: 'When time and money are short, a fast, affordable cup wins. Where in Paris are there the most people like Léa? That is what our study measures.',
  },
]

type State = Required<Omit<Beat, 'caption' | 'choice' | 'dur' | 'hold' | 'walk' | 'step' | 'coin'>>
const BASE: State = { x: 90, pose: 'stand', mood: 'ok', fx: null, cup: false, gone: false, clock: '', energy: 50, gloom: 0, sunX: 200, sign: '', queue: 0, tableCups: false, friendTalk: false }

function merge(list: Beat[]): State {
  const s: any = { ...BASE }
  for (const b of list) for (const [k, v] of Object.entries(b)) if (k in BASE && v !== undefined) s[k] = v
  return s
}

/* ---------- the character ---------- */

function Person({ x, from, dur, walking, step = 0.55, pose = 'stand', mood = 'ok', cup = false, fx = null, gone = false, flip = false, coin, run,
  coat = '#C9A77B', scarf = '#C8342F', hair = '#3A2418', beret = true }: {
  x: number; from?: number; dur: number; walking: boolean; step?: number; pose?: 'stand' | 'sit'; mood?: Mood; cup?: boolean; fx?: Fx; gone?: boolean
  flip?: boolean; coin?: string; run?: string; coat?: string; scarf?: string; hair?: string; beret?: boolean
}) {
  const skin = '#F1C7A2'
  const sleeve = coat
  const eyes = mood === 'happy' ? <path d="M2.5 -102 q1.6 -2.2 3.2 0 M7.5 -102 q1.6 -2.2 3.2 0" stroke="#2B1A14" strokeWidth="1.3" fill="none" strokeLinecap="round" />
    : mood === 'sleepy' ? <path d="M2.5 -101.5 h3 M7.5 -101.5 h3" stroke="#2B1A14" strokeWidth="1.3" strokeLinecap="round" />
      : <g fill="#2B1A14"><circle cx="4.2" cy="-102" r="1.4" /><circle cx="9" cy="-102" r="1.4" />{mood === 'sad' && <path d="M2.5 -106.5 l3 1.3 M10.8 -106.5 l-3 1.3" stroke="#2B1A14" strokeWidth="1.1" strokeLinecap="round" />}</g>
  const mouth = mood === 'happy' ? <path d="M4 -95.5 q2.8 3 5.6 0" stroke="#8A3A2A" strokeWidth="1.4" fill="none" strokeLinecap="round" />
    : mood === 'sad' ? <path d="M4.2 -94 q2.6 -2.4 5.2 0" stroke="#8A3A2A" strokeWidth="1.4" fill="none" strokeLinecap="round" />
      : mood === 'sleepy' ? <ellipse cx="6.8" cy="-94.6" rx="1.6" ry="2.1" fill="#8A3A2A" />
        : <path d="M4.5 -95 h4.4" stroke="#8A3A2A" strokeWidth="1.4" strokeLinecap="round" />

  const leg = (cls: string, dx: number) => pose === 'sit'
    ? <g><path d={`M${dx - 2} -26 L${dx + 20} -26 L${dx + 21} -3`} fill="none" stroke="#2F3542" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" /><ellipse cx={dx + 24} cy={-1.5} rx="5" ry="2.6" fill="#1E222B" /></g>
    : <g className={`leg ${cls}`}><line x1={dx} y1={-48} x2={dx} y2={-3} stroke="#2F3542" strokeWidth="6" strokeLinecap="round" /><ellipse cx={dx + 3} cy={-1.5} rx="5" ry="2.6" fill="#1E222B" /></g>

  return (
    <motion.g key={run} initial={{ x: from ?? x, opacity: 1 }} animate={{ x, opacity: gone ? 0 : 1, y: gone ? 18 : 0 }}
      transition={{ x: { duration: dur, ease: 'linear' }, opacity: { duration: 0.8 }, y: { duration: 0.8 } }}>
      <g transform={`translate(0 ${GROUND}) scale(${flip ? -K : K} ${K})`} className={walking ? 'walk' : ''} style={{ ['--step' as any]: `${step}s` }}>
        <ellipse cx="2" cy="0" rx="16" ry="3" fill="#000" opacity=".12" />
        <g className="bob">
          {leg('leg-b', 3)}
          {leg('leg-a', -3)}
          <g transform={pose === 'sit' ? 'translate(0 22)' : undefined}>
          {/* back arm */}
          <g className="arm arm-b"><line x1="-2" y1="-84" x2="-4" y2="-58" stroke={sleeve} strokeWidth="6" strokeLinecap="round" opacity={0.78} /><circle cx="-4" cy="-56" r="3" fill={skin} /></g>
          {/* coat */}
          <path d="M-11 -88 Q-14 -62 -15 -42 L15 -42 Q14 -62 11 -88 Z" fill={coat} />
          <path d="M-13.5 -60 H13.5" stroke="#000" strokeOpacity=".18" strokeWidth="2" />
          <path d="M1 -86 V-44" stroke="#000" strokeOpacity=".12" strokeWidth="1.2" />
          {/* scarf */}
          <path d="M-9 -89 Q1 -83 10 -89 L10 -84 Q1 -78 -9 -84 Z" fill={scarf} />
          <path d="M5 -84 L9 -69 L4.5 -70 Z" fill={scarf} />
          {/* front arm, bent when it holds a cup */}
          {cup ? (
            <g>
              <path d="M3 -84 L11 -70 L17 -75" fill="none" stroke={sleeve} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="17.5" cy="-76" r="3" fill={skin} />
              <g transform="translate(14 -89)">
                <path d="M0 3 h9 l-1.3 11 h-6.4 z" fill="#FFFDF8" stroke="#D8CFC2" strokeWidth=".6" />
                <rect x="-0.6" y="1" width="10.2" height="2.6" rx="1" fill="#5A3A2A" />
                <rect x="0.6" y="7" width="7.8" height="3" fill="#C8342F" />
                <g className="fsteam" fill="none" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" opacity=".9">
                  <path d="M3 -1 q-2 -3 0 -6 t0 -5" /><path d="M6.5 -1 q2 -3 0 -6 t0 -5" style={{ animationDelay: '.6s' }} />
                </g>
              </g>
            </g>
          ) : (
            <g className="arm arm-a"><line x1="3" y1="-84" x2="5" y2="-58" stroke={sleeve} strokeWidth="6" strokeLinecap="round" /><circle cx="5" cy="-56" r="3" fill={skin} /></g>
          )}
          {/* head */}
          <rect x="-2.5" y="-92" width="6" height="6" fill={skin} />
          <circle cx="3" cy="-100" r="11" fill={skin} />
          <path d="M-8.5 -98 Q-10 -112 2 -112.5 Q13 -112 14 -103 Q8 -108 1 -106 Q-3 -101 -3 -93 Q-7 -92 -8.5 -98 Z" fill={hair} />
          {mood === 'happy' && <circle cx="10.5" cy="-97" r="2.2" fill="#F08A80" opacity=".55" />}
          {eyes}
          {mouth}
          {beret && <g><ellipse cx="1" cy="-111" rx="12" ry="4.2" fill="#1F2A44" /><rect x="0" y="-117.5" width="2.4" height="3.5" rx="1" fill="#1F2A44" /></g>}
          </g>
        </g>
        {/* effects above the head */}
        {fx === 'rain' && (
          <g transform="translate(2 -140)">
            <g fill="#9AA3B1"><circle cx="-10" cy="0" r="8" /><circle cx="0" cy="-5" r="10" /><circle cx="11" cy="0" r="8" /><rect x="-18" y="0" width="36" height="8" rx="4" /></g>
            {[-9, 0, 9].map((dx, i) => <line key={dx} className="drop" x1={dx} y1="12" x2={dx - 1.5} y2="18" stroke="#7FA6D6" strokeWidth="2" strokeLinecap="round" style={{ animationDelay: `${i * 0.3}s` }} />)}
          </g>
        )}
        {fx === 'zzz' && (
          <g fill="#5B6677" style={{ fontFamily: SERIF, fontWeight: 700 }}>
            {[0, 1, 2].map((i) => <text key={i} className="zz" x={14 + i * 7} y={-118 - i * 10} fontSize={10 + i * 3} style={{ animationDelay: `${i * 0.5}s`}}>z</text>)}
          </g>
        )}
        {fx === 'sparkle' && (
          <g fill="#FFC94D">
            {[[-17, -116, 1], [20, -122, 0.8], [8, -138, 1.1]].map(([sx, sy, s], i) => (
              <g key={i} transform={`translate(${sx} ${sy}) scale(${s})`}><path className="spark" d="M0 -6 L1.6 -1.6 L6 0 L1.6 1.6 L0 6 L-1.6 1.6 L-6 0 L-1.6 -1.6 Z" style={{ animationDelay: `${i * 0.35}s` }} /></g>
            ))}
          </g>
        )}
        {fx === 'talk' && <Bubble flip={flip} />}
      </g>
      {coin && (
        <motion.text key={coin + run} x="2" y={GROUND - 128 * K} textAnchor="middle" fontSize="16" fontWeight="700" fill="#C8342F" style={{ fontFamily: SERIF }}
          initial={{ opacity: 0, y: 0 }} animate={{ opacity: [0, 1, 1, 0], y: -34 }} transition={{ duration: 2.4 }}>{coin}</motion.text>
      )}
    </motion.g>
  )
}

function Bubble({ flip }: { flip?: boolean }) {
  return (
    <g transform="translate(10 -150)">
      <path d="M0 0 h46 a8 8 0 0 1 8 8 v12 a8 8 0 0 1 -8 8 h-30 l-8 8 v-8 h-8 a8 8 0 0 1 -8 -8 v-12 a8 8 0 0 1 8 -8 z" fill="#FFFDF8" stroke="#D8CFC2" />
      <g fill="#5B6677" style={flip ? { transform: 'scaleX(-1)', transformOrigin: '23px 14px' } : undefined}>
        {[12, 23, 34].map((cx, i) => <circle key={cx} className="talkdot" cx={cx} cy="14" r="2.6" style={{ animationDelay: `${i * 0.18}s` }} />)}
      </g>
    </g>
  )
}

/* ---------- scenery ---------- */

const BUILDINGS = [{ x: 0, w: 235, f: 5 }, { x: 235, w: 250, f: 5 }, { x: 485, w: 225, f: 5 }, { x: 710, w: 250, f: 5 }]
const SHOP_TOP = 250
const SH = 90 // shop-front height

function Building({ x, w, f }: { x: number; w: number; f: number }) {
  const top = SHOP_TOP - f * 40
  const cols = Math.max(2, Math.floor((w - 24) / 46))
  const gap = (w - cols * 18) / (cols + 1)
  return (
    <g>
      <path d={`M${x + 6} ${top} L${x + 20} ${top - 34} H${x + w - 20} L${x + w - 6} ${top} Z`} fill="#56627A" />
      {Array.from({ length: cols }).map((_, c) => <rect key={c} x={x + gap + c * (18 + gap) + 1} y={top - 26} width="16" height="18" rx="7" fill="#7F95AE" stroke="#E8DCC6" strokeWidth="2" />)}
      <rect x={x + w - 42} y={top - 48} width="14" height="20" fill="#B4785A" />
      <rect x={x} y={top} width={w} height={SHOP_TOP - top + 2} fill="#EADBC2" />
      <rect x={x} y={top} width={w} height="5" fill="#DCCAAE" />
      {Array.from({ length: f }).map((_, r) => {
        const y = SHOP_TOP - (r + 1) * 40 + 8
        return (
          <g key={r}>
            {Array.from({ length: cols }).map((_, c) => <rect key={c} x={x + gap + c * (18 + gap)} y={y} width="18" height="25" fill={r === 2 && c === 1 ? '#F7D58A' : '#8FA3B8'} stroke="#F7F0E2" strokeWidth="2" />)}
            {(r === 1 || r === 4) && <rect x={x + 6} y={y + 25} width={w - 12} height="3" fill="#2F3440" />}
          </g>
        )
      })}
      <line x1={x + w} y1={top} x2={x + w} y2={SHOP_TOP + SH} stroke="#CDBB9C" strokeWidth="2" />
    </g>
  )
}

function Awning({ x, w, label }: { x: number; w: number; label: string }) {
  const n = Math.round(w / 20)
  const sw = w / n
  return (
    <g>
      <rect x={x} y={SHOP_TOP} width={w} height={SH} fill="#3B4A42" />
      <rect x={x + 10} y={SHOP_TOP + 22} width={w - 20} height={SH - 22} fill="#F2D9A8" opacity=".9" />
      {Array.from({ length: Math.floor((w - 20) / 34) }).map((_, i) => <line key={i} x1={x + 10 + (i + 1) * 34} y1={SHOP_TOP + 22} x2={x + 10 + (i + 1) * 34} y2={SHOP_TOP + SH} stroke="#3B4A42" strokeWidth="2.5" />)}
      <path d={`M${x + w * 0.5 - 15} ${SHOP_TOP + SH} v-62 h30 v62`} fill="#2B3530" />
      <g>
        {Array.from({ length: n }).map((_, i) => <path key={i} d={`M${x + i * sw} ${SHOP_TOP - 6} h${sw} v18 a${sw / 2} ${sw / 2.4} 0 0 1 -${sw} 0 z`} fill={i % 2 ? '#FFF6EA' : '#C8342F'} />)}
      </g>
      <rect x={x + w / 2 - 34} y={SHOP_TOP - 26} width="68" height="18" rx="3" fill="#1F2A44" />
      <text x={x + w / 2} y={SHOP_TOP - 13} textAnchor="middle" fontSize="11" fill="#F7D58A" letterSpacing="2" style={{ fontFamily: SERIF, fontWeight: 700 }}>{label}</text>
    </g>
  )
}

function Bistro({ x, cups = false }: { x: number; cups?: boolean }) {
  return (
    <g>
      <ellipse cx={x} cy={GROUND - 40} rx="20" ry="4" fill="#B8BDC6" />
      <line x1={x} y1={GROUND - 40} x2={x} y2={GROUND - 2} stroke="#5B6677" strokeWidth="2.5" />
      <path d={`M${x - 9} ${GROUND} h18`} stroke="#5B6677" strokeWidth="2.5" strokeLinecap="round" />
      {cups && (
        <g>
          <path d={`M${x - 11} ${GROUND - 50} h8 l-1 9 h-6 z`} fill="#FFFDF8" stroke="#D8CFC2" strokeWidth=".6" />
          <path d={`M${x + 3} ${GROUND - 50} h8 l-1 9 h-6 z`} fill="#FFFDF8" stroke="#D8CFC2" strokeWidth=".6" />
          <g className="fsteam" fill="none" stroke="#fff" strokeWidth="1.3" strokeLinecap="round"><path d={`M${x - 7} ${GROUND - 53} q-2 -3 0 -6 t0 -5`} /><path d={`M${x + 7} ${GROUND - 53} q2 -3 0 -6 t0 -5`} style={{ animationDelay: '.7s' }} /></g>
        </g>
      )}
    </g>
  )
}

function Chair({ x, flip = false }: { x: number; flip?: boolean }) {
  return (
    <g transform={`translate(${x} ${GROUND}) scale(${flip ? -1 : 1} 1)`} stroke="#6B4A33" strokeWidth="2.6" fill="none" strokeLinecap="round">
      <path d="M-10 -36 h26 M-10 -36 v-40 M-10 -36 l-3 36 M16 -36 l3 36" />
    </g>
  )
}

function Metro({ x, sign }: { x: number; sign: string }) {
  return (
    <g>
      <rect x={x - 54} y={GROUND - 4} width="108" height="10" fill="#2A2F38" />
      <path d={`M${x - 50} ${GROUND} v-26 M${x + 50} ${GROUND} v-26 M${x - 50} ${GROUND - 20} h100`} stroke="#3E6B4E" strokeWidth="3" fill="none" />
      <path d={`M${x - 46} ${GROUND} C${x - 46} ${GROUND - 70} ${x - 62} ${GROUND - 104} ${x - 40} ${GROUND - 132}`} stroke="#3E6B4E" strokeWidth="5" fill="none" strokeLinecap="round" />
      <path d={`M${x + 46} ${GROUND} C${x + 46} ${GROUND - 70} ${x + 62} ${GROUND - 104} ${x + 40} ${GROUND - 132}`} stroke="#3E6B4E" strokeWidth="5" fill="none" strokeLinecap="round" />
      <ellipse cx={x - 40} cy={GROUND - 138} rx="6" ry="9" fill="#F28C28" />
      <ellipse cx={x + 40} cy={GROUND - 138} rx="6" ry="9" fill="#F28C28" />
      <rect x={x - 56} y={GROUND - 120} width="112" height="18" rx="2" fill="#F4E7C4" stroke="#3E6B4E" strokeWidth="2" />
      <text x={x} y={GROUND - 107.5} textAnchor="middle" fontSize="9.5" fill="#3E6B4E" letterSpacing=".6" style={{ fontFamily: SERIF, fontWeight: 700 }}>METROPOLITAIN</text>
      <rect x={x - 44} y={GROUND - 92} width="88" height="16" rx="3" fill="#1F2A44" />
      <text x={x} y={GROUND - 80.5} textAnchor="middle" fontSize="9" fill="#F7D58A" style={{ fontFamily: 'Hanken Grotesk, sans-serif', fontWeight: 600 }}>{sign}</text>
    </g>
  )
}

function Counter({ x }: { x: number }) {
  return (
    <g>
      <rect x={x} y={SHOP_TOP} width="200" height={SH} fill="#F7F7F5" />
      <rect x={x + 14} y={SHOP_TOP + 18} width="110" height={SH - 18} fill="#BFE3E8" />
      <rect x={x + 136} y={SHOP_TOP + 30} width="50" height="30" rx="3" fill="#2B3446" />
      <path d={`M${x + 140} ${SHOP_TOP + 60} h42 v5 h-42 z`} fill="#D9D6CF" />
      <path d={`M${x + 150} ${SHOP_TOP + 46} h8 l-1 10 h-6 z M${x + 164} ${SHOP_TOP + 46} h8 l-1 10 h-6 z`} fill="#fff" />
      <rect x={x + 30} y={SHOP_TOP - 28} width="140" height="22" rx="11" fill="#1F2A44" />
      <text x={x + 100} y={SHOP_TOP - 12.5} textAnchor="middle" fontSize="12" fill="#FF8FBF" letterSpacing="1.5" style={{ fontFamily: 'Hanken Grotesk, sans-serif', fontWeight: 700 }}>COFFEE · €1.50</text>
      <text x={x + 69} y={SHOP_TOP + 50} textAnchor="middle" fontSize="9" fill="#2B3446" style={{ fontFamily: 'Hanken Grotesk, sans-serif', fontWeight: 600 }}>ready in 1 min</text>
    </g>
  )
}

function Lamp({ x }: { x: number }) {
  return (
    <g>
      <line x1={x} y1={GROUND} x2={x} y2={GROUND - 120} stroke="#2F3440" strokeWidth="4" />
      <path d={`M${x - 9} ${GROUND - 120} h18 l-4 -16 h-10 z`} fill="#2F3440" />
      <rect x={x - 5} y={GROUND - 133} width="10" height="11" fill="#F7D58A" />
    </g>
  )
}


/* ---------- the player ---------- */

export function CoffeeFilm({ onFinish, onEnter, onClose }: { onFinish: () => void; onEnter: () => void; onClose: () => void }) {
  const [ep, setEp] = useState(0)
  const [track, setTrack] = useState<{ branch: string; i: number }>({ branch: 'main', i: 0 })
  const [ended, setEnded] = useState(false)
  const [moving, setMoving] = useState(false)
  const [seen, setSeen] = useState<Record<string, true>>({})
  const [run, setRun] = useState(0)
  const E = EPISODES[ep]
  const beats = E.beats[track.branch]
  const beat = beats[track.i]

  const before = useMemo(() => {
    const list: Beat[] = [E.start]
    if (track.branch !== 'main') list.push(...E.beats.main)
    list.push(...beats.slice(0, track.i))
    return merge(list)
  }, [E, beats, track])
  const st = useMemo(() => merge([before as Beat, beat]), [before, beat])

  // timeline: each beat moves, holds, then hands over to the next one (choices wait for a click)
  const timer = useRef<number[]>([])
  useEffect(() => {
    timer.current.forEach(clearTimeout)
    timer.current = []
    if (ended) return
    const d = beat.dur ?? 0
    setMoving(!!beat.walk && d > 0)
    if (beat.walk && d > 0) timer.current.push(window.setTimeout(() => setMoving(false), d * 1000))
    if (beat.choice) return
    timer.current.push(window.setTimeout(() => {
      if (track.i + 1 < beats.length) setTrack({ branch: track.branch, i: track.i + 1 })
      else { setEnded(true); setSeen((s) => ({ ...s, [`${E.id}:${track.branch}`]: true })) }
    }, (d + (beat.hold ?? 1.4)) * 1000))
    return () => timer.current.forEach(clearTimeout)
  }, [beat, beats, track, ended, E.id])

  const play = (n: number, branch = 'main') => { setEp(n); setTrack({ branch, i: 0 }); setEnded(false); setRun((r) => r + 1) }
  const pick = (go: string) => setTrack({ branch: go, i: 0 })
  const choiceBranches = E.beats.main.find((b) => b.choice)?.choice ?? []
  const other = ended && track.branch !== 'main' ? choiceBranches.find((c) => c.go !== track.branch && !seen[`${E.id}:${c.go}`]) : undefined
  const lastEp = ep === EPISODES.length - 1

  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); onClose() } }
    window.addEventListener('keydown', k, true)
    return () => window.removeEventListener('keydown', k, true)
  }, [onClose])

  // on phones the street is shown larger and the camera follows Léa
  const frame = useRef<HTMLDivElement>(null)
  const [fw, setFw] = useState(1000)
  useEffect(() => {
    const el = frame.current
    if (!el) return
    const ro = new ResizeObserver(([e]) => setFw(e.contentRect.width))
    ro.observe(el)
    return () => ro.disconnect()
  }, [])
  const narrow = fw < 760
  const fh = narrow ? Math.min(typeof window !== 'undefined' ? window.innerHeight * 0.48 : 360, 380) : (fw * 440) / 960
  const svgW = narrow ? (fh * 960) / 440 : fw
  const camX = narrow ? Math.min(0, Math.max(fw - svgW, fw / 2 - (st.x + 20) * (svgW / 960))) : 0

  const caption = ended ? E.outro : beat.caption
  const runKey = `${ep}-${run}`
  const queueBase = [224, 266, 308]

  return (
    <div className="film absolute inset-0 flex flex-col overflow-y-auto">
      <div className="mx-auto flex w-full max-w-[1120px] items-center justify-between gap-3 px-4 pt-4 md:px-8 md:pt-6">
        <div className="flex gap-1.5 overflow-x-auto" role="tablist" aria-label="Stories">
          {EPISODES.map((e, n) => (
            <button key={e.id} role="tab" aria-selected={n === ep} onClick={() => play(n)}
              className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-medium transition md:text-sm ${n === ep ? 'bg-[#FBD16B] text-[#3A2400]' : 'border border-white/25 text-[#E8D5CF] hover:bg-white/10'}`}>{e.tab}</button>
          ))}
        </div>
        <button onClick={onClose} className="shrink-0 rounded-full border border-white/25 px-4 py-1.5 text-sm text-[#E8D5CF] hover:bg-white/10">Close</button>
      </div>

      <div className="mx-auto flex w-full max-w-[1120px] flex-1 flex-col justify-center px-4 py-5 md:px-8">
        <div ref={frame} className="relative overflow-hidden rounded-[22px] shadow-2xl ring-1 ring-white/10" style={narrow ? { height: fh } : undefined}>
          <motion.div style={{ width: svgW }} initial={false} animate={{ x: camX }} transition={{ duration: moving ? beat.dur ?? 0.8 : 0.9, ease: moving ? 'linear' : 'easeInOut' }}>
          <svg viewBox="0 0 960 440" className="block h-auto w-full" role="img" aria-label={caption}>
            <defs>
              <linearGradient id="film-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#F9C99A" /><stop offset="1" stopColor="#FCEBD3" /></linearGradient>
            </defs>
            <rect width="960" height="440" fill="url(#film-sky)" />
            <motion.circle cy="70" r="26" fill="#FFD36E" initial={false} animate={{ cx: st.sunX }} transition={{ duration: 2.4, ease: 'easeInOut' }} />
            <path d="M861 6 L869 44 L853 44 Z M856 26 h10" stroke="#8E7E86" strokeWidth="2" fill="#8E7E86" opacity=".55" />
            {BUILDINGS.map((b) => <Building key={b.x} {...b} />)}
            {/* default shop fronts */}
            {BUILDINGS.map((b) => <g key={b.x}><rect x={b.x} y={SHOP_TOP} width={b.w} height={SH} fill="#D9C9AE" /><rect x={b.x + 16} y={SHOP_TOP + 16} width={b.w * 0.35} height={SH - 16} fill="#4B5466" /><rect x={b.x + b.w * 0.6} y={SHOP_TOP + 16} width={b.w * 0.3} height={SH - 16} fill="#4B5466" /></g>)}

            {E.id === 'metro' && (
              <g>
                <path d={`M48 ${SHOP_TOP + SH} v-64 a18 18 0 0 1 36 0 v64 z`} fill="#3E6B4E" />
                <Awning x={260} w={210} label="CAFÉ" />
                <Bistro x={492} />
                <Lamp x={620} />
                <Metro x={818} sign={st.sign} />
              </g>
            )}
            {E.id === 'terrace' && (
              <g>
                <Awning x={300} w={340} label="CAFÉ DE LA PLACE" />
                <Lamp x={180} />
                <Chair x={420} /><Chair x={534} flip /><Bistro x={477} cups={st.tableCups} />
                <Chair x={600} /><Chair x={680} flip /><Bistro x={640} />
              </g>
            )}
            {E.id === 'queue' && (
              <g>
                <Awning x={110} w={220} label="CAFÉ" />
                <g transform={`translate(64 ${GROUND - 46})`}><path d="M0 46 l8 -46 h26 l8 46" fill="none" stroke="#6B4A33" strokeWidth="2.5" /><rect x="6" y="2" width="30" height="26" fill="#2B3530" /><text x="21" y="13" textAnchor="middle" fontSize="6.5" fill="#fff" style={{ fontFamily: SERIF }}>Café crème</text><text x="21" y="23" textAnchor="middle" fontSize="8" fill="#F7D58A" style={{ fontFamily: SERIF, fontWeight: 700 }}>3,50 €</text></g>
                <Counter x={620} />
                <Lamp x={480} />
              </g>
            )}

            {/* sidewalk and street */}
            <rect y={GROUND - 5} width="960" height="34" fill="#D3C8B6" />
            <rect y={GROUND + 26} width="960" height="6" fill="#B9AD99" />
            <rect y={GROUND + 32} width="960" height="70" fill="#3F4552" />
            <path d={`M0 ${GROUND + 58} H960`} stroke="#E8E2D6" strokeWidth="3" strokeDasharray="34 26" />

            <g className="traffic traffic-bus">
              <rect x="0" y={GROUND + 34} width="150" height="44" rx="8" fill="#4E8A6E" />
              <rect x="0" y={GROUND + 34} width="150" height="10" rx="5" fill="#3B6E57" />
              {[10, 42, 74, 106].map((wx) => <rect key={wx} x={wx} y={GROUND + 47} width="26" height="14" rx="2" fill="#CFE6EC" />)}
              <circle cx="30" cy={GROUND + 80} r="8" fill="#22262E" /><circle cx="120" cy={GROUND + 80} r="8" fill="#22262E" />
            </g>
            <g className="traffic traffic-scooter">
              <circle cx="6" cy={GROUND + 78} r="6" fill="#22262E" /><circle cx="40" cy={GROUND + 78} r="6" fill="#22262E" />
              <path d={`M6 ${GROUND + 72} h30 l6 -14 M30 ${GROUND + 72} l-4 -16 h-12`} stroke="#E0A526" strokeWidth="5" fill="none" strokeLinecap="round" />
              <circle cx="20" cy={GROUND + 44} r="7" fill="#C8342F" />
            </g>

            {/* grey morning without coffee */}
            <motion.rect width="960" height={GROUND + 30} fill="#5E6878" initial={false} animate={{ opacity: st.gloom * 0.42 }} transition={{ duration: 1.6 }} />

            {E.id === 'terrace' && <Person x={534} dur={0} walking={false} pose="sit" flip mood="happy" coat="#3E6B8A" scarf="#F2C94C" hair="#1E1410" beret={false} fx={st.friendTalk ? 'talk' : null} />}
            {E.id === 'queue' && queueBase.map((bx, i) => {
              const x = bx - 42 * st.queue
              return <Person key={i} run={`${runKey}-q${i}`} x={Math.max(196, x)} dur={0.7} walking={moving && track.branch === 'a'} flip pose="stand" mood="ok" gone={x < 210}
                coat={['#6B7FA6', '#9C5B7A', '#5E8A6A'][i]} scarf={['#E9C46A', '#F4A261', '#E76F51'][i]} hair={['#2B1B14', '#6B3E26', '#1E1410'][i]} beret={false} />
            })}
            <Person run={runKey} x={st.x} from={before.x} dur={beat.dur ?? 0} walking={moving} step={beat.step ?? 0.55} pose={st.pose} mood={st.mood}
              cup={st.cup} fx={st.fx} gone={st.gone} coin={beat.coin} flip={E.id === 'queue' && track.branch === 'a'} />
          </svg>
          </motion.div>

          {/* HUD */}
          <div className="pointer-events-none absolute left-3 top-3 rounded-full bg-[#1F2A44]/85 px-3 py-1 text-sm font-semibold text-[#F7D58A] md:left-5 md:top-5 md:text-base" style={{ fontFamily: SERIF }}>{st.clock}</div>
          <div className="pointer-events-none absolute right-3 top-3 w-28 rounded-xl bg-[#1F2A44]/85 px-3 py-1.5 md:right-5 md:top-5 md:w-40">
            <div className="flex justify-between text-[10px] text-[#E8D5CF] md:text-xs"><span>Energy</span><span>{st.energy}%</span></div>
            <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/15">
              <motion.div className="h-full rounded-full" initial={false} animate={{ width: `${st.energy}%`, backgroundColor: st.energy < 30 ? '#F07167' : '#7BD389' }} transition={{ duration: 1 }} />
            </div>
          </div>
        </div>

        <div className="mt-5 min-h-[132px] md:mt-7">
          <AnimatePresence mode="wait">
            <motion.p key={caption} className="max-w-3xl text-[19px] leading-snug text-[#FFF3E6] md:text-[26px]" style={{ fontFamily: SERIF }}
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.35 }}>
              {caption}
            </motion.p>
          </AnimatePresence>

          {!ended && beat.choice && (
            <motion.div className="mt-4 flex flex-col gap-2.5 sm:flex-row" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
              {beat.choice.map((c) => (
                <button key={c.go} onClick={() => pick(c.go)} className="rounded-full bg-[#FBD16B] px-5 py-2.5 text-sm font-semibold text-[#3A2400] shadow-lg transition hover:-translate-y-0.5 hover:bg-[#FFDD85] md:text-base">{c.label}</button>
              ))}
            </motion.div>
          )}

          {ended && (
            <motion.div className="mt-4 flex flex-wrap gap-2.5" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
              {other && <button onClick={() => { setTrack({ branch: other.go, i: 0 }); setEnded(false); setRun((r) => r + 1) }} className="rounded-full border border-white/30 px-5 py-2.5 text-sm font-medium text-[#FFF3E6] hover:bg-white/10">Watch the other choice</button>}
              <button onClick={() => play(ep)} className="rounded-full border border-white/30 px-5 py-2.5 text-sm font-medium text-[#FFF3E6] hover:bg-white/10">Replay</button>
              {!lastEp && <button onClick={() => play(ep + 1)} className="rounded-full bg-[#FBD16B] px-5 py-2.5 text-sm font-semibold text-[#3A2400] shadow-lg hover:bg-[#FFDD85]">Next story</button>}
              {lastEp && <button onClick={onFinish} className="rounded-full bg-[#FBD16B] px-5 py-2.5 text-sm font-semibold text-[#3A2400] shadow-lg hover:bg-[#FFDD85]">See how we studied it</button>}
              {lastEp && <button onClick={onEnter} className="rounded-full border border-white/30 px-5 py-2.5 text-sm font-medium text-[#FFF3E6] hover:bg-white/10">Open the map</button>}
            </motion.div>
          )}
        </div>
        <p className="mt-3 text-xs text-[#BFA8AE]">Illustrated stories. Times and prices are typical examples, not figures from our data.</p>
      </div>
    </div>
  )
}
