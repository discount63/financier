import maplibregl from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import { useEffect, useMemo, useRef, useState } from 'react'
import { boundsOf, centroidOf, unionBounds } from '../lib/geo'
import { insufficient, ramp, scoreColor } from '../lib/colors'
import { MONUMENTS, DEPARTMENTS, iconSvg } from '../lib/monuments'
import { usePalette } from '../lib/theme'
import type { AppData } from '../lib/types'

interface Props {
  data: AppData
  selected: number | null
  onSelect: (arr: number | null, at?: { x: number; y: number }) => void
  showVenues: boolean
  highlight: number[] // arrondissements du top 3 (vide tant que le classement n'est pas fiable)
  scoreDomain: [number, number]
}

const makeStyle = (bg: string): maplibregl.StyleSpecification => ({
  version: 8,
  sources: {},
  layers: [{ id: 'bg', type: 'background', paint: { 'background-color': bg } }],
})
// the map can be dragged around the whole Île-de-France, no further
const MAX_BOUNDS: [[number, number], [number, number]] = [[1.15, 47.95], [3.85, 49.45]]

export function MapView({ data, selected, onSelect, showVenues, highlight, scoreDomain }: Props) {
  const box = useRef<HTMLDivElement>(null)
  const mapRef = useRef<maplibregl.Map | null>(null)
  const [ready, setReady] = useState(false)
  const [hover, setHover] = useState<{ arr: number; x: number; y: number } | null>(null)
  const hoveredId = useRef<number | null>(null)
  const markers = useRef<Map<number, HTMLElement>>(new Map())
  type Pin = { marker: maplibregl.Marker; el: HTMLElement; lngLat: [number, number]; minor: boolean }
  const pal = usePalette()
  const palRef = useRef(pal)
  palRef.current = pal
  const selectRef = useRef(onSelect)
  selectRef.current = onSelect

  const features = useMemo(
    () => ({
      type: 'FeatureCollection' as const,
      features: data.geojson.features.map((f) => {
        const d = data.districts.find((x) => x.arr === f.id || x.arr === (f.properties as any).arr)!
        return { ...f, properties: { ...f.properties, score: d.score, eligible: d.eligible } }
      }),
    }),
    [data],
  )

  const fitAll = (animate: boolean) => {
    const map = mapRef.current
    if (!map || !box.current) return
    const wide = box.current.clientWidth >= 900
    map.fitBounds(unionBounds(features.features), {
      padding: { top: wide ? 110 : 130, bottom: wide ? 110 : 340, left: wide ? 230 : 30, right: wide ? 520 : 30 },
      duration: animate ? 1500 : 0,
      bearing: 0, pitch: 0,
      essential: true,
    })
  }

  // map creation (once)
  useEffect(() => {
    if (!box.current) return
    const map = new maplibregl.Map({
      container: box.current, style: makeStyle(palRef.current.map.bg), center: [2.3488, 48.8566], zoom: 11, minZoom: 8.4, maxZoom: 16.5, maxBounds: MAX_BOUNDS,
      attributionControl: false, dragRotate: false, pitchWithRotate: false, touchPitch: false,
    })
    mapRef.current = map
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'bottom-right')
    map.touchZoomRotate.disableRotation()

    const pins: Pin[] = []
    const badgeAt: { arr: number; lngLat: [number, number]; big: boolean }[] = []
    map.on('load', () => {
      const [lo, hi] = scoreDomain
      const stops = ramp(lo, hi)
      const mp = palRef.current.map
      // surrounding departments, drawn under the arrondissements
      if (data.context) {
        map.addSource('ctx', { type: 'geojson', data: data.context as any })
        map.addLayer({ id: 'ctx-fill', type: 'fill', source: 'ctx', filter: ['!=', ['get', 'code'], '75'], paint: { 'fill-color': mp.ctxFill } })
        map.addLayer({ id: 'ctx-line', type: 'line', source: 'ctx', filter: ['!=', ['get', 'code'], '75'], paint: { 'line-color': mp.ctxLine, 'line-width': 1.4, 'line-dasharray': [3, 2] } })
        for (const [code, pos] of Object.entries(DEPARTMENTS)) {
          const f = data.context.features.find((x) => (x.properties as any)?.code === code)
          if (!f) continue
          // MapLibre writes its own opacity on marker elements, so the styled element is a child of the marker
          const wrap = document.createElement('div')
          const el = document.createElement('div')
          el.className = 'dep-label'
          el.style.fontSize = 'calc(15px * var(--arr-scale, 1))'
          el.innerHTML = `${(f.properties as any).nom}<b>${code}</b>`
          wrap.appendChild(el)
          new maplibregl.Marker({ element: wrap }).setLngLat([pos.lon, pos.lat]).addTo(map)
        }
        for (const m of MONUMENTS) {
          const wrap = document.createElement('div')
          const el = document.createElement('div')
          el.className = 'lm-pin' + (m.minor ? ' minor' : '')
          el.innerHTML = iconSvg(m.icon) + `<span class="lm-name">${m.name}</span>`
          el.setAttribute('role', m.arr ? 'button' : 'img')
          el.setAttribute('aria-label', m.name)
          if (m.arr) { el.style.cursor = 'pointer'; el.addEventListener('click', (ev) => { ev.stopPropagation(); selectRef.current(m.arr!) }) }
          wrap.appendChild(el)
          const marker = new maplibregl.Marker({ element: wrap }).setLngLat([m.lon, m.lat]).addTo(map)
          pins.push({ marker, el, lngLat: [m.lon, m.lat], minor: !!m.minor })
        }
      }
      // solid Paris shape under the districts: hides the hairline gaps between the low-resolution district outlines,
      // and a thick edge that gives the city a clean contour against the suburbs
      if (data.context) {
        map.addLayer({ id: 'paris-under', type: 'fill', source: 'ctx', filter: ['==', ['get', 'code'], '75'], paint: { 'fill-color': mp.arrLine } })
        map.addLayer({ id: 'paris-edge', type: 'line', source: 'ctx', filter: ['==', ['get', 'code'], '75'], paint: { 'line-color': mp.arrLine, 'line-width': 3 } })
      }
      map.addSource('arr', { type: 'geojson', data: features as any })
      map.addLayer({
        id: 'arr-fill', type: 'fill', source: 'arr',
        paint: {
          'fill-color': [
            'case', ['!', ['to-boolean', ['get', 'eligible']]], insufficient(),
            ['interpolate', ['linear'], ['get', 'score'], ...stops.flatMap((s) => [s.v, s.c])],
          ],
          'fill-opacity': [
            'case', ['boolean', ['feature-state', 'selected'], false], 1, ['boolean', ['feature-state', 'dim'], false], 0.3,
            ['boolean', ['feature-state', 'hover'], false], 0.98, 0.82,
          ],
        },
      })
      map.addLayer({ id: 'arr-line', type: 'line', source: 'arr', paint: { 'line-color': mp.arrLine, 'line-width': 1.2 } })
      map.addLayer({
        id: 'arr-selected-line', type: 'line', source: 'arr',
        paint: {
          'line-color': '#E0A526',
          'line-width': ['case', ['boolean', ['feature-state', 'selected'], false], 3, 0],
          'line-opacity': 1,
        },
      })
      map.addLayer({
        id: 'top-glow', type: 'line', source: 'arr', filter: ['in', ['get', 'arr'], ['literal', []]],
        paint: { 'line-color': '#E0A526', 'line-width': 8, 'line-blur': 8, 'line-opacity': 0.5 },
      })
      map.addLayer({
        id: 'top-line', type: 'line', source: 'arr', filter: ['in', ['get', 'arr'], ['literal', []]],
        paint: { 'line-color': '#E0A526', 'line-width': 2, 'line-opacity': 0.95 },
      })

      map.addSource('venues', {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: data.venues.map((v) => ({
            type: 'Feature', properties: { r: v.r ?? 3, n: v.n, chain: v.c }, geometry: { type: 'Point', coordinates: [v.lon, v.lat] },
          })),
        } as any,
      })
      map.addLayer({
        id: 'venues', type: 'circle', source: 'venues', layout: { visibility: 'none' },
        paint: {
          'circle-radius': ['interpolate', ['linear'], ['zoom'], 10, 2.2, 15, 5],
          'circle-color': ['interpolate', ['linear'], ['get', 'r'], 1, '#D6453D', 3, '#9A93A6', 5, '#2E8B5B'],
          'circle-stroke-color': mp.venueLine, 'circle-stroke-width': 1, 'circle-opacity': 0.9,
        },
      })

      // district numbers: HTML badges (no map font to download), ringed in the district's score colour
      for (const f of features.features) {
        const arr = (f.properties as any).arr as number
        const d = data.districts.find((x) => x.arr === arr)
        const wrap = document.createElement('div')
        wrap.className = 'arr-wrap'
        const el = document.createElement('div')
        el.className = 'arr-label' + (arr >= 10 ? ' big' : '')
        el.style.setProperty('--i', String(arr))
        el.style.setProperty('--ring', d?.eligible && d.score != null ? scoreColor(d.score, lo, hi) : mp.ring)
        el.textContent = String(arr)
        wrap.appendChild(el)
        new maplibregl.Marker({ element: wrap }).setLngLat(centroidOf(f.geometry)).addTo(map)
        markers.current.set(arr, el)
        badgeAt.push({ arr, lngLat: centroidOf(f.geometry), big: arr >= 10 })
      }
      // the badges grow smoothly with the zoom instead of staying a fixed size
      const syncScale = () => {
        const z = map.getZoom(), b = box.current
        if (!b) return
        b.style.setProperty('--arr-scale', String(Math.min(1.7, Math.max(0.78, 0.8 + (z - 10.6) * 0.24))))
        b.classList.toggle('zoom-far', z < 11.7)   // minor landmarks wait until you zoom in
        b.classList.toggle('zoom-wide', z < 9.6)   // very zoomed out: the Paris badges would be too small to read
      }
      // landmarks never sit on a district number: each pin tries its real spot, then a few nearby spots, else it hides
      const layoutPins = () => {
        const b = box.current
        if (!b) return
        const z = map.getZoom()
        const k = Math.min(1.7, Math.max(0.78, 0.8 + (z - 10.6) * 0.24))
        const small = b.clientWidth < 640
        const rp = small ? 13 : 15
        const badges = z < 9.6 ? [] : badgeAt.map((x) => ({ p: map.project(x.lngLat), r: (x.big ? 16 : 13.5) * k }))
        const placed: { x: number; y: number }[] = []
        const D1 = rp * 1.9, D2 = rp * 2.9
        const tries: [number, number][] = [[0, 0], [0, -D1], [D1, 0], [0, D1], [-D1, 0], [D1 * 0.72, -D1 * 0.72], [-D1 * 0.72, -D1 * 0.72], [D1 * 0.72, D1 * 0.72], [-D1 * 0.72, D1 * 0.72], [0, -D2], [D2, 0], [0, D2], [-D2, 0]]
        for (const pin of pins) {
          const skip = (pin.minor && z < 11.7) || (small && z < 11.7)
          if (skip) { pin.el.classList.remove('clash'); continue }
          const p = map.project(pin.lngLat)
          let ok: [number, number] | null = null
          for (const [dx, dy] of tries) {
            const x = p.x + dx, y = p.y + dy
            if (badges.some((bd) => Math.hypot(bd.p.x - x, bd.p.y - y) < bd.r + rp + 3)) continue
            if (placed.some((q) => Math.hypot(q.x - x, q.y - y) < rp * 2 + 3)) continue
            ok = [dx, dy]; placed.push({ x, y }); break
          }
          pin.el.classList.toggle('clash', !ok)
          pin.el.classList.toggle('moved', !!ok && (ok[0] !== 0 || ok[1] !== 0))
          pin.marker.setOffset(ok ?? [0, 0])
        }
      }
      let raf = 0
      const onZoom = () => { syncScale(); if (!raf) raf = requestAnimationFrame(() => { raf = 0; layoutPins() }) }
      map.on('zoom', onZoom)
      map.on('resize', onZoom)
      map.on('idle', layoutPins)
      syncScale()
      layoutPins()

      map.on('mousemove', 'arr-fill', (e) => {
        const f = e.features?.[0]
        if (!f) return
        const id = f.id as number
        map.getCanvas().style.cursor = 'pointer'
        if (hoveredId.current !== id) {
          if (hoveredId.current != null) {
            map.setFeatureState({ source: 'arr', id: hoveredId.current }, { hover: false })
            markers.current.get(hoveredId.current)?.classList.remove('hover')
          }
          map.setFeatureState({ source: 'arr', id }, { hover: true })
          markers.current.get(id)?.classList.add('hover')
          hoveredId.current = id
        }
        setHover({ arr: id, x: e.point.x, y: e.point.y })
      })
      map.on('mouseleave', 'arr-fill', () => {
        map.getCanvas().style.cursor = ''
        if (hoveredId.current != null) {
          map.setFeatureState({ source: 'arr', id: hoveredId.current }, { hover: false })
          markers.current.get(hoveredId.current)?.classList.remove('hover')
        }
        hoveredId.current = null
        setHover(null)
      })
      map.on('click', (e) => {
        const hit = map.queryRenderedFeatures(e.point, { layers: ['arr-fill'] })[0]
        selectRef.current(hit ? (hit.id as number) : null, { x: e.point.x, y: e.point.y })
      })
      setReady(true)
    })

    const onResize = () => map.resize()
    window.addEventListener('resize', onResize)
    return () => { window.removeEventListener('resize', onResize); map.remove(); mapRef.current = null; markers.current.clear() }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // theme change: recolour everything the map draws (the HTML badges follow through CSS variables)
  useEffect(() => {
    const map = mapRef.current
    if (!map || !ready) return
    const m = pal.map
    const [lo, hi] = scoreDomain
    map.setPaintProperty('bg', 'background-color', m.bg)
    map.setPaintProperty('arr-fill', 'fill-color', [
      'case', ['!', ['to-boolean', ['get', 'eligible']]], m.insufficient,
      ['interpolate', ['linear'], ['get', 'score'], ...ramp(lo, hi).flatMap((s) => [s.v, s.c])],
    ])
    map.setPaintProperty('arr-line', 'line-color', m.arrLine)
    map.setPaintProperty('venues', 'circle-stroke-color', m.venueLine)
    if (map.getLayer('ctx-fill')) {
      map.setPaintProperty('ctx-fill', 'fill-color', m.ctxFill); map.setPaintProperty('ctx-line', 'line-color', m.ctxLine)
      map.setPaintProperty('paris-under', 'fill-color', m.arrLine); map.setPaintProperty('paris-edge', 'line-color', m.arrLine)
    }
    for (const [arr, el] of markers.current) {
      const d = data.districts.find((x) => x.arr === arr)
      el.style.setProperty('--ring', d?.eligible && d.score != null ? scoreColor(d.score, lo, hi) : m.ring)
    }
  }, [pal, ready]) // eslint-disable-line react-hooks/exhaustive-deps

  // selection: polygon state + camera
  useEffect(() => {
    const map = mapRef.current
    if (!map || !ready || !box.current) return
    for (const f of features.features) {
      const arr = (f.properties as any).arr as number
      map.setFeatureState({ source: 'arr', id: arr }, { selected: selected === arr, dim: selected != null && selected !== arr })
      markers.current.get(arr)?.classList.toggle('dim', selected != null && selected !== arr)
    }
    box.current.classList.toggle('map-hide-ctx', selected != null)
    if (selected == null) { fitAll(true); return }
    const f = features.features.find((x) => (x.properties as any).arr === selected)
    if (!f) return
    const wide = box.current.clientWidth >= 900
    // cinematic fly-in: tilt and rotate while zooming (the scene overlay opens as an iris on top)
    const cam = map.cameraForBounds(boundsOf(f.geometry), { padding: wide ? 120 : 40, maxZoom: 12.6 })
    if (cam?.center) map.flyTo({ center: cam.center, zoom: cam.zoom, bearing: -16, pitch: 52, duration: 2200, curve: 1.5, essential: true })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected, ready])

  // premier cadrage sans animation
  useEffect(() => { if (ready) fitAll(false) /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [ready])

  useEffect(() => {
    const map = mapRef.current
    if (map && ready) map.setLayoutProperty('venues', 'visibility', showVenues ? 'visible' : 'none')
  }, [showVenues, ready])

  // top 3: gold outline + softly pulsing glow
  useEffect(() => {
    const map = mapRef.current
    if (!map || !ready) return
    const filter = ['in', ['get', 'arr'], ['literal', highlight]] as any
    map.setFilter('top-glow', filter)
    map.setFilter('top-line', filter)
    for (const [arr, el] of markers.current) el.classList.toggle('top', highlight.includes(arr))
    if (!highlight.length) return
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduce) return
    let raf = 0, last = 0
    const tick = (t: number) => {
      if (t - last > 33) {
        last = t
        const k = 0.5 + 0.5 * Math.sin(t / 650)
        map.setPaintProperty('top-glow', 'line-opacity', 0.25 + 0.5 * k)
        map.setPaintProperty('top-glow', 'line-width', 6 + 6 * k)
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [highlight, ready])

  const hovered = hover ? data.districts.find((d) => d.arr === hover.arr) : null
  return (
    <div className="absolute inset-0">
      <div ref={box} className="absolute inset-0" role="application" aria-label="Interactive map of Paris's 20 districts" />
      {hovered && hover && (
        <div
          className="glass pointer-events-none absolute z-20 rounded-lg px-3 py-2 text-sm shadow-panel"
          style={{ left: Math.min(hover.x + 16, (box.current?.clientWidth ?? 800) - 190), top: hover.y + 16 }}
        >
          <div className="font-display text-base font-bold">Paris {hovered.name} district</div>
          <div className="text-xs text-paper-mute">{hovered.label}</div>
          <div className="mt-1 text-xs">
            {hovered.eligible && hovered.score != null ? (
              <>Score <b className="text-crema">{hovered.score.toFixed(0)}</b> / 100 · rank {hovered.rank}</>
            ) : (
              <span className="text-paper-mute">Insufficient data</span>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
