import { AnimatePresence, motion } from 'motion/react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { DistrictScene } from './DistrictScene'
import { Wordmark } from './Logo'
import { Legend } from './Legend'
import { MapView } from './MapView'
import { RankingList } from './RankingList'
import type { AppData } from '../lib/types'
import { int } from '../lib/format'

export function MapSection({ data, selected, setSelected, onSimulate }: {
  data: AppData; selected: number | null; setSelected: (a: number | null) => void; onSimulate: (a: number) => void
}) {
  const [showVenues, setShowVenues] = useState(false)
  const reliable = data.ranking.status === 'reliable'
  const highlight = useMemo(() => (reliable ? data.ranking.top : []), [reliable, data.ranking.top])
  const scoreDomain = useMemo<[number, number]>(() => {
    const s = data.districts.filter((d) => d.score != null).map((d) => d.score as number)
    return [Math.floor(Math.min(...s)), Math.ceil(Math.max(...s))]
  }, [data.districts])
  const current = selected != null ? data.districts.find((d) => d.arr === selected) ?? null : null
  const [showWhy, setShowWhy] = useState(false)
  const [sheetOpen, setSheetOpen] = useState(true) // phone only: the ranking sheet can be pulled down to see the whole map
  const section = useRef<HTMLElement>(null)
  const [scene, setScene] = useState({ origin: { x: 800, y: 400 }, size: { w: 1440, h: 800 } })
  useEffect(() => {
    const r = section.current?.getBoundingClientRect()
    if (r) setScene((s) => ({ ...s, size: { w: r.width, h: r.height } }))
  }, [selected])
  const select = (arr: number | null, at?: { x: number; y: number }) => {
    const r = section.current?.getBoundingClientRect()
    const size = { w: r?.width ?? 1440, h: r?.height ?? 800 }
    setScene({ size, origin: at ?? { x: size.w * 0.78, y: size.h * 0.4 } })
    setSelected(arr)
  }

  return (
    <section ref={section} id="carte" className="relative h-[calc(100svh-56px)] min-h-[660px] overflow-hidden bg-ink-900" aria-label="District map">
      <MapView data={data} selected={selected} onSelect={select} showVenues={showVenues} highlight={highlight} scoreDomain={scoreDomain} />

      <div className="pointer-events-none absolute left-3 top-3 z-10 flex max-w-[330px] flex-col gap-3 md:left-6 md:top-6">
        <div className="glass pointer-events-auto rounded-2xl p-4 md:p-5">
          <div className="hidden md:block"><Wordmark size="lg" /></div>
          <h1 className="mt-0 font-display text-[19px] font-bold leading-[1.15] text-paper md:mt-3 md:text-[28px]">Where to open a €1.50 café in Paris?</h1>
          <p className="mt-2 hidden text-sm leading-relaxed text-paper-dim md:block">
            {int(data.meta.global.reviews)} Google Maps reviews across {int(data.meta.global.venues)} venues, matched with public data
            (INSEE, SIRENE). Click a district to explore it.
          </p>
          {!reliable && (
            <button className="mt-2 rounded-full border border-crema/30 bg-crema/5 px-2.5 py-1 text-xs font-medium text-crema md:hidden" onClick={() => setShowWhy((v) => !v)}>
              Provisional ranking · {showWhy ? 'hide' : 'why?'}
            </button>
          )}
          {!reliable && showWhy && (
            <ul className="mt-2 list-disc space-y-1 pl-4 text-xs leading-relaxed text-paper-dim md:hidden">{data.ranking.reasons.map((r) => <li key={r}>{r}</li>)}</ul>
          )}
          {!reliable && (
            <div className="mt-3 hidden rounded-lg border border-crema/30 bg-crema/5 p-2.5 text-xs leading-relaxed text-paper-dim">
              <b className="text-crema">Provisional ranking.</b>{' '}
              {data.ranking.reasons[0]}
              {data.ranking.reasons.length > 1 && (
                <button className="ml-1 underline underline-offset-2" onClick={() => setShowWhy((v) => !v)}>{showWhy ? 'less' : 'show all'}</button>
              )}
              {showWhy && <ul className="mt-1.5 list-disc space-y-1 pl-4">{data.ranking.reasons.slice(1).map((r) => <li key={r}>{r}</li>)}</ul>}
            </div>
          )}
        </div>
      </div>

      <div className="pointer-events-auto absolute bottom-3 left-3 z-10 hidden md:bottom-6 md:left-6 md:block">
        <Legend domain={scoreDomain} showVenues={showVenues} setShowVenues={setShowVenues} highlighted={reliable} venues={data.venues.length} />
      </div>

      <AnimatePresence>
        {!current && (
          <motion.aside key="ranking" initial={{ opacity: 0, x: 36 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 24 }} transition={{ duration: 0.35, delay: 0.1 }}
            className={`glass absolute z-30 flex flex-col overflow-hidden shadow-panel max-md:inset-x-0 max-md:bottom-0 max-md:rounded-t-2xl max-md:transition-[height] max-md:duration-300 ${sheetOpen ? 'max-md:h-[46%]' : 'max-md:h-[56px]'} md:bottom-6 md:right-6 md:top-6 md:w-[480px] md:rounded-2xl`}>
            <button onClick={() => setSheetOpen((o) => !o)} aria-expanded={sheetOpen} aria-label={sheetOpen ? 'Collapse the ranking' : 'Expand the ranking'} className="flex h-14 shrink-0 flex-col items-center justify-center gap-1.5 md:hidden">
              <span className="h-1 w-10 rounded-full bg-ink-500" />
              <span className="text-xs font-medium text-paper-dim">{sheetOpen ? 'Hide ranking' : 'Show district ranking'}</span>
            </button>
            <RankingList data={data} onSelect={(arr, ev) => select(arr, ev)} scoreDomain={scoreDomain} highlight={highlight} />
          </motion.aside>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {current && <DistrictScene key="scene" d={current} data={data} origin={scene.origin} size={scene.size} onClose={() => setSelected(null)} onSimulate={onSimulate} />}
      </AnimatePresence>
    </section>
  )
}
