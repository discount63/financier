import { insufficient, ramp } from '../lib/colors'
import { usePalette } from '../lib/theme'

export function Legend({ domain, showVenues, setShowVenues, highlighted, venues }: {
  domain: [number, number]; showVenues: boolean; setShowVenues: (v: boolean) => void; highlighted: boolean; venues: number
}) {
  usePalette() // re-render when the theme (and so the colour ramp) changes
  const stops = ramp(domain[0], domain[1])
  return (
    <div className="glass w-[270px] rounded-xl p-4 text-xs">
      <div className="mb-2 font-medium text-paper">Attractiveness score</div>
      <div className="h-2.5 rounded-full" style={{ background: `linear-gradient(90deg, ${stops.map((s) => s.c).join(', ')})` }} />
      <div className="mt-1 flex justify-between text-paper-mute"><span>{domain[0].toFixed(0)} · lower</span><span>higher · {domain[1].toFixed(0)}</span></div>
      <div className="mt-3 flex items-center gap-2 text-paper-dim">
        <span className="inline-block h-3 w-5 rounded-sm" style={{ background: insufficient(), border: '1px solid rgb(var(--ink-500))' }} /> Insufficient data
      </div>
      <div className="mt-1.5 flex items-center gap-2 text-paper-dim">
        <span className="inline-block h-3 w-5 rounded-sm border-2 border-[#E0A526]" style={{ opacity: highlighted ? 1 : 0.35 }} />
        {highlighted ? 'Top 3 (reliable ranking)' : 'Top 3: shown only when the ranking is reliable'}
      </div>
      <label className="mt-3 flex cursor-pointer items-center gap-2 text-paper-dim">
        <input type="checkbox" checked={showVenues} onChange={(e) => setShowVenues(e.target.checked)} className="accent-[#E0A526]" />
        Show analysed venues ({venues})
      </label>
    </div>
  )
}
