import { TIP } from '../lib/chartStyle'
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from 'recharts'
import { Note, Section } from './Section'
import { dec1, int, pct } from '../lib/format'
import { RANK_COLORS, RANK_TEXT } from '../lib/colors'
import { insightsFor } from '../lib/insights'
import { DEFAULT_SIM, simulate } from '../lib/sim'
import type { AppData, District } from '../lib/types'

const ordinal = (n: number) => `${n}${n % 100 >= 11 && n % 100 <= 13 ? 'th' : ({ 1: 'st', 2: 'nd', 3: 'rd' } as Record<number, string>)[n % 10] ?? 'th'}`
const CLUSTER_COLORS = ['#3FA37A', '#E0A526', '#8E6BD1', '#D6453D', '#3E8FC9']

function Card({ d, data, rank, provisional, onSelect, onSimulate }: {
  d: District; data: AppData; rank: number; provisional: boolean; onSelect: (a: number) => void; onSimulate: (a: number) => void
}) {
  const { strengths, weaknesses } = insightsFor(d, data.ranking)
  const m = d.metrics
  const sim = simulate({ ...DEFAULT_SIM })
  const pop = m.population.value
  const cluster = data.clusters.clusters.find((c) => c.id === d.cluster)
  return (
    <article className="card flex flex-col p-6" style={{ borderTop: `4px solid ${RANK_COLORS[rank - 1]}`, background: `linear-gradient(180deg, ${RANK_COLORS[rank - 1]}22, transparent 45%), var(--panel)` }}>
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs text-paper-mute">{d.label}</div>
          <h3 className="font-display text-3xl font-bold">Paris {d.name} district</h3>
        </div>
        <div className="text-right">
          <div className="font-display text-4xl font-bold" style={{ color: RANK_TEXT[rank - 1] }}>{dec1(d.score)}</div>
          <div className="text-xs font-semibold" style={{ color: RANK_TEXT[rank - 1] }}>#{rank}</div>
        </div>
      </div>
      <dl className="mt-5 space-y-4 text-sm">
        <div>
          <dt className="font-medium text-pos">Why it stands out</dt>
          <dd className="mt-1 space-y-1 text-paper-dim">{strengths.length ? strengths.map((s) => <div key={s.key}>{s.label}: <span className="text-paper">{s.detail}</span></div>) : 'No criterion clearly above the median.'}</dd>
        </div>
        <div>
          <dt className="font-medium text-neg">Watch-outs</dt>
          <dd className="mt-1 space-y-1 text-paper-dim">{weaknesses.length ? weaknesses.map((s) => <div key={s.key}>{s.label}: <span className="text-paper">{s.detail}</span></div>) : 'No criterion clearly below the median.'}</dd>
        </div>
        <div>
          <dt className="font-medium">Customer profile</dt>
          <dd className="mt-1 text-paper-dim">
            {m.price_band.value != null ? `Declared spend of about €${int(m.price_band.value)} per person. ` : ''}
            {m.takeaway.value != null ? `${pct(m.takeaway.value)} of declared orders are takeaway. ` : ''}
            {cluster ? `Similarity group ${cluster.id + 1} (${cluster.traits.join('; ')}).` : ''}
          </dd>
        </div>
        <div>
          <dt className="font-medium">Competitive environment</dt>
          <dd className="mt-1 text-paper-dim">{int(m.cafes_sirene.value)} cafés listed (SIRENE), i.e. {dec1(m.cafes_per_10k.value)} per 10,000 residents. Average venue rating: {dec1(m.rating.value)} / 5.</dd>
        </div>
        <div>
          <dt className="font-medium">Financial feasibility</dt>
          <dd className="mt-1 text-paper-dim">
            With the simulator's default assumptions (rent €{int(DEFAULT_SIM.rent)}), break-even is{' '}
            <span className="text-paper">{sim.breakEvenCupsPerDay ? int(Math.ceil(sim.breakEvenCupsPerDay)) : '—'} cups per day</span>
            {pop ? <>, i.e. {dec1(((sim.breakEvenCupsPerDay ?? 0) / pop) * 1000)} cups per day per 1,000 residents</> : null}.
          </dd>
        </div>
      </dl>
      <div className="mt-6 flex gap-2">
        <button onClick={() => onSelect(d.arr)} className="rounded-lg border border-ink-500 px-3 py-2 text-sm hover:bg-ink-600">View on map</button>
        <button onClick={() => onSimulate(d.arr)} className="rounded-lg border border-crema/50 px-3 py-2 text-sm text-crema hover:bg-crema/10">Simulate</button>
      </div>
    </article>
  )
}

export function TopThreeSection({ data, onSelect, onSimulate }: { data: AppData; onSelect: (a: number) => void; onSimulate: (a: number) => void }) {
  const r = data.ranking
  const provisional = r.status !== 'reliable'
  const top = r.top.map((a) => data.districts.find((d) => d.arr === a)!).filter(Boolean)
  const eligible = data.districts.filter((d) => d.eligible && d.top3_stability != null).sort((a, b) => (b.top3_stability ?? 0) - (a.top3_stability ?? 0))
  const stab = eligible.map((d) => ({ name: d.name, v: d.top3_stability ?? 0, top: r.top.includes(d.arr) }))
  const scatter = data.districts.filter((d) => d.pca && d.cluster != null).map((d) => ({ x: d.pca![0], y: d.pca![1], name: d.name, c: d.cluster as number }))

  return (
    <Section id="top3" title={provisional ? 'The top three districts, to be confirmed' : 'The three most promising districts'}
      intro="The ranking comes from a transparent multi-criteria score. It is presented as final only if there is enough data and the top 3 holds up when the weights change.">
      {provisional ? (
        <Note tone="warn">
          <b className="text-crema">Provisional ranking: the top 3 is not highlighted on the map.</b>
          <ul className="mt-2 list-disc space-y-1 pl-5">{r.reasons.map((x) => <li key={x}>{x}</li>)}</ul>
          <p className="mt-2">Below is the current state of the ranking, for information only.</p>
        </Note>
      ) : r.caveats.length > 0 ? <Note>{r.caveats.join(' ')}</Note> : null}

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {top.map((d, i) => <Card key={d.arr} d={d} data={data} rank={i + 1} provisional={provisional} onSelect={onSelect} onSimulate={onSimulate} />)}
      </div>

      <div className="mt-14 grid gap-6 lg:grid-cols-2">
        <div className="card p-5">
          <h3 className="font-display text-lg font-bold">Does the top 3 survive different weightings?</h3>
          <p className="mt-1 text-xs leading-relaxed text-paper-mute">{int(r.draws)} random weight draws around the starting weights. Share of draws in which the district stays in the top 3; acceptance threshold: {pct(r.min_top3_stability)}.</p>
          <div className="mt-3" style={{ height: Math.max(220, stab.length * 24) }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stab} layout="vertical" margin={{ left: 8, right: 16, top: 4, bottom: 4 }}>
                <CartesianGrid horizontal={false} stroke="rgb(var(--ink-600))" />
                <XAxis type="number" domain={[0, 1]} tickFormatter={(v) => `${Math.round(v * 100)}%`} tick={{ fill: 'rgb(var(--paper-mute))', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="name" interval={0} width={38} tick={{ fill: 'rgb(var(--paper-dim))', fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip cursor={{ fill: 'rgb(var(--paper) / 0.06)' }} {...TIP} formatter={(v: number) => [pct(v), 'in the top 3']} labelFormatter={(l) => `Paris ${l}`} />
                <Bar dataKey="v" radius={[0, 4, 4, 0]} barSize={14}>{stab.map((s) => <Cell key={s.name} fill={s.top ? '#E0A526' : '#6C7BC9'} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card p-5">
          <h3 className="font-display text-lg font-bold">Which districts look alike?</h3>
          <p className="mt-1 text-xs leading-relaxed text-paper-mute">
            K-Means clustering into {data.clusters.k} groups (silhouette {data.clusters.silhouette.toLocaleString('en-GB')}), projected on two axes (PCA, {pct(data.clusters.explained_variance.reduce((a, b) => a + b, 0))} of the information). {data.clusters.caveat}
          </p>
          <div className="mt-3 h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
                <CartesianGrid stroke="rgb(var(--ink-600))" />
                <XAxis type="number" dataKey="x" hide /><YAxis type="number" dataKey="y" hide /><ZAxis range={[90, 90]} />
                <Tooltip cursor={{ strokeDasharray: '3 3', stroke: 'rgb(var(--crema))' }} content={({ active, payload }) => active && payload?.length ? (
                  <div className="rounded-lg border border-ink-600 bg-ink-800 px-3 py-2 text-sm text-paper shadow-panel"><b>Paris {(payload[0].payload as any).name}</b><div className="text-xs text-paper-mute">group {(payload[0].payload as any).c + 1}</div></div>
                ) : null} />
                {data.clusters.clusters.map((c) => (
                  <Scatter key={c.id} name={`Group ${c.id + 1}`} data={scatter.filter((s) => s.c === c.id)} fill={CLUSTER_COLORS[c.id % 5]} />
                ))}
              </ScatterChart>
            </ResponsiveContainer>
          </div>
          <ul className="mt-2 space-y-1 text-xs text-paper-dim">
            {data.clusters.clusters.map((c) => (
              <li key={c.id}><span className="mr-2 inline-block h-2.5 w-2.5 rounded-full align-middle" style={{ background: CLUSTER_COLORS[c.id % 5] }} />
                <b className="text-paper">Group {c.id + 1}</b>: {c.members.map((a) => ordinal(a)).join(', ')} · {c.traits.join('; ')}</li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  )
}
