import { animate, motion, useMotionValue, useSpring, useTransform } from 'motion/react'
import { useId, useRef } from 'react'

/** The drawing: a steaming espresso cup and a financier (the little golden almond cake) on one saucer. */
function CupAndCake({ id }: { id: string }) {
  return (
    <svg viewBox="0 0 64 64" className="absolute inset-0 h-full w-full" aria-hidden>
      <defs>
        <linearGradient id={`${id}-bg`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" style={{ stopColor: 'rgb(var(--deep-700))' }} />
          <stop offset="1" style={{ stopColor: 'rgb(var(--deep-900))' }} />
        </linearGradient>
        <linearGradient id={`${id}-cake`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#F6C65E" />
          <stop offset="1" stopColor="#C27A1C" />
        </linearGradient>
        <linearGradient id={`${id}-cup`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#FFF7EC" />
          <stop offset="1" stopColor="#EBD9C4" />
        </linearGradient>
        <clipPath id={`${id}-clip`}><circle cx="32" cy="32" r="31" /></clipPath>
      </defs>
      <circle cx="32" cy="32" r="31" fill={`url(#${id}-bg)`} />
      <circle cx="32" cy="32" r="27.6" fill="none" stroke="#E7B54A" strokeOpacity=".55" strokeWidth="1" />

      <g transform="translate(32 32.5) scale(1.13) translate(-33.2 -34.2)">
      {/* steam */}
      <g className="steam" fill="none" stroke="#FFF1DD" strokeWidth="1.9" strokeLinecap="round">
        <path d="M40 27 q-3.2 -3.6 0 -7 t0 -7" style={{ animationDelay: '0s' }} />
        <path d="M46 27 q3.2 -3.6 0 -7 t0 -7" style={{ animationDelay: '.9s' }} />
        <path d="M51.5 27 q-2.6 -3 0 -5.8 t0 -5.8" style={{ animationDelay: '1.7s' }} />
      </g>

      {/* saucer */}
      <ellipse cx="38.5" cy="51.8" rx="22.5" ry="3.4" fill="#E9D3AE" />
      <ellipse cx="38.5" cy="50.8" rx="22.5" ry="3.4" fill="#F7E8CC" />

      {/* cup */}
      <path d="M52.6 33 h2.4 a4.3 4.3 0 0 1 0 8.6 h-3" fill="none" stroke="#FFF1DD" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M33 29.5 h22 v8.5 a11 11 0 0 1 -11 11.5 a11 11 0 0 1 -11 -11.5 z" fill={`url(#${id}-cup)`} />
      <ellipse cx="44" cy="29.5" rx="11" ry="2.7" fill="#FFF7EC" />
      <ellipse cx="44" cy="29.8" rx="9.2" ry="1.9" fill="#7A4527" />
      <path d="M36 41 q8 6 16 0" fill="none" stroke="#E7B54A" strokeWidth="1.1" strokeLinecap="round" opacity=".9" />

      {/* financier */}
      <g className="cake">
        <path d="M8.5 43.5 L12.2 36 H33.2 L29.6 43.5 Z" fill="#F9D98A" />
        <rect x="8.5" y="43.5" width="21.1" height="7.4" rx="1.6" fill={`url(#${id}-cake)`} />
        <path d="M8.5 45.6 H29.6" stroke="#FFF0C8" strokeOpacity=".55" strokeWidth=".8" />
        <g fill="#FFF3D4" stroke="#C98A2B" strokeWidth=".35">
          <ellipse cx="16" cy="39.8" rx="2.5" ry="1.2" transform="rotate(-18 16 39.8)" />
          <ellipse cx="22.4" cy="38.6" rx="2.5" ry="1.2" transform="rotate(8 22.4 38.6)" />
          <ellipse cx="27.4" cy="40.2" rx="2.3" ry="1.1" transform="rotate(-10 27.4 40.2)" />
        </g>
      </g>
      </g>
    </svg>
  )
}

/**
 * Financier mark. Hover: the badge tilts in 3D, the cake floats forward, the steam speeds up and a light follows the cursor.
 * Click: it flips like a coin to show the price (€1.50).
 */
export function FinancierMark({ size = 40, interactive = true, onActivate }: { size?: number; interactive?: boolean; onActivate?: () => void }) {
  const id = useId().replace(/:/g, '')
  const ref = useRef<HTMLSpanElement>(null)
  const mx = useMotionValue(0), my = useMotionValue(0)
  const rx = useSpring(useTransform(my, [-1, 1], [16, -16]), { stiffness: 220, damping: 18 })
  const ry = useSpring(useTransform(mx, [-1, 1], [-20, 20]), { stiffness: 220, damping: 18 })
  const flip = useMotionValue(0)
  const glare = useTransform([mx, my] as any, ([x, y]: number[]) => `radial-gradient(circle at ${50 + x * 42}% ${50 + y * 42}%, rgba(255,255,255,.55), rgba(255,255,255,0) 55%)`)

  const move = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect()
    mx.set(((e.clientX - r.left) / r.width) * 2 - 1)
    my.set(((e.clientY - r.top) / r.height) * 2 - 1)
  }
  const reset = () => { mx.set(0); my.set(0) }
  const toggle = () => {
    animate(flip, flip.get() + 180, { duration: 0.75, ease: [0.3, 0.9, 0.3, 1] })
    if (onActivate) window.setTimeout(onActivate, 650)
  }

  return (
    <span ref={ref} className="logo-mark inline-block shrink-0 select-none" style={{ width: size, height: size, perspective: 520 }}
      onPointerMove={interactive ? move : undefined} onPointerLeave={interactive ? reset : undefined} onClick={interactive ? toggle : undefined}
      role={interactive ? 'button' : 'img'} aria-label="Financier logo: a coffee cup and a financier cake" tabIndex={interactive ? 0 : -1}
      onKeyDown={interactive ? (e) => { if (e.key === 'Enter' || e.key === ' ') toggle() } : undefined}>
      <motion.span className="relative block h-full w-full cursor-pointer" style={{ rotateX: rx, rotateY: ry, transformStyle: 'preserve-3d' }}>
        <motion.span className="absolute inset-0 block" style={{ rotateY: flip, transformStyle: 'preserve-3d' }}>
          <span className="absolute inset-0 block overflow-hidden rounded-full" style={{ backfaceVisibility: 'hidden', boxShadow: `0 ${size * 0.1}px ${size * 0.28}px -${size * 0.08}px rgba(60,20,40,.6)` }}>
            <CupAndCake id={id} />
            <motion.span className="pointer-events-none absolute inset-0" style={{ background: glare, mixBlendMode: 'soft-light' }} />
          </span>
          <span className="absolute inset-0 grid place-items-center overflow-hidden rounded-full"
            style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)', background: 'linear-gradient(135deg, rgb(var(--deep-700)), rgb(var(--deep-900)))', boxShadow: `inset 0 0 0 ${Math.max(1, size * 0.03)}px rgba(231,181,74,.6)` }}>
            <span style={{ fontFamily: 'Fraunces, Georgia, serif', fontWeight: 700, fontSize: size * 0.34, color: '#F6C65E', letterSpacing: '-0.02em' }}>€1.50</span>
          </span>
        </motion.span>
      </motion.span>
    </span>
  )
}

export function Wordmark({ size = 'md', light = false }: { size?: 'md' | 'lg'; light?: boolean }) {
  const big = size === 'lg'
  return (
    <span className="inline-flex items-center gap-3">
      <FinancierMark size={big ? 60 : 38} />
      <span className="flex flex-col leading-none">
        <span style={{ fontFamily: 'Fraunces, Georgia, serif', fontWeight: 600, fontSize: big ? 36 : 23, letterSpacing: '-0.015em', color: light ? 'rgb(var(--deep-text))' : 'rgb(var(--paper))' }}>Financier</span>
        {big && <span className="mt-1.5 text-[13px] italic" style={{ fontFamily: 'Fraunces, Georgia, serif', color: light ? 'rgb(var(--deep-mute))' : 'rgb(var(--paper-mute))' }}>coffee &amp; pastry, €1.50, Paris</span>}
      </span>
    </span>
  )
}
