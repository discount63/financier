export const POS = '#2E9E6E'
export const NEG = '#D6453D'
export const NEU = '#A9A3B5'
export const CREMA = '#D9456B'

/** One colour per aspect, so each customer theme is recognisable at a glance. */
export const ASPECT_COLORS: Record<string, string> = {
  price: '#D9A21B', taste: '#E2793A', coffee_quality: '#8A5A3C', service: '#3E8FC9', waiting_time: '#8E6BD1',
  atmosphere: '#D9488A', comfort: '#3FA37A', variety: '#2BA5A5', takeaway: '#5C6BC9',
}
export const RANK_COLORS = ['#E0A526', '#8FA3B5', '#C9774A']
export const RANK_TEXT = ['#8A5A00', '#4A6076', '#9A4E25']
/** Darkened version of a bright accent, safe to use as text on the cream background. */
export const inkOf = (c: string) => `color-mix(in srgb, ${c} 62%, rgb(var(--mix)))`

/** Berry ramp: vanilla, apricot, raspberry, plum. One warm hue family: light = low score, dark = high score. */
let STOPS: string[] = ['#FBE6CC', '#F4A97F', '#D9456B', '#6E1F5A']
let INSUF = '#D8D4DA'
/** Called by the theme system: every theme brings its own ramp. */
export function setMapColors(stops: string[], insufficient: string) { STOPS = stops; INSUF = insufficient }
export const insufficient = () => INSUF
export function ramp(lo: number, hi: number) {
  return STOPS.map((c, i) => ({ v: lo + ((hi - lo) * i) / (STOPS.length - 1), c }))
}

const parse = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16))

export function scoreColor(score: number, lo: number, hi: number): string {
  const t = Math.min(1, Math.max(0, (score - lo) / Math.max(hi - lo, 1e-9)))
  const pos = t * (STOPS.length - 1)
  const i = Math.min(STOPS.length - 2, Math.floor(pos))
  const f = pos - i
  const pa = parse(STOPS[i]), pb = parse(STOPS[i + 1])
  return `rgb(${pa.map((x, k) => Math.round(x + (pb[k] - x) * f)).join(',')})`
}
