import { setMapColors } from './colors'
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'

/** RGB triplet "r g b": lets Tailwind apply opacity (bg-panel/90) on top of a CSS variable. */
type Rgb = string
const hex = (t: Rgb) => '#' + t.split(' ').map((n) => Number(n).toString(16).padStart(2, '0')).join('')

interface Tokens {
  ink950: Rgb; ink900: Rgb; ink800: Rgb; ink700: Rgb; ink600: Rgb; ink500: Rgb   // surfaces and borders
  paper: Rgb; dim: Rgb; mute: Rgb                                                 // text
  crema: Rgb; cremaDeep: Rgb; onCrema: Rgb                                        // main accent and the text on top of it
  tealGlow: Rgb; tealMid: Rgb; tealDeep: Rgb
  pos: Rgb; neg: Rgb; neu: Rgb
  posSoft: Rgb; posInk: Rgb; negSoft: Rgb; negInk: Rgb
  deep900: Rgb; deep800: Rgb; deep700: Rgb; deepText: Rgb; deepMute: Rgb         // brand-dark areas: intro, footer
  glow1: Rgb; glow2: Rgb
  mix: Rgb                                                                        // what accent colours are mixed with to get readable text
}

interface MapTokens { ramp: [string, string, string, string]; bg: string; insufficient: string; ctxFill: string; ctxLine: string; arrLine: string; venueLine: string; ring: string }

export interface Palette extends Record<string, any> {
  id: ThemeId
  label: string
  swatch: [string, string]
  tokens: Tokens
  map: MapTokens
  // ready-to-use hex values for charts
  grid: string; axis: string; text: string; textDim: string; panel: string; border: string
  primary: string; primaryDeep: string; cursor: string; track: string; neutral: string
}

export type ThemeId = 'berry' | 'navy' | 'espresso' | 'matcha' | 'ocean' | 'sunset' | 'mono' | 'dark' | 'seoul'
export const THEME_ORDER: ThemeId[] = ['berry', 'navy', 'espresso', 'matcha', 'ocean', 'sunset', 'mono', 'dark', 'seoul']
export const DARK_THEMES: ThemeId[] = ['dark', 'seoul']

function make(id: ThemeId, label: string, swatch: [string, string], t: Tokens, map: MapTokens, cursor: string): Palette {
  return {
    id, label, swatch, tokens: t, map,
    grid: hex(t.ink600), axis: hex(t.mute), text: hex(t.paper), textDim: hex(t.dim), panel: hex(t.ink800), border: hex(t.ink600),
    primary: hex(t.crema), primaryDeep: hex(t.cremaDeep), cursor, track: hex(t.ink700), neutral: hex(t.neu),
  }
}

export const THEMES: Record<ThemeId, Palette> = {
  berry: make('berry', 'Berry', ['#B5214F', '#2B1A1D'], {
    ink950: '241 234 230', ink900: '251 248 246', ink800: '255 255 255', ink700: '245 239 236', ink600: '232 222 218', ink500: '213 199 194',
    paper: '43 26 29', dim: '90 70 74', mute: '127 107 112',
    crema: '181 33 79', cremaDeep: '217 69 107', onCrema: '255 255 255',
    tealGlow: '47 111 79', tealMid: '111 174 139', tealDeep: '228 242 234',
    pos: '35 130 90', neg: '194 58 50', neu: '124 119 136',
    posSoft: '225 243 234', posInk: '29 107 73', negSoft: '251 229 225', negInk: '168 51 43',
    deep900: '31 17 22', deep800: '38 18 27', deep700: '74 32 56', deepText: '255 243 230', deepMute: '205 185 189',
    glow1: '217 69 107', glow2: '224 165 38', mix: '43 26 29',
  }, {
    ramp: ['#FBE6CC', '#F4A97F', '#D9456B', '#6E1F5A'], bg: '#E6EDF1', insufficient: '#D8D4DA', ctxFill: '#F7F3F1', ctxLine: '#BFB3BA', arrLine: 'rgba(255,253,252,0.95)', venueLine: '#FFFFFF', ring: '#B9B2BE',
  }, 'rgba(70,30,45,0.06)'),

  navy: make('navy', 'Navy & coral', ['#E05038', '#0F1E3A'], {
    ink950: '233 238 245', ink900: '246 248 251', ink800: '255 255 255', ink700: '238 242 248', ink600: '221 228 238', ink500: '194 205 221',
    paper: '15 30 58', dim: '58 74 104', mute: '100 116 145',
    crema: '201 64 40', cremaDeep: '240 111 85', onCrema: '255 255 255',
    tealGlow: '30 100 130', tealMid: '90 160 190', tealDeep: '221 238 246',
    pos: '28 130 100', neg: '200 60 52', neu: '110 120 140',
    posSoft: '222 242 234', posInk: '24 105 80', negSoft: '252 228 224', negInk: '170 50 42',
    deep900: '9 22 44', deep800: '13 31 61', deep700: '27 58 107', deepText: '240 246 255', deepMute: '170 186 214',
    glow1: '240 111 85', glow2: '90 160 230', mix: '15 30 58',
  }, {
    ramp: ['#FDE9DC', '#F7A48A', '#E8573F', '#14305F'], bg: '#E3EBF4', insufficient: '#D3DAE4', ctxFill: '#F4F7FB', ctxLine: '#AEBBD0', arrLine: 'rgba(255,255,255,0.95)', venueLine: '#FFFFFF', ring: '#B4C0D2',
  }, 'rgba(15,30,58,0.06)'),


  espresso: make('espresso', 'Espresso', ['#C47A3A', '#2C1E16'], {
    ink950: '238 230 221', ink900: '249 245 240', ink800: '255 253 250', ink700: '243 236 228', ink600: '228 216 203', ink500: '206 190 173',
    paper: '44 30 22', dim: '94 74 60', mute: '128 108 92',
    crema: '150 84 34', cremaDeep: '196 122 58', onCrema: '255 255 255',
    tealGlow: '60 110 80', tealMid: '120 170 135', tealDeep: '228 240 230',
    pos: '40 125 85', neg: '190 60 45', neu: '125 115 105',
    posSoft: '226 240 229', posInk: '30 100 65', negSoft: '248 228 220', negInk: '160 50 35',
    deep900: '28 18 12', deep800: '40 26 18', deep700: '82 52 32', deepText: '255 244 230', deepMute: '205 186 168',
    glow1: '214 140 70', glow2: '240 200 120', mix: '44 30 22',
  }, {
    ramp: ['#F6E7D2', '#E2B57F', '#A8652F', '#4A2A16'], bg: '#E4E6E2', insufficient: '#D9D3CC', ctxFill: '#F5F1EB', ctxLine: '#C2B3A3', arrLine: 'rgba(255,252,248,0.95)', venueLine: '#FFFFFF', ring: '#BFB1A4',
  }, 'rgba(44,30,22,0.06)'),

  matcha: make('matcha', 'Matcha', ['#6EA050', '#1A2A1E'], {
    ink950: '232 238 228', ink900: '246 249 243', ink800: '255 255 252', ink700: '237 243 233', ink600: '219 229 213', ink500: '191 206 183',
    paper: '26 42 30', dim: '64 84 68', mute: '102 122 104',
    crema: '58 112 56', cremaDeep: '110 160 80', onCrema: '255 255 255',
    tealGlow: '40 110 100', tealMid: '100 170 160', tealDeep: '222 240 236',
    pos: '30 120 95', neg: '196 70 50', neu: '120 128 118',
    posSoft: '224 242 230', posInk: '28 100 66', negSoft: '250 230 222', negInk: '165 55 40',
    deep900: '16 30 20', deep800: '22 40 27', deep700: '44 78 50', deepText: '240 248 236', deepMute: '180 200 182',
    glow1: '130 190 90', glow2: '230 200 110', mix: '26 42 30',
  }, {
    ramp: ['#EEF5D6', '#B8D98A', '#5E9E4E', '#1F4D33'], bg: '#E3EAEC', insufficient: '#D5DBD2', ctxFill: '#F3F7EF', ctxLine: '#B5C4AE', arrLine: 'rgba(255,255,252,0.95)', venueLine: '#FFFFFF', ring: '#AFBDA9',
  }, 'rgba(26,42,30,0.06)'),

  ocean: make('ocean', 'Ocean', ['#2AA5AA', '#0E2830'], {
    ink950: '228 237 238', ink900: '244 249 249', ink800: '255 255 255', ink700: '234 243 244', ink600: '214 228 230', ink500: '184 204 208',
    paper: '14 40 48', dim: '50 82 90', mute: '92 120 128',
    crema: '0 116 124', cremaDeep: '42 165 170', onCrema: '255 255 255',
    tealGlow: '0 110 120', tealMid: '90 175 180', tealDeep: '222 242 242',
    pos: '30 128 92', neg: '200 70 55', neu: '110 125 130',
    posSoft: '222 242 234', posInk: '24 102 74', negSoft: '252 230 224', negInk: '168 52 40',
    deep900: '6 28 34', deep800: '10 40 48', deep700: '18 82 92', deepText: '236 250 250', deepMute: '160 196 200',
    glow1: '60 190 190', glow2: '240 190 120', mix: '14 40 48',
  }, {
    ramp: ['#FFF1D6', '#9ED8D0', '#2A9DA3', '#0F3F5C'], bg: '#E2ECEF', insufficient: '#D2DDE0', ctxFill: '#F2F7F7', ctxLine: '#A8C1C6', arrLine: 'rgba(255,255,255,0.95)', venueLine: '#FFFFFF', ring: '#A9BFC3',
  }, 'rgba(14,40,48,0.06)'),

  sunset: make('sunset', 'Sunset', ['#EE6A3C', '#3A1420'], {
    ink950: '244 233 226', ink900: '252 247 243', ink800: '255 255 255', ink700: '248 238 231', ink600: '237 220 209', ink500: '220 196 181',
    paper: '46 24 20', dim: '96 62 54', mute: '134 100 92',
    crema: '196 72 30', cremaDeep: '240 130 70', onCrema: '255 255 255',
    tealGlow: '50 110 120', tealMid: '110 170 175', tealDeep: '226 240 240',
    pos: '36 128 88', neg: '200 50 60', neu: '128 116 112',
    posSoft: '226 242 232', posInk: '28 102 70', negSoft: '252 228 228', negInk: '168 40 50',
    deep900: '36 14 18', deep800: '52 20 26', deep700: '120 40 50', deepText: '255 240 230', deepMute: '220 180 170',
    glow1: '255 140 80', glow2: '255 200 90', mix: '46 24 20',
  }, {
    ramp: ['#FFF0C9', '#FDB86A', '#EE6A3C', '#8A1F3D'], bg: '#E7ECF0', insufficient: '#DCD3CF', ctxFill: '#FBF4EF', ctxLine: '#D2B9AC', arrLine: 'rgba(255,253,250,0.95)', venueLine: '#FFFFFF', ring: '#C9B2A6',
  }, 'rgba(46,24,20,0.06)'),

  mono: make('mono', 'Mono', ['#F0CB45', '#1E1E1E'], {
    ink950: '234 234 232', ink900: '247 247 245', ink800: '255 255 255', ink700: '239 239 236', ink600: '222 222 218', ink500: '196 196 190',
    paper: '24 24 24', dim: '72 72 70', mute: '112 112 108',
    crema: '28 28 28', cremaDeep: '214 168 0', onCrema: '255 255 255',
    tealGlow: '60 100 90', tealMid: '130 160 150', tealDeep: '232 238 236',
    pos: '36 124 84', neg: '196 56 48', neu: '120 120 116',
    posSoft: '228 240 232', posInk: '28 98 66', negSoft: '250 230 226', negInk: '160 44 36',
    deep900: '14 14 14', deep800: '22 22 22', deep700: '52 52 50', deepText: '250 250 246', deepMute: '180 180 174',
    glow1: '240 196 40', glow2: '150 150 150', mix: '24 24 24',
  }, {
    ramp: ['#FAF3D2', '#F0CB45', '#9A8F5E', '#232323'], bg: '#E9EBEC', insufficient: '#D6D6D2', ctxFill: '#F6F6F4', ctxLine: '#BDBDB6', arrLine: 'rgba(255,255,255,0.95)', venueLine: '#FFFFFF', ring: '#B5B5AE',
  }, 'rgba(24,24,24,0.06)'),

  dark: make('dark', 'Dark', ['#FF7D69', '#121722'], {
    ink950: '14 18 27', ink900: '18 23 34', ink800: '27 34 50', ink700: '33 41 60', ink600: '48 58 82', ink500: '70 82 110',
    paper: '236 240 248', dim: '176 186 205', mute: '130 143 168',
    crema: '255 125 105', cremaDeep: '255 156 138', onCrema: '28 14 16',
    tealGlow: '120 205 215', tealMid: '70 140 150', tealDeep: '28 52 60',
    pos: '90 205 150', neg: '255 120 110', neu: '150 160 180',
    posSoft: '28 64 50', posInk: '120 224 170', negSoft: '72 34 36', negInk: '255 150 140',
    deep900: '8 11 18', deep800: '14 19 30', deep700: '36 48 84', deepText: '240 244 252', deepMute: '160 172 196',
    glow1: '255 125 105', glow2: '99 130 255', mix: '255 255 255',
  }, {
    ramp: ['#2A3358', '#6B5BA8', '#E0607E', '#FFC36B'], bg: '#0D121C', insufficient: '#2A3042', ctxFill: '#1B2233', ctxLine: '#36435F', arrLine: 'rgba(18,23,34,0.9)', venueLine: '#12161F', ring: '#46526E',
  }, 'rgba(255,255,255,0.06)'),

  seoul: make('seoul', 'Seoul night', ['#FF5CAA', '#0E0E1C'], {
    ink950: '10 10 20', ink900: '14 14 28', ink800: '24 24 44', ink700: '32 32 56', ink600: '48 48 80', ink500: '72 72 110',
    paper: '240 238 255', dim: '186 182 214', mute: '140 136 172',
    crema: '255 92 170', cremaDeep: '255 140 200', onCrema: '20 8 20',
    tealGlow: '90 230 230', tealMid: '60 150 160', tealDeep: '20 50 60',
    pos: '80 220 170', neg: '255 110 120', neu: '150 148 180',
    posSoft: '22 60 52', posInk: '120 240 190', negSoft: '70 28 40', negInk: '255 150 160',
    deep900: '6 6 14', deep800: '12 12 26', deep700: '50 30 90', deepText: '244 240 255', deepMute: '170 164 210',
    glow1: '255 92 170', glow2: '80 220 255', mix: '255 255 255',
  }, {
    ramp: ['#242452', '#5340B0', '#D14DAE', '#FFB0DD'], bg: '#0B0B16', insufficient: '#262640', ctxFill: '#15152A', ctxLine: '#34345A', arrLine: 'rgba(14,14,28,0.9)', venueLine: '#0E0E1C', ring: '#4A4A78',
  }, 'rgba(255,255,255,0.06)'),
}

const KEY = 'financier-theme'
const CSS_NAMES: Record<keyof Tokens, string> = {
  ink950: '--ink-950', ink900: '--ink-900', ink800: '--ink-800', ink700: '--ink-700', ink600: '--ink-600', ink500: '--ink-500',
  paper: '--paper', dim: '--paper-dim', mute: '--paper-mute', crema: '--crema', cremaDeep: '--crema-deep', onCrema: '--on-crema',
  tealGlow: '--teal-glow', tealMid: '--teal-mid', tealDeep: '--teal-deep', pos: '--pos', neg: '--neg', neu: '--neu',
  posSoft: '--pos-soft', posInk: '--pos-ink', negSoft: '--neg-soft', negInk: '--neg-ink',
  deep900: '--deep-900', deep800: '--deep-800', deep700: '--deep-700', deepText: '--deep-text', deepMute: '--deep-mute',
  glow1: '--glow-1', glow2: '--glow-2', mix: '--mix',
}

export function applyTheme(id: ThemeId) {
  const p = THEMES[id]
  const root = document.documentElement
  for (const k of Object.keys(CSS_NAMES) as (keyof Tokens)[]) root.style.setProperty(CSS_NAMES[k], p.tokens[k])
  root.style.setProperty('--ring', p.map.ring)
  root.style.setProperty('--cursor', p.cursor)
  setMapColors(p.map.ramp, p.map.insufficient)
  root.dataset.theme = id
  const isDark = DARK_THEMES.includes(id)
  root.style.colorScheme = isDark ? 'dark' : 'light'
  const meta = document.querySelector('meta[name="color-scheme"]')
  if (meta) meta.setAttribute('content', isDark ? 'dark' : 'light')
}

export function initialTheme(): ThemeId {
  try {
    const v = localStorage.getItem(KEY)
    if (v && v in THEMES) return v as ThemeId
  } catch { /* storage unavailable: default theme */ }
  return 'berry'
}

interface Ctx { theme: ThemeId; palette: Palette; setTheme: (t: ThemeId) => void }
const ThemeCtx = createContext<Ctx>({ theme: 'berry', palette: THEMES.berry, setTheme: () => {} })

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeId>(initialTheme)
  useEffect(() => { applyTheme(theme) }, [theme])
  const setTheme = useCallback((t: ThemeId) => {
    setThemeState(t)
    try { localStorage.setItem(KEY, t) } catch { /* the choice just will not be remembered */ }
  }, [])
  const value = useMemo(() => ({ theme, palette: THEMES[theme], setTheme }), [theme, setTheme])
  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>
}

export const useTheme = () => useContext(ThemeCtx)
export const usePalette = () => useContext(ThemeCtx).palette
