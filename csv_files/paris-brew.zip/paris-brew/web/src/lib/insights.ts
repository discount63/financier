import { dec1, dec2, int, pct } from './format'
import type { District, Ranking } from './types'

export const RAW_FORMAT: Record<string, (v: number) => string> = {
  demand_population: (v) => `${int(v)} residents`,
  visitor_activity: (v) => `${int(v)} hospitality venues`,
  low_competition: (v) => `${dec1(v)} cafés per 10,000 residents`,
  incumbent_dissatisfaction: (v) => `average rating ${dec2(v)} / 5`,
  price_pain: (v) => `${pct(v)} of price mentions are negative`,
  wait_pain: (v) => `${pct(v)} of waiting-time mentions are negative`,
  takeaway_signal: (v) => `${pct(v)} of declared orders are takeaway`,
}

export interface Insight { key: string; label: string; detail: string; value: number }

/** Strengths and weaknesses of a district: score criteria clearly above (≥ 0.7) or below (≤ 0.3) the median. */
export function insightsFor(d: District, ranking: Ranking): { strengths: Insight[]; weaknesses: Insight[] } {
  const strengths: Insight[] = []
  const weaknesses: Insight[] = []
  if (!d.components) return { strengths, weaknesses }
  for (const [key, value] of Object.entries(d.components)) {
    if (value == null || !ranking.criteria[key]) continue
    const raw = d.raw?.[key]
    const item = {
      key, value, label: ranking.criteria[key].label,
      detail: raw != null && RAW_FORMAT[key] ? RAW_FORMAT[key](raw) : '',
    }
    if (value >= 0.7) strengths.push(item)
    else if (value <= 0.3) weaknesses.push(item)
  }
  strengths.sort((a, b) => b.value - a.value)
  weaknesses.sort((a, b) => a.value - b.value)
  return { strengths, weaknesses }
}

/** Short names for chart axes (the full label stays in tooltips). */
export const SHORT_LABEL: Record<string, string> = {
  demand_population: 'Residents',
  visitor_activity: 'Footfall',
  low_competition: 'Few cafés',
  incumbent_dissatisfaction: 'Room to grow',
  price_pain: 'Price pain',
  wait_pain: 'Wait pain',
  takeaway_signal: 'Takeaway',
}
export const shortLabel = (key: string, full?: string) => SHORT_LABEL[key] ?? (full ?? key).split(' ').slice(0, 2).join(' ')
