/** Minimal CSV reader (separator ',' or ';', basic quotes handled). */
export function parseCsv(text: string): Record<string, string>[] {
  const clean = text.replace(/^﻿/, '')
  const firstLine = clean.split(/\r?\n/, 1)[0] ?? ''
  const sep = (firstLine.match(/;/g)?.length ?? 0) > (firstLine.match(/,/g)?.length ?? 0) ? ';' : ','
  const rows: string[][] = []
  let row: string[] = [], cell = '', quoted = false
  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i]
    if (quoted) {
      if (ch === '"' && clean[i + 1] === '"') { cell += '"'; i++ }
      else if (ch === '"') quoted = false
      else cell += ch
    } else if (ch === '"') quoted = true
    else if (ch === sep) { row.push(cell); cell = '' }
    else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && clean[i + 1] === '\n') i++
      row.push(cell); cell = ''
      if (row.some((c) => c.trim() !== '')) rows.push(row)
      row = []
    } else cell += ch
  }
  if (cell !== '' || row.length) { row.push(cell); if (row.some((c) => c.trim() !== '')) rows.push(row) }
  const [header, ...body] = rows
  if (!header) return []
  return body.map((r) => Object.fromEntries(header.map((h, i) => [h.trim(), (r[i] ?? '').trim()])))
}

export interface IndicatorOverride {
  arr: number
  students?: number
  transit?: number
  rent?: number
  source: string
}

const num = (v: string | undefined) => {
  if (v == null || v === '') return undefined
  const n = Number(v.replace(/\s/g, '').replace(',', '.'))
  return Number.isFinite(n) ? n : undefined
}

/** Recognised columns: arrondissement, students, transit_stations, rent_eur_m2_year, source (optional). */
export function toOverrides(rows: Record<string, string>[], fileName: string): IndicatorOverride[] {
  const out: IndicatorOverride[] = []
  for (const r of rows) {
    const arr = num(r.arrondissement ?? r.arr)
    if (!arr || arr < 1 || arr > 20) continue
    out.push({
      arr,
      students: num(r.students),
      transit: num(r.transit_stations),
      rent: num(r.rent_eur_m2_year),
      source: r.source || `Imported file: ${fileName}`,
    })
  }
  return out
}
