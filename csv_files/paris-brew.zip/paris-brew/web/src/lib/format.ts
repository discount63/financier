const nf0 = new Intl.NumberFormat('en-GB', { maximumFractionDigits: 0 })
const nf1 = new Intl.NumberFormat('en-GB', { maximumFractionDigits: 1, minimumFractionDigits: 1 })
const nf2 = new Intl.NumberFormat('en-GB', { maximumFractionDigits: 2, minimumFractionDigits: 2 })

export const int = (v: number | null | undefined) => (v == null ? '—' : nf0.format(v))
export const dec1 = (v: number | null | undefined) => (v == null ? '—' : nf1.format(v))
export const dec2 = (v: number | null | undefined) => (v == null ? '—' : nf2.format(v))
export const pct = (v: number | null | undefined, digits = 0) =>
  v == null ? '—' : `${(v * 100).toLocaleString('en-GB', { maximumFractionDigits: digits, minimumFractionDigits: digits })}%`
export const eur = (v: number | null | undefined, digits = 0) =>
  v == null ? '—' : v.toLocaleString('en-GB', { style: 'currency', currency: 'EUR', maximumFractionDigits: digits, minimumFractionDigits: digits })
export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v))
