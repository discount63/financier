/** Landmarks per district. Photos and one-line descriptions are fetched live from Wikipedia (internet needed);
 *  offline, the scene still works with colour cards. */
export interface Landmark { title: string; name: string }

export const LANDMARKS: Record<number, Landmark[]> = {
  1: [{ title: 'Louvre', name: 'The Louvre' }, { title: 'Tuileries Garden', name: 'Tuileries Garden' }, { title: 'Palais-Royal', name: 'Palais-Royal' }, { title: 'Place Vendôme', name: 'Place Vendôme' }, { title: 'Pont Neuf', name: 'Pont Neuf' }],
  2: [{ title: 'Palais Brongniart', name: 'Palais Brongniart' }, { title: 'Galerie Vivienne', name: 'Galerie Vivienne' }, { title: 'Passage des Panoramas', name: 'Passage des Panoramas' }, { title: 'Place des Victoires', name: 'Place des Victoires' }],
  3: [{ title: 'Carreau du Temple', name: 'Carreau du Temple' }, { title: 'Musée Picasso', name: 'Musée Picasso' }, { title: 'Musée des Arts et Métiers', name: 'Arts et Métiers' }],
  4: [{ title: 'Notre-Dame de Paris', name: 'Notre-Dame' }, { title: 'Centre Pompidou', name: 'Centre Pompidou' }, { title: 'Hôtel de Ville, Paris', name: 'Hôtel de Ville' }, { title: 'Place des Vosges', name: 'Place des Vosges' }, { title: 'Île Saint-Louis', name: 'Île Saint-Louis' }],
  5: [{ title: 'Panthéon, Paris', name: 'The Panthéon' }, { title: 'Jardin des Plantes', name: 'Jardin des Plantes' }, { title: 'Sorbonne', name: 'La Sorbonne' }, { title: 'Arènes de Lutèce', name: 'Arènes de Lutèce' }, { title: 'Latin Quarter, Paris', name: 'Latin Quarter' }],
  6: [{ title: 'Luxembourg Gardens', name: 'Luxembourg Gardens' }, { title: 'Saint-Sulpice, Paris', name: 'Saint-Sulpice' }, { title: 'Café de Flore', name: 'Café de Flore' }, { title: 'Institut de France', name: 'Institut de France' }],
  7: [{ title: 'Eiffel Tower', name: 'Eiffel Tower' }, { title: "Musée d'Orsay", name: "Musée d'Orsay" }, { title: 'Les Invalides', name: 'Les Invalides' }, { title: 'Pont Alexandre III', name: 'Pont Alexandre III' }, { title: 'Musée du quai Branly – Jacques Chirac', name: 'Musée du quai Branly' }],
  8: [{ title: 'Champs-Élysées', name: 'Champs-Élysées' }, { title: 'Arc de Triomphe', name: 'Arc de Triomphe' }, { title: 'Grand Palais', name: 'Grand Palais' }, { title: 'Place de la Concorde', name: 'Place de la Concorde' }, { title: 'La Madeleine, Paris', name: 'La Madeleine' }],
  9: [{ title: 'Palais Garnier', name: 'Opéra Garnier' }, { title: 'Galeries Lafayette', name: 'Galeries Lafayette' }, { title: 'Folies Bergère', name: 'Folies Bergère' }, { title: 'Place Pigalle', name: 'Place Pigalle' }],
  10: [{ title: 'Canal Saint-Martin', name: 'Canal Saint-Martin' }, { title: 'Gare du Nord', name: 'Gare du Nord' }, { title: 'Porte Saint-Denis', name: 'Porte Saint-Denis' }, { title: 'Gare de l\'Est', name: 'Gare de l\'Est' }],
  11: [{ title: "Cirque d'Hiver", name: "Cirque d'Hiver" }, { title: 'Place de la République', name: 'Place de la République' }, { title: 'Place de la Bastille', name: 'Place de la Bastille' }],
  12: [{ title: 'Opéra Bastille', name: 'Opéra Bastille' }, { title: 'Bois de Vincennes', name: 'Bois de Vincennes' }, { title: 'Gare de Lyon', name: 'Gare de Lyon' }, { title: 'Promenade plantée', name: 'Promenade plantée' }, { title: 'Palais de la Porte Dorée', name: 'Palais de la Porte Dorée' }],
  13: [{ title: 'Bibliothèque nationale de France', name: 'Bibliothèque nationale de France' }, { title: 'Chinatown, Paris', name: 'Chinatown' }, { title: 'Manufacture des Gobelins', name: 'Manufacture des Gobelins' }, { title: 'Place d\'Italie', name: 'Place d\'Italie' }, { title: 'Butte-aux-Cailles', name: 'Butte-aux-Cailles' }],
  14: [{ title: 'Catacombs of Paris', name: 'The Catacombs' }, { title: 'Montparnasse Cemetery', name: 'Montparnasse Cemetery' }, { title: 'Fondation Cartier pour l\'art contemporain', name: 'Fondation Cartier' }, { title: 'Parc Montsouris', name: 'Parc Montsouris' }, { title: 'Cité internationale universitaire de Paris', name: 'Cité universitaire' }],
  15: [{ title: 'Tour Montparnasse', name: 'Tour Montparnasse' }, { title: 'Parc André Citroën', name: 'Parc André Citroën' }, { title: 'Paris Expo Porte de Versailles', name: 'Porte de Versailles' }, { title: 'Beaugrenelle', name: 'Beaugrenelle' }],
  16: [{ title: 'Palais de Chaillot', name: 'Palais de Chaillot' }, { title: 'Bois de Boulogne', name: 'Bois de Boulogne' }, { title: 'Palais de Tokyo', name: 'Palais de Tokyo' }, { title: 'Trocadéro Gardens', name: 'Trocadéro Gardens' }, { title: 'Fondation Louis Vuitton', name: 'Fondation Louis Vuitton' }],
  17: [{ title: 'Palais des Congrès de Paris', name: 'Palais des Congrès' }, { title: 'Parc Clichy-Batignolles – Martin Luther King', name: 'Parc Martin Luther King' }, { title: 'Square des Batignolles', name: 'Square des Batignolles' }],
  18: [{ title: 'Sacré-Cœur, Paris', name: 'Sacré-Cœur' }, { title: 'Moulin Rouge', name: 'Moulin Rouge' }, { title: 'Place du Tertre', name: 'Place du Tertre' }, { title: 'Montmartre', name: 'Montmartre' }],
  19: [{ title: 'Parc des Buttes-Chaumont', name: 'Buttes-Chaumont' }, { title: 'Parc de la Villette', name: 'Parc de la Villette' }, { title: "Cité des Sciences et de l'Industrie", name: 'Cité des Sciences' }, { title: 'Philharmonie de Paris', name: 'Philharmonie de Paris' }, { title: 'Bassin de la Villette', name: 'Bassin de la Villette' }],
  20: [{ title: 'Père Lachaise Cemetery', name: 'Père Lachaise' }, { title: 'Parc de Belleville', name: 'Parc de Belleville' }, { title: 'Ménilmontant', name: 'Ménilmontant' }],
}

/** Warm gradient used behind the scene while (or if) photos are not available. */
export const DISTRICT_HUE: Record<number, number> = Object.fromEntries(Array.from({ length: 20 }, (_, i) => [i + 1, (i * 47 + 20) % 360]))

export interface LandmarkInfo { title: string; name: string; image: string | null; preview: string | null; description: string | null; ratio: number | null; width: number | null; done: boolean }

/** A photo works as a full-screen backdrop when it is a wide landscape and sharp enough. */
export const isGood = (l: LandmarkInfo) => !!l.image && (l.ratio ?? 0) >= 1.35 && (l.width ?? 0) >= 1200
const cache = new Map<string, LandmarkInfo>()

/** Wikimedia only serves a fixed set of thumbnail widths; 1920 is sharp on a full-screen backdrop, 960 loads fast as a first look. */
function sized(thumb: string, width: number): string {
  return thumb.replace(/\/\d+px-/, `/${width}px-`)
}

export async function fetchLandmark(l: Landmark, signal?: AbortSignal): Promise<LandmarkInfo> {
  const hit = cache.get(l.title)
  if (hit) return hit
  let info: LandmarkInfo = { ...l, image: null, preview: null, description: null, ratio: null, width: null, done: false }
  try {
    const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(l.title.replace(/ /g, '_'))}`, { signal })
    if (!res.ok) throw new Error(String(res.status))
    const j = await res.json()
    const thumb: string | undefined = j.thumbnail?.source
    const ow: number | undefined = j.originalimage?.width
    let image: string | null = null, preview: string | null = null
    if (thumb && thumb.includes('/thumb/')) {
      const best = !ow || ow >= 3000 ? 1920 : ow >= 1920 ? 1920 : ow >= 1280 ? 1280 : ow >= 960 ? 960 : 0
      image = best ? sized(thumb, best) : (j.originalimage?.source ?? thumb)
      preview = sized(thumb, ow && ow < 960 ? Math.min(ow, 500) : 960)
      if (preview === image) preview = null
    } else if (thumb) {
      image = j.originalimage?.source ?? thumb
    }
    const oh: number | undefined = j.originalimage?.height
    info = { ...l, image, preview, description: j.description ?? null, ratio: ow && oh ? ow / oh : null, width: ow ?? null, done: true }
    cache.set(l.title, info)
  } catch { info = { ...info, done: true } /* offline or unknown article: keep the colour card */ }
  return info
}
