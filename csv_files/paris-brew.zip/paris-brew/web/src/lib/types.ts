export type Status = 'measured' | 'estimate' | 'unavailable'

export interface Metric {
  value: number | null
  unit: string
  status: Status
  source: string
  note: string
}

export interface AspectStats {
  mentions: number
  reliable: boolean
  review_share?: number
  positive?: number
  neutral?: number
  negative?: number
  net?: number
  label?: string
  rating_correlation?: number | null
  rating_when_negative?: number | null
  rating_when_positive?: number | null
  top_complaints?: Term[]
  top_praise?: Term[]
}

export interface Term { term: string; count: number; example: string }

export interface District {
  arr: number
  name: string
  label: string
  score: number | null
  eligible: boolean
  confidence: 'high' | 'medium' | 'low'
  rank: number | null
  top3_stability: number | null
  rank_interval: [number, number] | null
  cluster: number | null
  pca: [number, number] | null
  components: Record<string, number | null> | null
  raw: Record<string, number | null> | null
  imputed: string[]
  rating_hist: number[]
  metrics: Record<string, Metric>
  aspects: Record<string, AspectStats> | null
}

export interface Criterion { label: string; source: string; direction: number; weight: number }

export interface Ranking {
  status: 'reliable' | 'provisional'
  reasons: string[]
  caveats: string[]
  top: number[]
  criteria: Record<string, Criterion>
  dropped_criteria: string[]
  excluded: number[]
  top_n: number
  min_reviews: number
  min_top3_stability: number
  draws: number
}

export interface Dist { label: string; count: number; share: number }

export interface Meta {
  generated_at: string
  audit: Record<string, any>
  structured: {
    sub_ratings: Record<string, { n: number; mean: number; share_1_2: number; share_5: number }>
    rating_hist: number[]
    price_band: Dist[]
    wait: Dist[]
    noise: Dist[]
    order_type: Dist[]
    lexical: { note: string; negative_reviews: number; terms: Term[] }
  }
  global: { reviews: number; venues: number; rating_mean: number; pct_1_2: number }
  chains: Record<'chain' | 'independent', { reviews: number; venues: number; rating_mean: number; pct_1_2: number }>
  sirene_total: number
  absa_available: boolean
  geometry_quality: 'official' | 'lowres_fallback'
  weights: Record<string, number>
  ranking_status: string
  run_info: Record<string, any> | null
  sources: { name: string; detail: string; url: string }[]
  absa_config: Record<string, any>
}

export interface AspectsFile {
  available: boolean
  labels: Record<string, string>
  global: Record<string, AspectStats> | null
  validation: Record<string, { google_sub_rating: string; n: number; spearman: number }> | null
}

export interface Clusters {
  k: number
  silhouette: number
  features: string[]
  clusters: { id: number; members: number[]; traits: string[] }[]
  assignment: Record<string, number>
  pca: Record<string, [number, number]>
  explained_variance: number[]
  caveat: string
}

export interface Venue { n: string; lat: number; lon: number; arr: number; seg: string; r: number | null; c: boolean; k: number }

export interface AppData {
  districts: District[]
  ranking: Ranking
  aspects: AspectsFile
  clusters: Clusters
  meta: Meta
  geojson: GeoJSON.FeatureCollection
  venues: Venue[]
  /** Surrounding departments (optional file: the map still works without it). */
  context?: GeoJSON.FeatureCollection
}
