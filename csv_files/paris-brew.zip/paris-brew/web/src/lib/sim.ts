export interface SimInputs {
  priceTtc: number
  vat: number            // 0.10 = 10 %
  cupsPerDay: number
  daysPerMonth: number
  rent: number           // € / mois
  staffCount: number     // équivalents temps plein
  costPerStaff: number   // coût employeur chargé € / mois
  ingredients: number    // € / tasse
  packaging: number      // € / tasse
  paymentFee: number     // part du CA HT
  other: number          // € / month: energy, insurance, accountant, software… (one lump sum, on purpose)
}

export const DEFAULT_SIM: SimInputs = {
  priceTtc: 1.5, vat: 0.1, cupsPerDay: 300, daysPerMonth: 26, rent: 4500, staffCount: 3, costPerStaff: 2600,
  ingredients: 0.35, packaging: 0.08, paymentFee: 0.015, other: 1600,
}

export interface SimResult {
  priceHt: number
  revenue: number
  variable: number
  fixed: number
  profit: number
  contributionPerCup: number
  breakEvenCupsPerDay: number | null
  fixedBreakdown: { rent: number; staff: number; other: number }
  variableBreakdown: { ingredients: number; packaging: number; fees: number }
  breakEvenPrice: number
}

export function simulate(i: SimInputs): SimResult {
  const priceHt = i.priceTtc / (1 + i.vat)
  const cupsMonth = i.cupsPerDay * i.daysPerMonth
  const fees = priceHt * i.paymentFee
  const varPerCup = i.ingredients + i.packaging + fees
  const staff = i.staffCount * i.costPerStaff
  const fixed = i.rent + staff + i.other
  const revenue = cupsMonth * priceHt
  const variable = cupsMonth * varPerCup
  const contribution = priceHt - varPerCup
  const breakEven = contribution > 0 ? fixed / (contribution * i.daysPerMonth) : null
  // Prix TTC minimal pour couvrir les coûts au volume choisi (frais de paiement proportionnels au prix).
  const needHt = cupsMonth > 0 ? (fixed / cupsMonth + i.ingredients + i.packaging) / (1 - i.paymentFee) : Infinity
  return {
    priceHt, revenue, variable, fixed, profit: revenue - variable - fixed, contributionPerCup: contribution,
    breakEvenCupsPerDay: breakEven, fixedBreakdown: { rent: i.rent, staff, other: i.other },
    variableBreakdown: { ingredients: cupsMonth * i.ingredients, packaging: cupsMonth * i.packaging, fees: cupsMonth * fees },
    breakEvenPrice: needHt * (1 + i.vat),
  }
}
