/** Shared Recharts look. CSS variables keep tooltips and axes in tune with the active theme. */
export const TIP = {
  contentStyle: { background: 'rgb(var(--ink-800))', border: '1px solid rgb(var(--ink-600))', borderRadius: 10, fontSize: 13, color: 'rgb(var(--paper))', boxShadow: '0 8px 24px -10px rgb(0 0 0 / .4)' },
  labelStyle: { color: 'rgb(var(--paper))', fontWeight: 600 },
  itemStyle: { color: 'rgb(var(--paper))' },
}
export const AXIS_TICK = { fill: 'rgb(var(--paper-mute))', fontSize: 12 }
export const GRID = 'rgb(var(--ink-600))'
