import type { AppData } from './types'

async function load<T>(name: string): Promise<T> {
  const res = await fetch(`${import.meta.env.BASE_URL}data/${name}`)
  if (!res.ok) throw new Error(`File not found: data/${name}. Run "python3 pipeline/run_all.py" from the project root.`)
  return res.json() as Promise<T>
}

export async function loadAll(): Promise<AppData> {
  const [districts, ranking, aspects, clusters, meta, geojson, venues] = await Promise.all([
    load<AppData['districts']>('districts.json'),
    load<AppData['ranking']>('ranking.json'),
    load<AppData['aspects']>('aspects.json'),
    load<AppData['clusters']>('clusters.json'),
    load<AppData['meta']>('meta.json'),
    load<AppData['geojson']>('arrondissements.geojson'),
    load<AppData['venues']>('venues.json'),
  ])
  // decorative background of the map: if the file is missing, the map just stays plain
  let context: AppData['context']
  try { context = await load<NonNullable<AppData['context']>>('context.geojson') } catch { context = undefined }
  return { districts, ranking, aspects, clusters, meta, geojson, venues, context }
}
