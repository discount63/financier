/** Landmarks drawn on the map background. Coordinates are public knowledge (Wikipedia). `arr` links a Paris landmark to its district. */
export type Icon = 'tower' | 'arch' | 'pyramid' | 'cathedral' | 'dome' | 'palace' | 'castle' | 'stadium' | 'book' | 'windmill' | 'tree' | 'boxes' | 'skyscraper'

export interface Monument { name: string; lon: number; lat: number; icon: Icon; arr?: number; minor?: boolean }

export const MONUMENTS: Monument[] = [
  { name: 'Eiffel Tower', lon: 2.2945, lat: 48.8584, icon: 'tower', arr: 7 },
  { name: 'Arc de Triomphe', lon: 2.295, lat: 48.8738, icon: 'arch', arr: 8 },
  { name: 'Louvre', lon: 2.3376, lat: 48.8606, icon: 'pyramid', arr: 1 },
  { name: 'Notre-Dame', lon: 2.3499, lat: 48.853, icon: 'cathedral', arr: 4 },
  { name: 'Sacré-Cœur', lon: 2.3431, lat: 48.8867, icon: 'dome', arr: 18 },
  { name: 'Panthéon', lon: 2.3464, lat: 48.8462, icon: 'dome', arr: 5, minor: true },
  { name: 'Opéra Garnier', lon: 2.3316, lat: 48.8719, icon: 'palace', arr: 9, minor: true },
  { name: 'Montparnasse Tower', lon: 2.3219, lat: 48.8421, icon: 'skyscraper', arr: 15, minor: true },
  { name: 'Bibliothèque F. Mitterrand', lon: 2.3758, lat: 48.8338, icon: 'book', arr: 13, minor: true },
  { name: 'Père Lachaise', lon: 2.3933, lat: 48.8614, icon: 'tree', arr: 20, minor: true },
  { name: 'Moulin Rouge', lon: 2.3323, lat: 48.8841, icon: 'windmill', arr: 18, minor: true },
  { name: 'Centre Pompidou', lon: 2.3522, lat: 48.8606, icon: 'boxes', arr: 4, minor: true },
  { name: 'Roland-Garros', lon: 2.253, lat: 48.847, icon: 'stadium', arr: 16, minor: true },
  { name: 'La Défense · Grande Arche', lon: 2.2362, lat: 48.892, icon: 'arch' },
  { name: 'Château de Versailles', lon: 2.1204, lat: 48.8049, icon: 'palace' },
  { name: 'Stade de France', lon: 2.3601, lat: 48.9245, icon: 'stadium' },
  { name: 'Château de Vincennes', lon: 2.4358, lat: 48.8427, icon: 'castle', minor: true },
  { name: 'Disneyland Paris', lon: 2.7836, lat: 48.8674, icon: 'castle' },
  { name: 'Château de Fontainebleau', lon: 2.6998, lat: 48.4025, icon: 'palace' },
]

/** Names printed on the departments around Paris (position hand-placed so the text sits inside each area). */
export const DEPARTMENTS: Record<string, { lon: number; lat: number }> = {
  '77': { lon: 2.95, lat: 48.66 },
  '78': { lon: 1.83, lat: 48.8 },
  '91': { lon: 2.25, lat: 48.5 },
  '92': { lon: 2.19, lat: 48.8 },
  '93': { lon: 2.43, lat: 48.94 },
  '94': { lon: 2.45, lat: 48.76 },
  '95': { lon: 2.1, lat: 49.08 },
}

const P = (d: string) => `<path d="${d}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>`
const ICONS: Record<Icon, string> = {
  tower: P('M12 2.5v3 M10.6 7h2.8 M10.3 7 8 21 M13.7 7 16 21 M6.8 21h10.4 M9.2 14.5h5.6 M8.3 18h7.4'),
  arch: P('M5 21V6h14v15 M9 21v-7a3 3 0 0 1 6 0v7 M5 9.5h14'),
  pyramid: P('M12 4.5 20 18.5H4z M3 21h18 M12 4.5v14'),
  cathedral: P('M4 21V10h4V6h8v4h4v11z M10 21v-5h4v5 M12 2.5V6'),
  dome: P('M4 21h16 M6 21v-6h12v6 M7 15a5 5 0 0 1 10 0 M12 10V5.5 M10.8 7h2.4'),
  palace: P('M3 21h18 M5 21V11h14v10 M3 11l9-6 9 6 M9.5 21v-5h5v5 M8 14h.01 M16 14h.01'),
  castle: P('M5 21V9l2-2 2 2v3h6V9l2-2 2 2v12 M4 21h16 M10 21v-4a2 2 0 0 1 4 0v4 M12 2.5V7'),
  stadium: P('M3 9.5c0-2 4-3.2 9-3.2s9 1.2 9 3.2v5c0 2-4 3.2-9 3.2s-9-1.2-9-3.2z M3 9.5c0 2 4 3.2 9 3.2s9-1.2 9-3.2'),
  book: P('M5.5 4H16a3 3 0 0 1 3 3v13H8.5a3 3 0 0 1-3-3z M5.5 17a3 3 0 0 1 3-3H19'),
  windmill: P('M10.2 21 11 12.5h2l.8 8.5 M7 21h10 M12 12.5 6.5 7 M12 12.5 17.5 7 M12 12.5 6.5 18 M12 12.5 17.5 18'),
  tree: P('M12 3c3 4 5 7.2 5 11a5 5 0 0 1-10 0c0-3.800 2-7 5-11z M12 19v3'),
  boxes: P('M4 5h16v14H4z M4 10h16 M4 15h16 M9.500 5v14 M15 5v14'),
  skyscraper: P('M8.500 21V3h7v18 M7 21h10 M11 7h2 M11 11h2 M11 15h2'),
}
export const iconSvg = (i: Icon) => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[i]}</svg>`
