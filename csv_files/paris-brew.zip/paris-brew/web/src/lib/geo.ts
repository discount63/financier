type Ring = number[][]

function polygonsOf(geometry: GeoJSON.Geometry): Ring[][] {
  if (geometry.type === 'Polygon') return [geometry.coordinates as Ring[]]
  if (geometry.type === 'MultiPolygon') return geometry.coordinates as Ring[][]
  return []
}

export function boundsOf(geometry: GeoJSON.Geometry): [[number, number], [number, number]] {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
  for (const poly of polygonsOf(geometry)) for (const [x, y] of poly[0]) {
    minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y)
  }
  return [[minX, minY], [maxX, maxY]]
}

/** Centroïde (pondéré par l'aire) du plus grand polygone : sert à poser le numéro de l'arrondissement. */
export function centroidOf(geometry: GeoJSON.Geometry): [number, number] {
  let best: { area: number; c: [number, number] } | null = null
  for (const poly of polygonsOf(geometry)) {
    const ring = poly[0]
    let a = 0, cx = 0, cy = 0
    for (let i = 0; i < ring.length - 1; i++) {
      const [x0, y0] = ring[i], [x1, y1] = ring[i + 1]
      const f = x0 * y1 - x1 * y0
      a += f; cx += (x0 + x1) * f; cy += (y0 + y1) * f
    }
    a /= 2
    if (Math.abs(a) < 1e-12) continue
    const c: [number, number] = [cx / (6 * a), cy / (6 * a)]
    if (!best || Math.abs(a) > best.area) best = { area: Math.abs(a), c }
  }
  return best ? best.c : [2.3488, 48.8566]
}

export function unionBounds(features: GeoJSON.Feature[]): [[number, number], [number, number]] {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
  for (const f of features) {
    const [[a, b], [c, d]] = boundsOf(f.geometry)
    minX = Math.min(minX, a); minY = Math.min(minY, b); maxX = Math.max(maxX, c); maxY = Math.max(maxY, d)
  }
  return [[minX, minY], [maxX, maxY]]
}
