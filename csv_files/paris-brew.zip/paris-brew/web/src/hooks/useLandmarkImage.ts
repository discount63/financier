import { useEffect, useState } from 'react'
import { fetchLandmark, LANDMARKS, type LandmarkInfo } from '../lib/landmarks'

/** Landmarks of a district, filled in as Wikipedia answers (order is kept). */
export function useLandmarks(arr: number): LandmarkInfo[] {
  const base = LANDMARKS[arr] ?? []
  const [items, setItems] = useState<LandmarkInfo[]>(base.map((l) => ({ ...l, image: null, preview: null, description: null, ratio: null, width: null, done: false })))
  useEffect(() => {
    const ctl = new AbortController()
    setItems(base.map((l) => ({ ...l, image: null, preview: null, description: null, ratio: null, width: null, done: false })))
    base.forEach((l, i) => {
      fetchLandmark(l, ctl.signal).then((info) => {
        if (ctl.signal.aborted) return
        setItems((cur) => cur.map((c, k) => (k === i ? info : c)))
      })
    })
    return () => ctl.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [arr])
  return items
}
