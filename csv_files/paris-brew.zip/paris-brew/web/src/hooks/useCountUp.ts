import { animate } from 'motion'
import { useEffect, useRef, useState } from 'react'

/** Animates a number to its new value (counter). Respects reduced-motion. */
export function useCountUp(target: number | null | undefined, duration = 0.9): number | null {
  const [value, setValue] = useState<number | null>(target ?? null)
  const previous = useRef<number>(0)
  useEffect(() => {
    if (target == null) { setValue(null); return }
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    if (reduce) { setValue(target); previous.current = target; return }
    const controls = animate(previous.current, target, {
      duration, ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setValue(v),
      onComplete: () => { previous.current = target },
    })
    return () => { previous.current = target; controls.stop() }
  }, [target, duration])
  return value
}
